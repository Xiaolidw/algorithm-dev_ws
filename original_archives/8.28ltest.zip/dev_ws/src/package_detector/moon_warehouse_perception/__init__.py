"""Moon warehouse perception package."""
