// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__BUILDER_HPP_
#define MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_Goal_object_id
{
public:
  explicit Init_ExecuteManipulation_Goal_object_id(::moon_warehouse_interfaces::action::ExecuteManipulation_Goal & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Goal object_id(::moon_warehouse_interfaces::action::ExecuteManipulation_Goal::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Goal msg_;
};

class Init_ExecuteManipulation_Goal_operation
{
public:
  Init_ExecuteManipulation_Goal_operation()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_Goal_object_id operation(::moon_warehouse_interfaces::action::ExecuteManipulation_Goal::_operation_type arg)
  {
    msg_.operation = std::move(arg);
    return Init_ExecuteManipulation_Goal_object_id(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_Goal>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_Goal_operation();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_Result_message
{
public:
  explicit Init_ExecuteManipulation_Result_message(::moon_warehouse_interfaces::action::ExecuteManipulation_Result & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Result message(::moon_warehouse_interfaces::action::ExecuteManipulation_Result::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Result msg_;
};

class Init_ExecuteManipulation_Result_error_code
{
public:
  explicit Init_ExecuteManipulation_Result_error_code(::moon_warehouse_interfaces::action::ExecuteManipulation_Result & msg)
  : msg_(msg)
  {}
  Init_ExecuteManipulation_Result_message error_code(::moon_warehouse_interfaces::action::ExecuteManipulation_Result::_error_code_type arg)
  {
    msg_.error_code = std::move(arg);
    return Init_ExecuteManipulation_Result_message(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Result msg_;
};

class Init_ExecuteManipulation_Result_success
{
public:
  Init_ExecuteManipulation_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_Result_error_code success(::moon_warehouse_interfaces::action::ExecuteManipulation_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_ExecuteManipulation_Result_error_code(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_Result>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_Result_success();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_Feedback_progress
{
public:
  explicit Init_ExecuteManipulation_Feedback_progress(::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback progress(::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback::_progress_type arg)
  {
    msg_.progress = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback msg_;
};

class Init_ExecuteManipulation_Feedback_stage
{
public:
  Init_ExecuteManipulation_Feedback_stage()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_Feedback_progress stage(::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback::_stage_type arg)
  {
    msg_.stage = std::move(arg);
    return Init_ExecuteManipulation_Feedback_progress(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_Feedback_stage();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_SendGoal_Request_goal
{
public:
  explicit Init_ExecuteManipulation_SendGoal_Request_goal(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request goal(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request msg_;
};

class Init_ExecuteManipulation_SendGoal_Request_goal_id
{
public:
  Init_ExecuteManipulation_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_SendGoal_Request_goal goal_id(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_ExecuteManipulation_SendGoal_Request_goal(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_SendGoal_Request_goal_id();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_SendGoal_Response_stamp
{
public:
  explicit Init_ExecuteManipulation_SendGoal_Response_stamp(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response stamp(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response msg_;
};

class Init_ExecuteManipulation_SendGoal_Response_accepted
{
public:
  Init_ExecuteManipulation_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_SendGoal_Response_stamp accepted(::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_ExecuteManipulation_SendGoal_Response_stamp(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_SendGoal_Response_accepted();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_GetResult_Request_goal_id
{
public:
  Init_ExecuteManipulation_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request goal_id(::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_GetResult_Request_goal_id();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_GetResult_Response_result
{
public:
  explicit Init_ExecuteManipulation_GetResult_Response_result(::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response result(::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response msg_;
};

class Init_ExecuteManipulation_GetResult_Response_status
{
public:
  Init_ExecuteManipulation_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_GetResult_Response_result status(::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_ExecuteManipulation_GetResult_Response_result(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_GetResult_Response_status();
}

}  // namespace moon_warehouse_interfaces


namespace moon_warehouse_interfaces
{

namespace action
{

namespace builder
{

class Init_ExecuteManipulation_FeedbackMessage_feedback
{
public:
  explicit Init_ExecuteManipulation_FeedbackMessage_feedback(::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage feedback(::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage msg_;
};

class Init_ExecuteManipulation_FeedbackMessage_goal_id
{
public:
  Init_ExecuteManipulation_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecuteManipulation_FeedbackMessage_feedback goal_id(::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_ExecuteManipulation_FeedbackMessage_feedback(msg_);
  }

private:
  ::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>()
{
  return moon_warehouse_interfaces::action::builder::Init_ExecuteManipulation_FeedbackMessage_goal_id();
}

}  // namespace moon_warehouse_interfaces

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__BUILDER_HPP_
