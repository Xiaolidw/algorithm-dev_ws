// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_HPP_
#define MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Goal __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Goal __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_Goal_
{
  using Type = ExecuteManipulation_Goal_<ContainerAllocator>;

  explicit ExecuteManipulation_Goal_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->operation = "";
      this->object_id = "";
    }
  }

  explicit ExecuteManipulation_Goal_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : operation(_alloc),
    object_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->operation = "";
      this->object_id = "";
    }
  }

  // field types and members
  using _operation_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _operation_type operation;
  using _object_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _object_id_type object_id;

  // setters for named parameter idiom
  Type & set__operation(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->operation = _arg;
    return *this;
  }
  Type & set__object_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->object_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Goal
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Goal
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_Goal_ & other) const
  {
    if (this->operation != other.operation) {
      return false;
    }
    if (this->object_id != other.object_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_Goal_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_Goal_

// alias to use template instance with default allocator
using ExecuteManipulation_Goal =
  moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces


#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Result __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Result __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_Result_
{
  using Type = ExecuteManipulation_Result_<ContainerAllocator>;

  explicit ExecuteManipulation_Result_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->error_code = 0l;
      this->message = "";
    }
  }

  explicit ExecuteManipulation_Result_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->error_code = 0l;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _error_code_type =
    int32_t;
  _error_code_type error_code;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__error_code(
    const int32_t & _arg)
  {
    this->error_code = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Result
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Result
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_Result_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->error_code != other.error_code) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_Result_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_Result_

// alias to use template instance with default allocator
using ExecuteManipulation_Result =
  moon_warehouse_interfaces::action::ExecuteManipulation_Result_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces


#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Feedback __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Feedback __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_Feedback_
{
  using Type = ExecuteManipulation_Feedback_<ContainerAllocator>;

  explicit ExecuteManipulation_Feedback_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->stage = "";
      this->progress = 0.0f;
    }
  }

  explicit ExecuteManipulation_Feedback_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stage(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->stage = "";
      this->progress = 0.0f;
    }
  }

  // field types and members
  using _stage_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _stage_type stage;
  using _progress_type =
    float;
  _progress_type progress;

  // setters for named parameter idiom
  Type & set__stage(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->stage = _arg;
    return *this;
  }
  Type & set__progress(
    const float & _arg)
  {
    this->progress = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Feedback
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_Feedback
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_Feedback_ & other) const
  {
    if (this->stage != other.stage) {
      return false;
    }
    if (this->progress != other.progress) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_Feedback_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_Feedback_

// alias to use template instance with default allocator
using ExecuteManipulation_Feedback =
  moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces


// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"
// Member 'goal'
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_SendGoal_Request_
{
  using Type = ExecuteManipulation_SendGoal_Request_<ContainerAllocator>;

  explicit ExecuteManipulation_SendGoal_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init),
    goal(_init)
  {
    (void)_init;
  }

  explicit ExecuteManipulation_SendGoal_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init),
    goal(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;
  using _goal_type =
    moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator>;
  _goal_type goal;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }
  Type & set__goal(
    const moon_warehouse_interfaces::action::ExecuteManipulation_Goal_<ContainerAllocator> & _arg)
  {
    this->goal = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_SendGoal_Request_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    if (this->goal != other.goal) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_SendGoal_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_SendGoal_Request_

// alias to use template instance with default allocator
using ExecuteManipulation_SendGoal_Request =
  moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces


// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_SendGoal_Response_
{
  using Type = ExecuteManipulation_SendGoal_Response_<ContainerAllocator>;

  explicit ExecuteManipulation_SendGoal_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  explicit ExecuteManipulation_SendGoal_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  // field types and members
  using _accepted_type =
    bool;
  _accepted_type accepted;
  using _stamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _stamp_type stamp;

  // setters for named parameter idiom
  Type & set__accepted(
    const bool & _arg)
  {
    this->accepted = _arg;
    return *this;
  }
  Type & set__stamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->stamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_SendGoal_Response_ & other) const
  {
    if (this->accepted != other.accepted) {
      return false;
    }
    if (this->stamp != other.stamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_SendGoal_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_SendGoal_Response_

// alias to use template instance with default allocator
using ExecuteManipulation_SendGoal_Response =
  moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace moon_warehouse_interfaces
{

namespace action
{

struct ExecuteManipulation_SendGoal
{
  using Request = moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request;
  using Response = moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response;
};

}  // namespace action

}  // namespace moon_warehouse_interfaces


// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_GetResult_Request_
{
  using Type = ExecuteManipulation_GetResult_Request_<ContainerAllocator>;

  explicit ExecuteManipulation_GetResult_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init)
  {
    (void)_init;
  }

  explicit ExecuteManipulation_GetResult_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_GetResult_Request_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_GetResult_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_GetResult_Request_

// alias to use template instance with default allocator
using ExecuteManipulation_GetResult_Request =
  moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces


// Include directives for member types
// Member 'result'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_GetResult_Response_
{
  using Type = ExecuteManipulation_GetResult_Response_<ContainerAllocator>;

  explicit ExecuteManipulation_GetResult_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
    }
  }

  explicit ExecuteManipulation_GetResult_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
    }
  }

  // field types and members
  using _status_type =
    int8_t;
  _status_type status;
  using _result_type =
    moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator>;
  _result_type result;

  // setters for named parameter idiom
  Type & set__status(
    const int8_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__result(
    const moon_warehouse_interfaces::action::ExecuteManipulation_Result_<ContainerAllocator> & _arg)
  {
    this->result = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_GetResult_Response_ & other) const
  {
    if (this->status != other.status) {
      return false;
    }
    if (this->result != other.result) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_GetResult_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_GetResult_Response_

// alias to use template instance with default allocator
using ExecuteManipulation_GetResult_Response =
  moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace moon_warehouse_interfaces
{

namespace action
{

struct ExecuteManipulation_GetResult
{
  using Request = moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request;
  using Response = moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response;
};

}  // namespace action

}  // namespace moon_warehouse_interfaces


// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"
// Member 'feedback'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage __attribute__((deprecated))
#else
# define DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage __declspec(deprecated)
#endif

namespace moon_warehouse_interfaces
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct ExecuteManipulation_FeedbackMessage_
{
  using Type = ExecuteManipulation_FeedbackMessage_<ContainerAllocator>;

  explicit ExecuteManipulation_FeedbackMessage_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init),
    feedback(_init)
  {
    (void)_init;
  }

  explicit ExecuteManipulation_FeedbackMessage_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init),
    feedback(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;
  using _feedback_type =
    moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator>;
  _feedback_type feedback;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }
  Type & set__feedback(
    const moon_warehouse_interfaces::action::ExecuteManipulation_Feedback_<ContainerAllocator> & _arg)
  {
    this->feedback = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> *;
  using ConstRawPtr =
    const moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage
    std::shared_ptr<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecuteManipulation_FeedbackMessage_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    if (this->feedback != other.feedback) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecuteManipulation_FeedbackMessage_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecuteManipulation_FeedbackMessage_

// alias to use template instance with default allocator
using ExecuteManipulation_FeedbackMessage =
  moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace moon_warehouse_interfaces

#include "action_msgs/srv/cancel_goal.hpp"
#include "action_msgs/msg/goal_info.hpp"
#include "action_msgs/msg/goal_status_array.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

struct ExecuteManipulation
{
  /// The goal message defined in the action definition.
  using Goal = moon_warehouse_interfaces::action::ExecuteManipulation_Goal;
  /// The result message defined in the action definition.
  using Result = moon_warehouse_interfaces::action::ExecuteManipulation_Result;
  /// The feedback message defined in the action definition.
  using Feedback = moon_warehouse_interfaces::action::ExecuteManipulation_Feedback;

  struct Impl
  {
    /// The send_goal service using a wrapped version of the goal message as a request.
    using SendGoalService = moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal;
    /// The get_result service using a wrapped version of the result message as a response.
    using GetResultService = moon_warehouse_interfaces::action::ExecuteManipulation_GetResult;
    /// The feedback message with generic fields which wraps the feedback message.
    using FeedbackMessage = moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage;

    /// The generic service to cancel a goal.
    using CancelGoalService = action_msgs::srv::CancelGoal;
    /// The generic message for the status of a goal.
    using GoalStatusMessage = action_msgs::msg::GoalStatusArray;
  };
};

typedef struct ExecuteManipulation ExecuteManipulation;

}  // namespace action

}  // namespace moon_warehouse_interfaces

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_HPP_
