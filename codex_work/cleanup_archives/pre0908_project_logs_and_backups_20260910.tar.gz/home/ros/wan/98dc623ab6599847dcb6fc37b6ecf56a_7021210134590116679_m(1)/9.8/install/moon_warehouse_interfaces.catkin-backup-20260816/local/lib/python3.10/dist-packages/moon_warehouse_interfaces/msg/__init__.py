from moon_warehouse_interfaces.msg._detection2_d import Detection2D  # noqa: F401
from moon_warehouse_interfaces.msg._detection2_d_array import Detection2DArray  # noqa: F401
