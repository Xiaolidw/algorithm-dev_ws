// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from moon_warehouse_interfaces:msg/Detection2D.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__STRUCT_H_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'class_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/Detection2D in the package moon_warehouse_interfaces.
/**
  * Bounding box and classification result for one image target.
 */
typedef struct moon_warehouse_interfaces__msg__Detection2D
{
  std_msgs__msg__Header header;
  uint32_t id;
  rosidl_runtime_c__String class_name;
  float confidence;
  uint32_t x;
  uint32_t y;
  uint32_t width;
  uint32_t height;
  float center_x;
  float center_y;
} moon_warehouse_interfaces__msg__Detection2D;

// Struct for a sequence of moon_warehouse_interfaces__msg__Detection2D.
typedef struct moon_warehouse_interfaces__msg__Detection2D__Sequence
{
  moon_warehouse_interfaces__msg__Detection2D * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__msg__Detection2D__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__STRUCT_H_
