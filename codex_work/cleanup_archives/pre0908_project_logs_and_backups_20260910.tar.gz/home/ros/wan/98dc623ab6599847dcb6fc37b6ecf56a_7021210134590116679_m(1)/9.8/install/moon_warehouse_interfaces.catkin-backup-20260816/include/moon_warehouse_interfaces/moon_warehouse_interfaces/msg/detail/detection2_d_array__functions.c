// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from moon_warehouse_interfaces:msg/Detection2DArray.idl
// generated code does not contain a copyright notice
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `detections`
#include "moon_warehouse_interfaces/msg/detail/detection2_d__functions.h"

bool
moon_warehouse_interfaces__msg__Detection2DArray__init(moon_warehouse_interfaces__msg__Detection2DArray * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    moon_warehouse_interfaces__msg__Detection2DArray__fini(msg);
    return false;
  }
  // detections
  if (!moon_warehouse_interfaces__msg__Detection2D__Sequence__init(&msg->detections, 0)) {
    moon_warehouse_interfaces__msg__Detection2DArray__fini(msg);
    return false;
  }
  return true;
}

void
moon_warehouse_interfaces__msg__Detection2DArray__fini(moon_warehouse_interfaces__msg__Detection2DArray * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // detections
  moon_warehouse_interfaces__msg__Detection2D__Sequence__fini(&msg->detections);
}

bool
moon_warehouse_interfaces__msg__Detection2DArray__are_equal(const moon_warehouse_interfaces__msg__Detection2DArray * lhs, const moon_warehouse_interfaces__msg__Detection2DArray * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // detections
  if (!moon_warehouse_interfaces__msg__Detection2D__Sequence__are_equal(
      &(lhs->detections), &(rhs->detections)))
  {
    return false;
  }
  return true;
}

bool
moon_warehouse_interfaces__msg__Detection2DArray__copy(
  const moon_warehouse_interfaces__msg__Detection2DArray * input,
  moon_warehouse_interfaces__msg__Detection2DArray * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // detections
  if (!moon_warehouse_interfaces__msg__Detection2D__Sequence__copy(
      &(input->detections), &(output->detections)))
  {
    return false;
  }
  return true;
}

moon_warehouse_interfaces__msg__Detection2DArray *
moon_warehouse_interfaces__msg__Detection2DArray__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  moon_warehouse_interfaces__msg__Detection2DArray * msg = (moon_warehouse_interfaces__msg__Detection2DArray *)allocator.allocate(sizeof(moon_warehouse_interfaces__msg__Detection2DArray), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(moon_warehouse_interfaces__msg__Detection2DArray));
  bool success = moon_warehouse_interfaces__msg__Detection2DArray__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
moon_warehouse_interfaces__msg__Detection2DArray__destroy(moon_warehouse_interfaces__msg__Detection2DArray * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    moon_warehouse_interfaces__msg__Detection2DArray__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__init(moon_warehouse_interfaces__msg__Detection2DArray__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  moon_warehouse_interfaces__msg__Detection2DArray * data = NULL;

  if (size) {
    data = (moon_warehouse_interfaces__msg__Detection2DArray *)allocator.zero_allocate(size, sizeof(moon_warehouse_interfaces__msg__Detection2DArray), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = moon_warehouse_interfaces__msg__Detection2DArray__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        moon_warehouse_interfaces__msg__Detection2DArray__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__fini(moon_warehouse_interfaces__msg__Detection2DArray__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      moon_warehouse_interfaces__msg__Detection2DArray__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

moon_warehouse_interfaces__msg__Detection2DArray__Sequence *
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  moon_warehouse_interfaces__msg__Detection2DArray__Sequence * array = (moon_warehouse_interfaces__msg__Detection2DArray__Sequence *)allocator.allocate(sizeof(moon_warehouse_interfaces__msg__Detection2DArray__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = moon_warehouse_interfaces__msg__Detection2DArray__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__destroy(moon_warehouse_interfaces__msg__Detection2DArray__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    moon_warehouse_interfaces__msg__Detection2DArray__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__are_equal(const moon_warehouse_interfaces__msg__Detection2DArray__Sequence * lhs, const moon_warehouse_interfaces__msg__Detection2DArray__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!moon_warehouse_interfaces__msg__Detection2DArray__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
moon_warehouse_interfaces__msg__Detection2DArray__Sequence__copy(
  const moon_warehouse_interfaces__msg__Detection2DArray__Sequence * input,
  moon_warehouse_interfaces__msg__Detection2DArray__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(moon_warehouse_interfaces__msg__Detection2DArray);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    moon_warehouse_interfaces__msg__Detection2DArray * data =
      (moon_warehouse_interfaces__msg__Detection2DArray *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!moon_warehouse_interfaces__msg__Detection2DArray__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          moon_warehouse_interfaces__msg__Detection2DArray__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!moon_warehouse_interfaces__msg__Detection2DArray__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
