// generated from rosidl_generator_c/resource/idl.h.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_H_
#define MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_H_

#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.h"
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__functions.h"
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__type_support.h"

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_H_
