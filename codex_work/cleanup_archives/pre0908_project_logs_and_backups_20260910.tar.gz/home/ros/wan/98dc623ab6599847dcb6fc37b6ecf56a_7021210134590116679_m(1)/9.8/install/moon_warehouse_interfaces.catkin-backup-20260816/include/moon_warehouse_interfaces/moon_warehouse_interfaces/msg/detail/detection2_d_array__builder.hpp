// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from moon_warehouse_interfaces:msg/Detection2DArray.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__BUILDER_HPP_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace moon_warehouse_interfaces
{

namespace msg
{

namespace builder
{

class Init_Detection2DArray_detections
{
public:
  explicit Init_Detection2DArray_detections(::moon_warehouse_interfaces::msg::Detection2DArray & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::msg::Detection2DArray detections(::moon_warehouse_interfaces::msg::Detection2DArray::_detections_type arg)
  {
    msg_.detections = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2DArray msg_;
};

class Init_Detection2DArray_header
{
public:
  Init_Detection2DArray_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Detection2DArray_detections header(::moon_warehouse_interfaces::msg::Detection2DArray::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Detection2DArray_detections(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2DArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::msg::Detection2DArray>()
{
  return moon_warehouse_interfaces::msg::builder::Init_Detection2DArray_header();
}

}  // namespace moon_warehouse_interfaces

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__BUILDER_HPP_
