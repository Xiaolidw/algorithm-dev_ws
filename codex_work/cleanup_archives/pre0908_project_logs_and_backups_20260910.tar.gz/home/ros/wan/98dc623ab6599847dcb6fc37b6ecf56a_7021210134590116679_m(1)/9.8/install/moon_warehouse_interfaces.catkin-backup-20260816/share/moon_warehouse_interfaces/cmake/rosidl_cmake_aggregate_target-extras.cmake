# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target moon_warehouse_interfaces::moon_warehouse_interfaces
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${moon_warehouse_interfaces_TARGETS}.
if(moon_warehouse_interfaces_TARGETS AND NOT TARGET moon_warehouse_interfaces::moon_warehouse_interfaces)
  add_library(moon_warehouse_interfaces::moon_warehouse_interfaces INTERFACE IMPORTED)
  set_target_properties(moon_warehouse_interfaces::moon_warehouse_interfaces PROPERTIES
    INTERFACE_LINK_LIBRARIES "${moon_warehouse_interfaces_TARGETS}")
endif()
