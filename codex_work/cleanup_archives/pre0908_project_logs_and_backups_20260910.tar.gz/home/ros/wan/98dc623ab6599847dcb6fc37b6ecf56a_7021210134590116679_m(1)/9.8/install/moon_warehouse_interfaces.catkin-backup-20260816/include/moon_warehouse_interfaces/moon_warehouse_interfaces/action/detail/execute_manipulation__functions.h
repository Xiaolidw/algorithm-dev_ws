// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__FUNCTIONS_H_
#define MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "moon_warehouse_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.h"

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__init(moon_warehouse_interfaces__action__ExecuteManipulation_Goal * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Goal * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Goal *
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Goal * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Goal * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Goal * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Goal * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Goal * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__init(moon_warehouse_interfaces__action__ExecuteManipulation_Result * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Result__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Result * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Result *
moon_warehouse_interfaces__action__ExecuteManipulation_Result__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Result__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Result * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Result * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Result * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Result * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Result * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__init(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback *
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__init(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__fini(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request *
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__init(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__fini(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response *
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__init(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__fini(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request *
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__init(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__fini(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response *
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence * output);

/// Initialize action/ExecuteManipulation message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage
 * )) before or use
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__init(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * msg);

/// Finalize action/ExecuteManipulation message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__fini(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * msg);

/// Create action/ExecuteManipulation message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage *
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__create();

/// Destroy action/ExecuteManipulation message.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * msg);

/// Check for action/ExecuteManipulation message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * rhs);

/// Copy a action/ExecuteManipulation message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * output);

/// Initialize array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the number of elements and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__init(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * array, size_t size);

/// Finalize array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__fini(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * array);

/// Create array of action/ExecuteManipulation messages.
/**
 * It allocates the memory for the array and calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence *
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__create(size_t size);

/// Destroy array of action/ExecuteManipulation messages.
/**
 * It calls
 * moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
void
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__destroy(moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * array);

/// Check for action/ExecuteManipulation message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__are_equal(const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * lhs, const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * rhs);

/// Copy an array of action/ExecuteManipulation messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
bool
moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence__copy(
  const moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * input,
  moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__FUNCTIONS_H_
