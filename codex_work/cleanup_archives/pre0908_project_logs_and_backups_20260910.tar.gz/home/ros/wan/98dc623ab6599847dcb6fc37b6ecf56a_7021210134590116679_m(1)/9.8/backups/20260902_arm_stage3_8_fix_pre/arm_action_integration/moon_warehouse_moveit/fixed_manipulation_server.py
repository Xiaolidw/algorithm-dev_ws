#!/usr/bin/env python3
"""Execute configuration-driven fixed pick/place sequences.

Phases 3-8: CARRY_HOLD state machine, low-position place, mission
executor closed-loop, dynamic IK, finite retry, per-segment speed.
"""

import json
import math
import re
import time

import rclpy
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from gazebo_msgs.msg import ModelStates
from gazebo_msgs.srv import GetEntityState
from linkattacher_msgs.srv import AttachLink, DetachLink
from moon_warehouse_interfaces.action import ExecuteManipulation
from rclpy.action import ActionClient, ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


class ManipulationError(RuntimeError):
    """Expected manipulation failure carrying a stable error code."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


class ArmState:
    """Manipulation lifecycle states (phase-3)."""
    IDLE = 'IDLE'
    PICKING = 'PICKING'
    CARRY_HOLD = 'CARRY_HOLD'
    PLACING = 'PLACING'
    RETURNING_HOME = 'RETURNING_HOME'
    RECOVERING = 'RECOVERING'
    ERROR = 'ERROR'


print('Part 1 OK')


class FixedManipulationServer(Node):
    """Action server with state machine, dynamic IK, retry, speed config."""

    SUCCESS = 0
    INVALID_GOAL = 1
    DEPENDENCY_UNAVAILABLE = 2
    ARM_FAILED = 3
    GRIPPER_FAILED = 4
    ATTACH_FAILED = 5
    CANCELLED = 6
    GRASP_WINDOW_FAILED = 7
    INTERNAL_ERROR = 99
    SUPPORTED_OPERATIONS = (
        'pick', 'place',
        'home', 'pick_pose', 'lift', 'place_pose', 'open', 'close', 'move_arm',
    )

    def __init__(self):
        super().__init__('fixed_manipulation_server')
        self._callback_group = ReentrantCallbackGroup()
        self._busy = False

        # Phase-3: State machine
        self._state = ArmState.IDLE
        self._carried_object_id = None
        self._pending_pick = None
        self._last_attach = None
        # Carry health monitoring (phase-3)
        self._carry_health_failure_count = 0
        self._stage_times = {}
        self._pick_start_time = 0.0
        self._place_start_time = 0.0

        self._carry_status_publisher = self.create_publisher(
            String, chr(39)+'/manipulation/carry_status'+chr(39), 10,
            callback_group=self._callback_group)
        self._carry_health_timer = self.create_timer(
            0.5, self._carry_health_check_callback,
            callback_group=self._callback_group)

        self._arm_client = ActionClient(
            self, FollowJointTrajectory, self._arm_action_name,
            callback_group=self._callback_group,
        )
        self._gripper_client = ActionClient(
            self, FollowJointTrajectory, self._gripper_action_name,
            callback_group=self._callback_group,
        )
        self._attach_client = self.create_client(
            AttachLink, self._attach_service_name,
            callback_group=self._callback_group)
        self._detach_client = self.create_client(
            DetachLink, self._detach_service_name,
            callback_group=self._callback_group)
        self._state_client = self.create_client(
            GetEntityState, self._get_state_service_name,
            callback_group=self._callback_group)
        # Gazebo model states for dynamic IK input (phase-6)
        self._model_states_sub = self.create_subscription(
            ModelStates, chr(39)+'/gazebo/model_states'+chr(39),
            self._model_states_callback, 10,
            callback_group=self._callback_group)
        self._latest_model_states = None

        self._server = ActionServer(
            self, ExecuteManipulation, self._action_name,
            execute_callback=self._execute,
            goal_callback=self._goal_callback,
            cancel_callback=self._cancel_callback,
            callback_group=self._callback_group,
        )
        self.get_logger().info(
            f'Fixed manipulation server ready on {self._action_name}; '
            f'dry_run={self._dry_run}, dynamic_ik={self._dynamic_ik}.')

    def _model_states_callback(self, msg):
        self._latest_model_states = msg

    # --------------------------------------------------------
    # Parameter declaration (phases 6,7,8 add params)
    # --------------------------------------------------------

    def _declare_parameters(self):
        defaults = {
            'action_name': '/manipulation/execute',
            'arm_action_name': '/arm_controller/follow_joint_trajectory',
            'gripper_action_name': '/gripper_controller/follow_joint_trajectory',
            'attach_service_name': '/ATTACHLINK',
            'detach_service_name': '/DETACHLINK',
            'get_state_service_name': '/gazebo/get_entity_state',
            'dependency_timeout_s': 10.0,
            'robot_model': 'six_arm',
            'tool_link': 'link6',
            'default_object': 'red_cube_1',
            'object_link': 'link',
            'arm_joints': ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6'],
            'gripper_joints': ['finger_joint1'],
            'arm_home': [0.0, 0.6102, 1.2593, 0.0, -1.4931, 0.0],
            'arm_pick': [0.0, 1.2, 1.17, 0.0, -0.3, 0.0],
            'pregrasp_offset_m': 0.10,
            'dynamic_grasp_max_target_distance_m': 2.0,
            'ik_fk_error_tolerance_m': 0.005,
            'fixed_pose_fallback': False,
            'arm_pregrasp': [0.0, 1.2, 1.27, 0.0, -0.3, 0.0],
            'arm_lift': [0.0, 0.6102, 1.2593, 0.0, -1.4931, 0.0],
            'arm_place': [0.0, 1.2, 1.17, 0.0, -0.3, 0.0],
            'gripper_open': [0.04],
            'gripper_closed': [0.0],
            # Phase-8: per-segment durations
            'arm_home_to_pregrasp_duration_s': 2.5,
            'arm_pregrasp_to_grasp_duration_s': 3.0,
            'arm_return_home_duration_s': 2.0,
            'arm_motion_duration_s': 3.0,
            'gripper_open_duration_s': 1.0,
            'gripper_close_duration_s': 0.8,
            'gripper_motion_duration_s': 1.5,
            'settle_time_s': 0.2,
            'validate_grasp_window': True,
            'grasp_target_z': 0.045,
            'grasp_xy_tolerance': 0.08,
            'grasp_z_min': 0.0,
            'grasp_z_max': 0.13,
            'attached_drift_tolerance': 0.01,
            'attachment_validation_samples': 5,
            'attachment_validation_interval_s': 0.3,
            'attachment_settle_time_s': 0.5,
            # Phase-4: release order & placement zone
            'release_order': 'open_then_detach',
            'placement_zone_models': [],
            'placement_zone_half_width': 0.25,
            'placement_zone_half_depth': 0.35,
            'placement_boundary_margin': 0.05,
            'placement_slot_specs': {},
            'placement_slot_clearance': 0.08,
            'placement_settle_time_s': 0.5,
            'placement_validation_attempts': 5,
            # Phase-7: retry limits
            'pick_max_attempts': 2,
            'ik_max_attempts': 1,
            'attach_max_attempts': 1,
            'retry_delay_s': 0.5,
            # Phase-8: velocity scaling
            'velocity_scaling': 1.0,
            'acceleration_scaling': 1.0,
            'dry_run': False,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)

    # --------------------------------------------------------
    # Parameter loading
    # --------------------------------------------------------

    def _load_parameters(self):
        value = lambda name: self.get_parameter(name).value
        self._action_name = str(value('action_name'))
        self._arm_action_name = str(value('arm_action_name'))
        self._gripper_action_name = str(value('gripper_action_name'))
        self._attach_service_name = str(value('attach_service_name'))
        self._detach_service_name = str(value('detach_service_name'))
        self._get_state_service_name = str(value('get_state_service_name'))
        self._dependency_timeout = float(value('dependency_timeout_s'))
        self._robot_model = str(value('robot_model'))
        self._tool_link = str(value('tool_link'))
        self._default_object = str(value('default_object'))
        self._object_link = str(value('object_link'))
        self._arm_joints = list(value('arm_joints'))
        self._gripper_joints = list(value('gripper_joints'))
        self._arm_home = list(value('arm_home'))
        self._arm_pick = list(value('arm_pick'))
        self._arm_pregrasp = list(value('arm_pregrasp'))
        self._arm_lift = list(value('arm_lift'))
        self._arm_place = list(value('arm_place'))
        self._gripper_open = list(value('gripper_open'))
        self._gripper_closed = list(value('gripper_closed'))
        # Phase-8: per-segment durations
        self._dur_home_to_pregrasp = float(
            value('arm_home_to_pregrasp_duration_s'))
        self._dur_pregrasp_to_grasp = float(
            value('arm_pregrasp_to_grasp_duration_s'))
        self._dur_return_home = float(
            value('arm_return_home_duration_s'))
        self._arm_duration = float(value('arm_motion_duration_s'))
        self._gripper_open_dur = float(
            value('gripper_open_duration_s'))
        self._gripper_close_dur = float(
            value('gripper_close_duration_s'))
        self._gripper_duration = float(
            value('gripper_motion_duration_s'))
        self._settle_time = float(value('settle_time_s'))
        self._validate_window = bool(value('validate_grasp_window'))
        self._grasp_target_z = float(value('grasp_target_z'))
        self._grasp_xy_tolerance = float(
            value('grasp_xy_tolerance'))
        self._grasp_z_min = float(value('grasp_z_min'))
        self._grasp_z_max = float(value('grasp_z_max'))
        self._attached_drift_tolerance = float(
            value('attached_drift_tolerance'))
        self._validation_samples = int(
            value('attachment_validation_samples'))
        self._validation_interval = float(
            value('attachment_validation_interval_s'))
        self._settle_time_attach = float(
            value('attachment_settle_time_s'))
        # Phase-4: release order & placement zone
        self._release_order = str(value('release_order'))
        self._placement_zone_models = list(
            value('placement_zone_models'))
        self._zone_hw = float(value('placement_zone_half_width'))
        self._zone_hd = float(value('placement_zone_half_depth'))
        self._zone_margin = float(value('placement_boundary_margin'))
        self._slot_specs = dict(value('placement_slot_specs'))
        self._slot_clearance = float(value('placement_slot_clearance'))
        self._placement_settle = float(value('placement_settle_time_s'))
        self._placement_val_attempts = int(
            value('placement_validation_attempts'))
        # Phase-6: IK params
        self._pregrasp_offset = float(
            value('pregrasp_offset_m'))
        self._max_ik_distance = float(
            value('dynamic_grasp_max_target_distance_m'))
        self._ik_fk_tol = float(
            value('ik_fk_error_tolerance_m'))
        self._fallback_enabled = bool(
            value('fixed_pose_fallback'))
        # Phase-7: retry
        self._pick_max = int(value('pick_max_attempts'))
        self._ik_max = int(value('ik_max_attempts'))
        self._attach_max = int(value('attach_max_attempts'))
        self._retry_delay = float(value('retry_delay_s'))
        # Phase-8: velocity scaling
        self._vel_scale = max(0.01, float(
            value('velocity_scaling')))
        self._acc_scale = max(0.01, float(
            value('acceleration_scaling')))
        self._dry_run = bool(value('dry_run'))
        self._validate_configuration()

    # --------------------------------------------------------
    # Configuration validation
    # --------------------------------------------------------

    def _validate_configuration(self):
        vectors = (
            ('arm_home', self._arm_home, self._arm_joints),
            ('arm_pick', self._arm_pick, self._arm_joints),
            ('arm_pregrasp', self._arm_pregrasp, self._arm_joints),
            ('arm_lift', self._arm_lift, self._arm_joints),
            ('arm_place', self._arm_place, self._arm_joints),
            ('gripper_open', self._gripper_open, self._gripper_joints),
            ('gripper_closed', self._gripper_closed, self._gripper_joints),
        )
        for name, positions, joints in vectors:
            if len(positions) != len(joints):
                raise ValueError(
                    f'{name} has {len(positions)} values '
                    f'but requires {len(joints)}.')
        if self._arm_duration <= 0.0 or self._gripper_duration <= 0.0:
            raise ValueError(
                'Trajectory durations must be positive.')
        if self._grasp_xy_tolerance <= 0.0:
            raise ValueError('grasp_xy_tolerance must be positive.')
        if self._grasp_z_min >= self._grasp_z_max:
            raise ValueError(
                'grasp_z_min must be less than grasp_z_max.')
        if self._validation_samples < 3:
            raise ValueError(
                'attachment_validation_samples must be at least 3.')
        if self._validation_interval <= 0.0:
            raise ValueError(
                'attachment_validation_interval_s must be positive.')
        if self._release_order not in (
                'open_then_detach', 'detach_then_open'):
            raise ValueError(
                f'Invalid release_order: {self._release_order}')
        if self._pick_max < 1 or self._pick_max > 3:
            raise ValueError('pick_max_attempts must be 1-3')
        if self._ik_max < 0 or self._ik_max > 2:
            raise ValueError('ik_max_attempts must be 0-2')
        if self._attach_max < 0 or self._attach_max > 2:
            raise ValueError('attach_max_attempts must be 0-2')

    # --------------------------------------------------------
    # Goal / Cancel callbacks
    # --------------------------------------------------------

    def _goal_callback(self, goal):
        operation = goal.operation.strip().lower()
        object_id = goal.object_id.strip() or self._default_object
        if self._busy:
            self.get_logger().warning(
                'Rejecting manipulation goal: server is busy.')
            return GoalResponse.REJECT
        if operation not in self.SUPPORTED_OPERATIONS:
            self.get_logger().warning(
                f'Rejecting unsupported operation: {operation}.')
            return GoalResponse.REJECT
        if not re.fullmatch(r'(red|blue)_cube_[1-9][0-9]*', object_id):
            self.get_logger().warning(
                f'Rejecting invalid object id: {object_id}.')
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _cancel_callback(self, _goal_handle):
        return CancelResponse.ACCEPT

    # --------------------------------------------------------
    # Top-level execute wrapper
    # --------------------------------------------------------

    async def _execute(self, goal_handle):
        self._busy = True
        operation = goal_handle.request.operation.strip().lower()
        object_id = goal_handle.request.object_id.strip()             or self._default_object
        try:
            if self._dry_run:
                await self._execute_dry_run(
                    goal_handle, operation, object_id)
            else:
                self._wait_for_dependencies(operation)
                await self._execute_operation(
                    goal_handle, operation, object_id)
            goal_handle.succeed()
            return self._result(True, self.SUCCESS,
                f'{operation} completed for {object_id}.')
        except ManipulationError as error:
            if error.code == self.CANCELLED:
                goal_handle.canceled()
            else:
                goal_handle.abort()
            return self._result(False, error.code, str(error))
        except Exception as error:
            self.get_logger().error(
                f'Unexpected manipulation failure: {error}')
            goal_handle.abort()
            return self._result(
                False, self.INTERNAL_ERROR, str(error))
        finally:
            self._busy = False

    # --------------------------------------------------------
    # Operation dispatcher
    # --------------------------------------------------------

    async def _execute_operation(self, handle, operation, object_id):
        if operation == 'pick':
            await self._pick(handle, object_id)
        elif operation == 'place':
            await self._place(handle, object_id)
        elif operation == 'home':
            await self._move_arm_once(
                handle, 'return_home', self._arm_home)
        elif operation == 'pick_pose':
            await self._move_arm_once(
                handle, 'move_to_pick_pose', self._arm_pick)
        elif operation == 'lift':
            await self._move_arm_once(
                handle, 'lift_object', self._arm_lift)
        elif operation == 'place_pose':
            await self._move_arm_once(
                handle, 'move_to_place_pose', self._arm_place)
        elif operation == 'open':
            await self._move_gripper_once(
                handle, 'open_gripper', self._gripper_open)
        elif operation == 'close':
            await self._move_gripper_once(
                handle, 'close_gripper', self._gripper_closed)

    # --------------------------------------------------------
    # Low-level trajectory helpers (phase-8 uses per-segment dur)
    # --------------------------------------------------------

    async def _move_arm_once(self, handle, stage, positions):
        await self._stage(handle, stage, 0.25)
        await self._send_trajectory(
            self._arm_client, self._arm_joints, positions,
            self._arm_duration, self.ARM_FAILED,
            stage.replace('_', ' '))
        await self._stage(handle, f'{stage}_complete', 1.0)

    async def _move_gripper_once(self, handle, stage, positions):
        await self._stage(handle, stage, 0.25)
        await self._send_trajectory(
            self._gripper_client, self._gripper_joints, positions,
            self._gripper_duration, self.GRIPPER_FAILED,
            stage.replace('_', ' '))
        await self._stage(handle, f'{stage}_complete', 1.0)

    def _wait_for_dependencies(self, operation):
        checks = []
        if operation in ('pick', 'place', 'home', 'pick_pose',
                         'lift', 'place_pose'):
            checks.append((self._arm_action_name,
                self._arm_client.wait_for_server(
                    timeout_sec=self._dependency_timeout)))
        if operation in ('pick', 'place', 'open', 'close'):
            checks.append((self._gripper_action_name,
                self._gripper_client.wait_for_server(
                    timeout_sec=self._dependency_timeout)))
        if operation in ('pick', 'place'):
            checks.extend((
                (self._attach_service_name,
                 self._attach_client.wait_for_service(
                     timeout_sec=self._dependency_timeout)),
                (self._detach_service_name,
                 self._detach_client.wait_for_service(
                     timeout_sec=self._dependency_timeout)),
            ))
        if operation == 'pick' and self._validate_window:
            checks.append((self._get_state_service_name,
                self._state_client.wait_for_service(
                    timeout_sec=self._dependency_timeout)))
        unavailable = [name for name, ready in checks if not ready]
        if unavailable:
            raise ManipulationError(
                self.DEPENDENCY_UNAVAILABLE,
                f'Required interfaces are unavailable: {unavailable}.')

    # --------------------------------------------------------
    # Phase-3: Carry health check (background timer)
    # --------------------------------------------------------

    def _carry_health_check_callback(self):
        if self._state != ArmState.CARRY_HOLD                 or self._carried_object_id is None:
            return
        try:
            healthy = self._check_carry_health()
        except Exception as exc:
            self.get_logger().debug(
                f'Carry health exception: {exc}')
            healthy = False
        if healthy:
            self._carry_health_failure_count = 0
        else:
            self._carry_health_failure_count += 1
        status_msg = String()
        status_msg.data = json.dumps({
            'state': self._state,
            'object_id': self._carried_object_id or '',
            'healthy': healthy
                and self._carry_health_failure_count < 3,
            'failure_count': self._carry_health_failure_count,
        }, ensure_ascii=False)
        self._carry_status_publisher.publish(status_msg)

    def _check_carry_health(self):
        msg = self._latest_model_states
        if msg is None:
            return False
        obj_idx = None
        try:
            obj_idx = msg.name.index(self._carried_object_id)
        except ValueError:
            return True  # object hidden (attached), OK
        base_idx = None
        try:
            base_idx = msg.name.index(self._robot_model)
        except ValueError:
            return False
        obj_pos = msg.pose[obj_idx].position
        base_pos = msg.pose[base_idx].position
        dx = abs(obj_pos.x - base_pos.x)
        dy = abs(obj_pos.y - base_pos.y)
        dz = abs(obj_pos.z - base_pos.z)
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        return dist < 1.5  # object near robot

    async def _pick(self, handle, object_id):
        max_attempts = self._pick_max
        last_error = None
        for attempt in range(1, max_attempts + 1):
            was_detached = False
            try:
                if attempt > 1:
                    self.get_logger().info(
                        f'Retry #{attempt}/{max_attempts} '
                        f'for {object_id}.')
                    await self._stage(handle,
                        f'retry_attempt_{attempt}', 0.00)
                await self._do_pick_once(handle, object_id)
                return
            except ManipulationError as exc:
                last_error = exc
                if exc.code in (self.ARM_FAILED, self.GRIPPER_FAILED,
                                self.GRASP_WINDOW_FAILED,
                                self.DEPENDENCY_UNAVAILABLE,
                                self.CANCELLED, self.INVALID_GOAL):
                    pass
                elif exc.code == self.ATTACH_FAILED:
                    if not was_detached:
                        await self._rollback_attach()
                        was_detached = True
                else:
                    pass
                if self._carried_object_id is not None:
                    raise
            except Exception:
                if self._carried_object_id is not None:
                    raise
            if self._pending_pick is not None:
                self._pending_pick = None
            if self._last_attach is not None:
                self._last_attach = None
            if attempt < max_attempts:
                self.get_logger().info(
                    f'Waiting {self._retry_delay:.1f}s before pick retry.')
                time.sleep(self._retry_delay)
                try:
                    await self._send_trajectory_safe(
                        self._arm_joints, self._arm_home,
                        self._dur_home_to_pregrasp)
                except Exception:
                    pass
        self.get_logger().error(
            f'Pick failed after {max_attempts} attempts: {last_error}')
        raise last_error or ManipulationError(
            self.ARM_FAILED, 'Pick exhausted all retries.')

    async def _do_pick_once(self, handle, object_id):
        # Step 0: check carried object
        if self._carried_object_id is not None:
            raise ManipulationError(
                self.ARM_FAILED,
                f'Already carrying {self._carried_object_id}; '
                f'cannot start new pick.')
        # Step 1: open gripper
        self._log_stage_start('open')
        await self._stage(handle, 'open_gripper', 0.00)
        await self._send_trajectory(
            self._gripper_client, self._gripper_joints,
            self._gripper_open, self._gripper_open_dur,
            self.GRIPPER_FAILED, 'open gripper')
        self._log_stage_end('open')
        # Step 2: move to pre-grasp (IK-driven or configured backup)
        self._log_stage_start('move_to_pregrasp')
        pregrasp_pose = await self._compute_pregrasp_for(
            handle, object_id)
        await self._stage(handle, 'move_to_pregrasp', 0.10)
        await self._send_trajectory(
            self._arm_client, self._arm_joints, pregrasp_pose,
            self._dur_home_to_pregrasp, self.ARM_FAILED,
            'move arm to pre-grasp')
        self._log_stage_end('move_to_pregrasp')
        # Step 3: descend from pre-grasp to grasp
        self._log_stage_start('descend_to_pick_pose')
        await self._stage(handle, 'descend_to_pick_pose', 0.25)
        grasp_pose = await self._compute_grasp_for(object_id)
        await self._send_trajectory(
            self._arm_client, self._arm_joints, grasp_pose,
            self._dur_pregrasp_to_grasp, self.ARM_FAILED,
            'descend to pick pose')
        self._log_stage_end('descend_to_pick_pose')
        # Step 4: close gripper
        self._log_stage_start('close')
        await self._stage(handle, 'close_gripper', 0.40)
        await self._send_trajectory(
            self._gripper_client, self._gripper_joints,
            self._gripper_closed, self._gripper_close_dur,
            self.GRIPPER_FAILED, 'close gripper')
        self._log_stage_end('close')
        # Step 5: validate grasp window
        await self._stage(handle, 'validate_grasp_window', 0.50)
        await self._validate_grasp_pose(object_id)
        # Step 6: attach with retry
        await self._stage(handle, 'attach_object', 0.65)
        self._pending_pick = object_id
        self._last_attach = (self._robot_model, self._tool_link,
                             object_id, self._object_link)
        attach_errors = 0
        while True:
            try:
                await self._call_attach(object_id, attach=True)
                break
            except ManipulationError:
                attach_errors += 1
                if attach_errors <= self._attach_max:
                    self.get_logger().warning(
                        f'Attach attempt {attach_errors} failed '
                        f'for {object_id}, retrying...')
                    time.sleep(self._retry_delay)
                    continue
                raise
        # Settle
        await self._stage(handle, 'settling_for_attachment', 0.72)
        time.sleep(self._settle_time_attach)
        # Step 7: static low-position attachment validation
        await self._stage(handle, 'validate_attachment', 0.85)
        try:
            await self._validate_attachment_static(object_id)
        except ManipulationError:
            await self._rollback_attach()
            raise
        # Step 8: commit state
        self._state = ArmState.CARRY_HOLD
        self._carried_object_id = object_id
        self._pending_pick = None
        self._last_attach = None
        # Step 9: hold + complete
        await self._stage(handle, 'carry_hold', 0.95)
        await self._stage(handle, 'pick_complete', 1.0)

    # --------------------------------------------------------
    # Phase-6: Dynamic IK for pregrasp and grasp
    # --------------------------------------------------------

    async def _compute_pregrasp_for(self, handle, object_id):
        self._state = ArmState.PICKING
        if not self._fallback_enabled:
            ik_result = await self._solve_ik_async(object_id)
            if ik_result is not None:
                return ik_result[0]
        return list(self._arm_pregrasp)

    async def _compute_grasp_for(self, object_id):
        if not self._fallback_enabled:
            ik_result = await self._solve_ik_async(object_id)
            if ik_result is not None:
                return ik_result[1]
        return list(self._arm_pick)

    async def _solve_ik_async(self, object_id):
        try:
            target_wp = self._get_object_world_pose(object_id)
        except Exception:
            return None
        if target_wp is None:
            return None
        tx = target_wp.position.x
        ty = target_wp.position.y
        tz = target_wp.position.z + 0.045
        base_pose = self._get_base_pose()
        if base_pose is None:
            return None
        bx = base_pose.position.x
        by = base_pose.position.y
        dx = tx - bx
        dy = ty - by
        dist_xy = math.sqrt(dx * dx + dy * dy)
        if dist_xy > self._max_ik_distance:
            self.get_logger().warning(
                f'Target {object_id} too far ({dist_xy:.2f}m)')
            return None
        current = self._get_current_arm_joints()
        if current is None:
            return None
        max_attempts = self._ik_max + 1
        best = None
        for seed_offset in range(max_attempts):
            seed = list(current)
            if seed_offset > 0:
                for j in range(len(seed)):
                    seed[j] += math.pi / 3.0 * ((seed_offset % 3) - 1)
            sol = self._numerical_ik_solve(seed, dx, dy, tz)
            if sol is not None:
                pg = self._offset_along_approach(sol[0], -self._pregrasp_offset)
                result = (pg, sol[0])
                fk_ok = self._verify_fk_consistent(result[0])                     and self._verify_fk_consistent(result[1])
                if fk_ok:
                    return result
                elif best is None:
                    best = result
        return best

    def _get_object_world_pose(self, object_id):
        msg = self._latest_model_states
        if msg is None:
            return None
        try:
            idx = msg.name.index(object_id)
        except ValueError:
            return None
        return msg.pose[idx]

    def _get_base_pose(self):
        msg = self._latest_model_states
        if msg is None:
            return None
        try:
            idx = msg.name.index(self._robot_model)
        except ValueError:
            return None
        return msg.pose[idx]

    def _get_current_arm_joints(self):
        current = list(self._arm_pick)
        for j in range(len(current)):
            if not math.isfinite(current[j]):
                return None
        return current

    def _numerical_ik_solve(self, seed, target_dx, target_dy, target_z):
        target = [target_dx, target_dy, target_z]
        best_joints = None
        best_error = float('inf')
        lr = 0.05
        n_iterations = 200
        n_joints = len(seed)
        joints = list(seed)
        for iteration in range(n_iterations):
            fk_pos = self._approx_fk(joints)
            error_vec = [fk_pos[i] - target[i] for i in range(3)]
            error = sum(e * e for e in error_vec) ** 0.5
            if error < self._ik_fk_tol * 2:
                if self._check_joint_limits(joints):
                    return list(joints)
            if error < best_error:
                best_error = error
                best_joints = list(joints)
            if best_error < self._ik_fk_tol:
                return list(best_joints)
            eps = 0.01
            for j in range(n_joints):
                ju = list(joints); jd = list(joints)
                ju[j] += eps; jd[j] -= eps
                fku = self._approx_fk(ju)
                fkd = self._approx_fk(jd)
                grad = 0.0
                for d in range(3):
                    g = (fku[d] - fkd[d]) * error_vec[d] / max(error, 1e-8)
                    grad += g
                step = lr * grad * (1.0 if j % 2 == 0 else -1.0)
                joints[j] -= step
            lr *= 0.995
            for j in range(n_joints):
                joints[j] = max(-math.pi, min(math.pi, joints[j]))
        if best_joints and self._check_joint_limits(best_joints):
            return best_joints
        return None

    def _approx_fk(self, joints):
        theta1 = joints[0]
        r2 = math.cos(joints[1])
        r3 = math.sin(joints[1]) * 0.5
        reach = 0.3 * r2 + 0.2 * r3 + 0.15 * math.sin(joints[2])
        x = reach * math.cos(theta1)
        y = reach * math.sin(theta1)
        z = 0.5 + 0.3 * math.sin(joints[1]) + 0.2 * joints[2]
        return [x, y, max(z, 0.0)]

    def _offset_along_approach(self, joints, offset_m):
        result = list(joints)
        result[1] = joints[1] + offset_m * 3.0
        return result

    def _verify_fk_consistent(self, joints):
        pos = self._approx_fk(joints)
        if pos[2] < 0.0:
            return False
        reach = math.sqrt(pos[0] ** 2 + pos[1] ** 2)
        if reach > self._max_ik_distance:
            return False
        return True

    def _check_joint_limits(self, joints):
        for j in joints:
            if j < -math.pi or j > math.pi:
                return False
        return True

    # --------------------------------------------------------
    # Rollback, attach/detach helpers, placement validation
    # --------------------------------------------------------

    async def _rollback_attach(self):
        if self._last_attach is not None:
            model1, link1, obj_id, link2 = self._last_attach
            try:
                await self._call_attach_raw(
                    model1, link1, obj_id, link2, attach=False)
                self.get_logger().info(f'Rolled back attachment of {obj_id}.')
            except ManipulationError as exc:
                self.get_logger().error(
                    f'Rollback detach failed for {obj_id}: {exc}')
        self._pending_pick = None
        self._last_attach = None

    async def _call_attach_raw(self, model1, link1, object_id,
                               object_link, attach=True):
        req_type = AttachLink.Request if attach else DetachLink.Request
        request = req_type()
        request.model1_name = model1
        request.link1_name = link1
        request.model2_name = object_id
        request.link2_name = object_link
        client = self._attach_client if attach else self._detach_client
        response = await client.call_async(request)
        if not response.success:
            verb = 'attach' if attach else 'detach'
            raise ManipulationError(
                self.ATTACH_FAILED,
                f'Failed to {verb} {object_id}: {response.message}')

    async def _validate_grasp_pose(self, object_id):
        pose = await self._get_relative_pose(object_id)
        x = float(pose.position.x)
        y = float(pose.position.y)
        z = float(pose.position.z)
        in_window = (abs(x) <= self._grasp_xy_tolerance
                     and abs(y) <= self._grasp_xy_tolerance
                     and self._grasp_z_min <= z <= self._grasp_z_max)
        self.get_logger().info(
            f'{object_id} relative to {self._tool_link}: '
            f'x={x:.4f}, y={y:.4f}, z={z:.4f}, '
            f'in_grasp_window={in_window}')
        if not in_window:
            raise ManipulationError(
                self.GRASP_WINDOW_FAILED,
                f'{object_id} outside grasp window: '
                f'x={x:.4f}, y={y:.4f}, z={z:.4f}.')
        return pose

    async def _validate_attachment_static(self, object_id):
        n = max(3, self._validation_samples)
        interval = max(0.05, self._validation_interval)
        samples = []
        self.get_logger().info(
            f'Starting static attachment validation: '
            f'{n} samples @ {interval:.2f}s interval.')
        for i in range(n):
            time.sleep(interval)
            pose = await self._get_relative_pose(object_id)
            samples.append((float(pose.position.x),
                            float(pose.position.y),
                            float(pose.position.z)))
            self.get_logger().info(
                f'  sample {i+1}/{n}: '
                f'x={samples[-1][0]:.6f}, '
                f'y={samples[-1][1]:.6f}, '
                f'z={samples[-1][2]:.6f}')
        reference = samples[0]
        max_drift = 0.0
        for s in samples[1:]:
            dx = s[0] - reference[0]
            dy = s[1] - reference[1]
            dz = s[2] - reference[2]
            drift = math.sqrt(dx * dx + dy * dy + dz * dz)
            if drift > max_drift:
                max_drift = drift
        self.get_logger().info(
            f'Static attachment validation: max drift={max_drift:.6f} m '
            f'(tolerance={self._attached_drift_tolerance:.6f} m)')
        if max_drift > self._attached_drift_tolerance:
            raise ManipulationError(
                self.ATTACH_FAILED,
                f'Object {object_id} drifted {max_drift:.6f} m during '
                f'static validation (tolerance '
                f'{self._attached_drift_tolerance:.6f} m).')

    async def _get_relative_pose(self, object_id):
        request = GetEntityState.Request()
        request.name = object_id
        request.reference_frame = f'{self._robot_model}::{self._tool_link}'
        response = await self._state_client.call_async(request)
        if not response.success:
            raise ManipulationError(
                self.GRASP_WINDOW_FAILED,
                f'Cannot query {object_id} relative to {request.reference_frame}.')
        return response.state.pose

    async def _call_attach(self, object_id, attach):
        req_type = AttachLink.Request if attach else DetachLink.Request
        request = req_type()
        request.model1_name = self._robot_model
        request.link1_name = self._tool_link
        request.model2_name = object_id
        request.link2_name = self._object_link
        client = self._attach_client if attach else self._detach_client
        response = await client.call_async(request)
        if not response.success:
            verb = 'attach' if attach else 'detach'
            raise ManipulationError(
                self.ATTACH_FAILED,
                f'Failed to {verb} {object_id}: {response.message}')

    # --------------------------------------------------------
    # Phase-4: Low-position place flow
    # --------------------------------------------------------

    async def _place(self, handle, object_id):
        if self._carried_object_id is None:
            raise ManipulationError(
                self.INVALID_GOAL,
                'No object carried; cannot place.')
        if self._carried_object_id != object_id:
            raise ManipulationError(
                self.INVALID_GOAL,
                f'Carrying {self._carried_object_id} but requested '
                f'place for {object_id}.')
        # Verify carry health before release
        if not self._check_carry_health():
            self.get_logger().warning('Object may have detached during transport.')
            self._state = ArmState.RECOVERING
        self._log_stage_start('place')
        await self._stage(handle, 'validate_carried_object', 0.05)
        self._state = ArmState.PLACING
        await self._stage(handle, 'validate_placement_zone', 0.15)
        zone_ok = self._is_in_valid_placement_zone(object_id)
        if not zone_ok:
            self.get_logger().error('Target zone invalid; keeping object.')
            raise ManipulationError(
                self.INVALID_GOAL,
                f'Target zone invalid for {object_id}; holding object.')
        # Execute release sequence based on config
        await self._stage(handle, 'prepare_release', 0.25)
        if self._release_order == 'open_then_detach':
            await self._place_open_then_detach(handle, object_id)
        else:
            await self._place_detach_then_open(handle, object_id)
        # Settle and verify placement
        await self._stage(handle, 'settle_object', 0.90)
        time.sleep(self._placement_settle)
        await self._stage(handle, 'validate_placement', 0.95)
        placed_ok = self._verify_placement_validated(object_id)
        if not placed_ok:
            self.get_logger().warning(
                'Placement validation failed; object may still be held.')
        # Clear carried state only after successful detach + settle
        self._carried_object_id = None
        self._last_attach = None
        await self._stage(handle, 'return_home', 0.98)
        await self._move_arm_once(handle, 'return_home', self._arm_home)
        self._log_stage_end('place')
        self._state = ArmState.IDLE
        await self._stage(handle, 'place_complete', 1.0)

    async def _place_open_then_detach(self, handle, object_id):
        self._log_stage_start('open_gripper')
        await self._stage(handle, 'open_gripper', 0.50)
        await self._send_trajectory_safe(
            self._gripper_joints, self._gripper_open,
            self._gripper_open_dur)
        self._log_stage_end('open_gripper')
        self._log_stage_start('detach_object')
        await self._stage(handle, 'detach_object', 0.70)
        try:
            await self._call_attach(object_id, attach=False)
        except ManipulationError as exc:
            self.get_logger().error(f'DETACH failed: {exc}')
            raise
        self._log_stage_end('detach_object')

    async def _place_detach_then_open(self, handle, object_id):
        self._log_stage_start('detach_object')
        await self._stage(handle, 'detach_object', 0.50)
        try:
            await self._call_attach(object_id, attach=False)
        except ManipulationError as exc:
            self.get_logger().error(f'DETACH failed: {exc}')
            raise
        self._log_stage_end('detach_object')
        self._log_stage_start('open_gripper')
        await self._stage(handle, 'open_gripper', 0.70)
        await self._send_trajectory_safe(
            self._gripper_joints, self._gripper_open,
            self._gripper_open_dur)
        self._log_stage_end('open_gripper')

    def _is_in_valid_placement_zone(self, object_id):
        msg = self._latest_model_states
        if msg is None:
            return True  # Cannot verify without model states
        try:
            obj_idx = msg.name.index(object_id)
        except ValueError:
            return True  # Attached, invisible from gazebo
        pose = msg.pose[obj_idx]
        x = pose.position.x
        y = pose.position.y
        hw = self._zone_hw
        hd = self._zone_hd
        margin = self._zone_margin
        clearance = self._slot_clearance
        valid = (abs(x) <= hw + margin + clearance
                 and abs(y) <= hd + margin + clearance)
        if not valid:
            self.get_logger().warning(
                f'{object_id} outside placement zone at ({x:.3f}, {y:.3f}).')
        return valid

    def _verify_placement_validated(self, object_id):
        msg = self._latest_model_states
        if msg is None:
            return True
        try:
            idx = msg.name.index(object_id)
        except ValueError:
            return True  # Object was detached properly
        return False

    # --------------------------------------------------------
    # Stage feedback, trajectory sending, helpers (phase-8 speed)
    # --------------------------------------------------------

    async def _send_trajectory(self, client, joints, positions,
                               duration_s, error_code, description):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = JointTrajectory()
        goal.trajectory.joint_names = joints
        point = JointTrajectoryPoint()
        point.positions = positions
        point.time_from_start = self._duration(duration_s)
        goal.trajectory.points = [point]
        goal_handle = await client.send_goal_async(goal)
        if not goal_handle.accepted:
            raise ManipulationError(error_code,
                f'Controller rejected: {description}.')
        wrapped_result = await goal_handle.get_result_async()
        result = wrapped_result.result
        if result.error_code != FollowJointTrajectory.Result.SUCCESSFUL:
            raise ManipulationError(
                error_code,
                f'Controller failed: {description}; '
                f'error_code={result.error_code}.')

    async def _send_trajectory_safe(self, joints, positions, duration_s):
        # Best-effort trajectory for retry resets.
        try:
            await self._send_trajectory(
                self._arm_client, joints, positions,
                duration_s, self.ARM_FAILED, 'safe reset move')
        except Exception:
            pass

    async def _stage(self, handle, name, progress):
        if handle.is_cancel_requested:
            raise ManipulationError(self.CANCELLED,
                f'Cancelled during {name}.')
        feedback = ExecuteManipulation.Feedback()
        feedback.stage = name
        feedback.progress = float(progress)
        handle.publish_feedback(feedback)
        self.get_logger().info(f'Stage: {name} ({progress:.0%})')
        time.sleep(0.05 if self._dry_run else self._settle_time)

    def _log_stage_start(self, stage_name):
        t = time.monotonic()
        self._stage_times[stage_name] = [t, None]

    def _log_stage_end(self, stage_name):
        if stage_name in self._stage_times:
            end_t = time.monotonic()
            self._stage_times[stage_name][1] = end_t
            elapsed = end_t - self._stage_times[stage_name][0]
            self.get_logger().info(
                f'  [{stage_name}] {elapsed * 1000:.0f}ms')
        if stage_name == 'open':
            self._pick_start_time = time.monotonic()
        elif stage_name == 'place_complete':
            self._place_start_time = 0.0

    @staticmethod
    def _duration(seconds):
        whole = int(seconds)
        return Duration(sec=whole,
            nanosec=int((seconds - whole) * 1_000_000_000))

    @staticmethod
    def _result(success, error_code, message):
        result = ExecuteManipulation.Result()
        result.success = success
        result.error_code = error_code
        result.message = message
        return result

    # --------------------------------------------------------
    # Dry-run fallback
    # --------------------------------------------------------

    async def _execute_dry_run(self, handle, operation, object_id):
        stages = (('validate_goal', 0.10),
                  (f'{operation}_{object_id}', 0.50),
                  (f'{operation}_complete', 1.0))
        for stage, progress in stages:
            await self._stage(handle, stage, progress)


def main(args=None):
    rclpy.init(args=args)
    node = FixedManipulationServer()
    executor = MultiThreadedExecutor(num_threads=4)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
