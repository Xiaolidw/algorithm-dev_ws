// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_HPP_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_HPP_

#include "moon_warehouse_interfaces/msg/detail/detection2_d__struct.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d__builder.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d__traits.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d__type_support.hpp"

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_HPP_
