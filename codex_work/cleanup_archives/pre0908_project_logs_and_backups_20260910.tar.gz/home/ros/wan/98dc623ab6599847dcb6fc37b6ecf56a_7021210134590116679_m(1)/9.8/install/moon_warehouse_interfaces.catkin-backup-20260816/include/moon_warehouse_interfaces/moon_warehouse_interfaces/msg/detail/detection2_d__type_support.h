// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from moon_warehouse_interfaces:msg/Detection2D.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__TYPE_SUPPORT_H_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "moon_warehouse_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_moon_warehouse_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  moon_warehouse_interfaces,
  msg,
  Detection2D
)();

#ifdef __cplusplus
}
#endif

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__TYPE_SUPPORT_H_
