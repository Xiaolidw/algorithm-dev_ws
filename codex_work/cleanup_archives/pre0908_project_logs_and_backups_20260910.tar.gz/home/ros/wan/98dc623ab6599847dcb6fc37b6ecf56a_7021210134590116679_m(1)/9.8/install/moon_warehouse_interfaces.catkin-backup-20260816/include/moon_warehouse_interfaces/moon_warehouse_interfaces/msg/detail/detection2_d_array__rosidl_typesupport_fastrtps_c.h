// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from moon_warehouse_interfaces:msg/Detection2DArray.idl
// generated code does not contain a copyright notice
#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "moon_warehouse_interfaces/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_moon_warehouse_interfaces
size_t get_serialized_size_moon_warehouse_interfaces__msg__Detection2DArray(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_moon_warehouse_interfaces
size_t max_serialized_size_moon_warehouse_interfaces__msg__Detection2DArray(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_moon_warehouse_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, moon_warehouse_interfaces, msg, Detection2DArray)();

#ifdef __cplusplus
}
#endif

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D_ARRAY__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
