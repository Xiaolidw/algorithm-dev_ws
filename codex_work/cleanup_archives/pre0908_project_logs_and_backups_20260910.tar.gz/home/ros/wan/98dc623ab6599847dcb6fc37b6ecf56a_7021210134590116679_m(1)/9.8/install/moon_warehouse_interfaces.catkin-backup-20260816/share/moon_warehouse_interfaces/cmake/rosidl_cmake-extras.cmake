# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(moon_warehouse_interfaces_IDL_FILES "action/ExecuteManipulation.idl;msg/Detection2D.idl;msg/Detection2DArray.idl")
set(moon_warehouse_interfaces_INTERFACE_FILES "action/ExecuteManipulation.action;msg/Detection2D.msg;msg/Detection2DArray.msg")
