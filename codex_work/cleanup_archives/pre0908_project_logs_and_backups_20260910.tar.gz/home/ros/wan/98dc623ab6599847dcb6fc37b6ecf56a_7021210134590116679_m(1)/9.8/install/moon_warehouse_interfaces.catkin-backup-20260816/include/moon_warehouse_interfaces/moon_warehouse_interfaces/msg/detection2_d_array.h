// generated from rosidl_generator_c/resource/idl.h.em
// with input from moon_warehouse_interfaces:msg/Detection2DArray.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_H_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_H_

#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__struct.h"
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__functions.h"
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__type_support.h"

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_H_
