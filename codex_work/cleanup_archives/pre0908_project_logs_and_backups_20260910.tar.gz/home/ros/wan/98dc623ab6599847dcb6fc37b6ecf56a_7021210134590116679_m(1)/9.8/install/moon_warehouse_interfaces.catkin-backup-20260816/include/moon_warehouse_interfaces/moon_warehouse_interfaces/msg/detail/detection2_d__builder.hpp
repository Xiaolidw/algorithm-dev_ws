// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from moon_warehouse_interfaces:msg/Detection2D.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__BUILDER_HPP_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "moon_warehouse_interfaces/msg/detail/detection2_d__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace moon_warehouse_interfaces
{

namespace msg
{

namespace builder
{

class Init_Detection2D_center_y
{
public:
  explicit Init_Detection2D_center_y(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  ::moon_warehouse_interfaces::msg::Detection2D center_y(::moon_warehouse_interfaces::msg::Detection2D::_center_y_type arg)
  {
    msg_.center_y = std::move(arg);
    return std::move(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_center_x
{
public:
  explicit Init_Detection2D_center_x(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_center_y center_x(::moon_warehouse_interfaces::msg::Detection2D::_center_x_type arg)
  {
    msg_.center_x = std::move(arg);
    return Init_Detection2D_center_y(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_height
{
public:
  explicit Init_Detection2D_height(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_center_x height(::moon_warehouse_interfaces::msg::Detection2D::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_Detection2D_center_x(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_width
{
public:
  explicit Init_Detection2D_width(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_height width(::moon_warehouse_interfaces::msg::Detection2D::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_Detection2D_height(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_y
{
public:
  explicit Init_Detection2D_y(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_width y(::moon_warehouse_interfaces::msg::Detection2D::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_Detection2D_width(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_x
{
public:
  explicit Init_Detection2D_x(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_y x(::moon_warehouse_interfaces::msg::Detection2D::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_Detection2D_y(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_confidence
{
public:
  explicit Init_Detection2D_confidence(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_x confidence(::moon_warehouse_interfaces::msg::Detection2D::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_Detection2D_x(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_class_name
{
public:
  explicit Init_Detection2D_class_name(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_confidence class_name(::moon_warehouse_interfaces::msg::Detection2D::_class_name_type arg)
  {
    msg_.class_name = std::move(arg);
    return Init_Detection2D_confidence(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_id
{
public:
  explicit Init_Detection2D_id(::moon_warehouse_interfaces::msg::Detection2D & msg)
  : msg_(msg)
  {}
  Init_Detection2D_class_name id(::moon_warehouse_interfaces::msg::Detection2D::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_Detection2D_class_name(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

class Init_Detection2D_header
{
public:
  Init_Detection2D_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Detection2D_id header(::moon_warehouse_interfaces::msg::Detection2D::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Detection2D_id(msg_);
  }

private:
  ::moon_warehouse_interfaces::msg::Detection2D msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::moon_warehouse_interfaces::msg::Detection2D>()
{
  return moon_warehouse_interfaces::msg::builder::Init_Detection2D_header();
}

}  // namespace moon_warehouse_interfaces

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETAIL__DETECTION2_D__BUILDER_HPP_
