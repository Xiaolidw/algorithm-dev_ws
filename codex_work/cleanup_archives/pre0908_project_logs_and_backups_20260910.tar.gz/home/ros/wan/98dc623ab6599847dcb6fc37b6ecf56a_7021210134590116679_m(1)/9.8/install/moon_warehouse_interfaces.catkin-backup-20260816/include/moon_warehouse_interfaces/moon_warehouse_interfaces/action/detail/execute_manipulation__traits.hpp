// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__TRAITS_HPP_
#define MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_Goal & msg,
  std::ostream & out)
{
  out << "{";
  // member: operation
  {
    out << "operation: ";
    rosidl_generator_traits::value_to_yaml(msg.operation, out);
    out << ", ";
  }

  // member: object_id
  {
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_Goal & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: operation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "operation: ";
    rosidl_generator_traits::value_to_yaml(msg.operation, out);
    out << "\n";
  }

  // member: object_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "object_id: ";
    rosidl_generator_traits::value_to_yaml(msg.object_id, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_Goal & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_Goal & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_Goal & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_Goal";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_Goal";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_Result & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: error_code
  {
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_Result & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: error_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_Result & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_Result & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_Result & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_Result>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_Result";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_Result>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_Result";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Result>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Result>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_Result>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_Feedback & msg,
  std::ostream & out)
{
  out << "{";
  // member: stage
  {
    out << "stage: ";
    rosidl_generator_traits::value_to_yaml(msg.stage, out);
    out << ", ";
  }

  // member: progress
  {
    out << "progress: ";
    rosidl_generator_traits::value_to_yaml(msg.progress, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_Feedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: stage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stage: ";
    rosidl_generator_traits::value_to_yaml(msg.stage, out);
    out << "\n";
  }

  // member: progress
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "progress: ";
    rosidl_generator_traits::value_to_yaml(msg.progress, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_Feedback & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_Feedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_Feedback & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_Feedback";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_Feedback";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'goal'
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_SendGoal_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
    out << ", ";
  }

  // member: goal
  {
    out << "goal: ";
    to_flow_style_yaml(msg.goal, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }

  // member: goal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal:\n";
    to_block_style_yaml(msg.goal, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_SendGoal_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_SendGoal_Request";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>
  : std::integral_constant<bool, has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>
  : std::integral_constant<bool, has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_SendGoal_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: accepted
  {
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << ", ";
  }

  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: accepted
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << "\n";
  }

  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_SendGoal_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_SendGoal_Response";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_SendGoal";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal>
  : std::integral_constant<
    bool,
    has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>::value &&
    has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>::value
  >
{
};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal>
  : std::integral_constant<
    bool,
    has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>::value &&
    has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>::value
  >
{
};

template<>
struct is_service<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal>
  : std::true_type
{
};

template<>
struct is_service_request<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Request>
  : std::true_type
{
};

template<>
struct is_service_response<moon_warehouse_interfaces::action::ExecuteManipulation_SendGoal_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_GetResult_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_GetResult_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_GetResult_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_GetResult_Request";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'result'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_GetResult_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << ", ";
  }

  // member: result
  {
    out << "result: ";
    to_flow_style_yaml(msg.result, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_GetResult_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }

  // member: result
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "result:\n";
    to_block_style_yaml(msg.result, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_GetResult_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_GetResult_Response";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>
  : std::integral_constant<bool, has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Result>::value> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>
  : std::integral_constant<bool, has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Result>::value> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_GetResult";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_GetResult";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult>
  : std::integral_constant<
    bool,
    has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>::value &&
    has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>::value
  >
{
};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult>
  : std::integral_constant<
    bool,
    has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>::value &&
    has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>::value
  >
{
};

template<>
struct is_service<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult>
  : std::true_type
{
};

template<>
struct is_service_request<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Request>
  : std::true_type
{
};

template<>
struct is_service_response<moon_warehouse_interfaces::action::ExecuteManipulation_GetResult_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'feedback'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__traits.hpp"

namespace moon_warehouse_interfaces
{

namespace action
{

inline void to_flow_style_yaml(
  const ExecuteManipulation_FeedbackMessage & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
    out << ", ";
  }

  // member: feedback
  {
    out << "feedback: ";
    to_flow_style_yaml(msg.feedback, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecuteManipulation_FeedbackMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }

  // member: feedback
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "feedback:\n";
    to_block_style_yaml(msg.feedback, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecuteManipulation_FeedbackMessage & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace moon_warehouse_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use moon_warehouse_interfaces::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  moon_warehouse_interfaces::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use moon_warehouse_interfaces::action::to_yaml() instead")]]
inline std::string to_yaml(const moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage & msg)
{
  return moon_warehouse_interfaces::action::to_yaml(msg);
}

template<>
inline const char * data_type<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>()
{
  return "moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage";
}

template<>
inline const char * name<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>()
{
  return "moon_warehouse_interfaces/action/ExecuteManipulation_FeedbackMessage";
}

template<>
struct has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>
  : std::integral_constant<bool, has_fixed_size<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>::value && has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>
  : std::integral_constant<bool, has_bounded_size<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>::value && has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<moon_warehouse_interfaces::action::ExecuteManipulation_FeedbackMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits


namespace rosidl_generator_traits
{

template<>
struct is_action<moon_warehouse_interfaces::action::ExecuteManipulation>
  : std::true_type
{
};

template<>
struct is_action_goal<moon_warehouse_interfaces::action::ExecuteManipulation_Goal>
  : std::true_type
{
};

template<>
struct is_action_result<moon_warehouse_interfaces::action::ExecuteManipulation_Result>
  : std::true_type
{
};

template<>
struct is_action_feedback<moon_warehouse_interfaces::action::ExecuteManipulation_Feedback>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits


#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__TRAITS_HPP_
