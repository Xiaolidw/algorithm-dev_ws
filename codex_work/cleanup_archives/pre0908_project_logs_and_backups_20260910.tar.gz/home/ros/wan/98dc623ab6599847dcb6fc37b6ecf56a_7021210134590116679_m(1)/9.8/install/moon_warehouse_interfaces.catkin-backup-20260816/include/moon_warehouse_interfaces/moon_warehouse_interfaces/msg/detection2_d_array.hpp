// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_HPP_
#define MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_HPP_

#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__struct.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__builder.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__traits.hpp"
#include "moon_warehouse_interfaces/msg/detail/detection2_d_array__type_support.hpp"

#endif  // MOON_WAREHOUSE_INTERFACES__MSG__DETECTION2_D_ARRAY_HPP_
