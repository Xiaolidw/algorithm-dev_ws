// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_HPP_
#define MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_HPP_

#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.hpp"
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__builder.hpp"
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__traits.hpp"
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__type_support.hpp"

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__EXECUTE_MANIPULATION_HPP_
