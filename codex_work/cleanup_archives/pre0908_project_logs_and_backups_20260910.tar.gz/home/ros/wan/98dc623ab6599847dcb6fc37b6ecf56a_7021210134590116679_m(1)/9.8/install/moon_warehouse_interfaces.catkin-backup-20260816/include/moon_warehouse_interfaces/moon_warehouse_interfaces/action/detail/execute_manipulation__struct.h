// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from moon_warehouse_interfaces:action/ExecuteManipulation.idl
// generated code does not contain a copyright notice

#ifndef MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_H_
#define MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'operation'
// Member 'object_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Goal
{
  rosidl_runtime_c__String operation;
  rosidl_runtime_c__String object_id;
} moon_warehouse_interfaces__action__ExecuteManipulation_Goal;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_Goal.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_Goal__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Result
{
  bool success;
  int32_t error_code;
  rosidl_runtime_c__String message;
} moon_warehouse_interfaces__action__ExecuteManipulation_Result;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_Result.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stage'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Feedback
{
  rosidl_runtime_c__String stage;
  float progress;
} moon_warehouse_interfaces__action__ExecuteManipulation_Feedback;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_Feedback.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  moon_warehouse_interfaces__action__ExecuteManipulation_Goal goal;
} moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response
{
  int8_t status;
  moon_warehouse_interfaces__action__ExecuteManipulation_Result result;
} moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "moon_warehouse_interfaces/action/detail/execute_manipulation__struct.h"

/// Struct defined in action/ExecuteManipulation in the package moon_warehouse_interfaces.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  moon_warehouse_interfaces__action__ExecuteManipulation_Feedback feedback;
} moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage;

// Struct for a sequence of moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage.
typedef struct moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence
{
  moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} moon_warehouse_interfaces__action__ExecuteManipulation_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MOON_WAREHOUSE_INTERFACES__ACTION__DETAIL__EXECUTE_MANIPULATION__STRUCT_H_
