"""Prediction helpers for guarded crossings of reciprocating obstacles."""

import math
from statistics import median


def select_known_track_observation(
    laser_observation,
    model_position,
    model_velocity,
    axis,
    observed_at,
):
    """Choose a live observation for a known simulated moving obstacle.

    Lidar remains the primary source.  In the competition simulation the
    obstacle can disappear behind a wall or beyond the scan arc near a track
    endpoint, although Gazebo's independent ModelStates stream is still live.
    Use that state only for the two configured known models.  If neither
    source is usable, return ``None`` so callers retain fail-safe stopping.
    """
    if (
        isinstance(laser_observation, dict)
        and laser_observation.get('velocity_valid', False)
    ):
        return laser_observation

    if axis not in ('x', 'y') or model_position is None or model_velocity is None:
        return None

    try:
        coordinate_index = 0 if axis == 'x' else 1
        coordinate = float(model_position[coordinate_index])
        velocity = float(model_velocity[coordinate_index])
        stamp = float(observed_at)
    except (IndexError, TypeError, ValueError):
        return None

    if not all(math.isfinite(value) for value in (coordinate, velocity, stamp)):
        return None

    return {
        'coordinate': coordinate,
        'velocity': velocity,
        'velocity_valid': True,
        'observed_at': stamp,
        'point_count': 0,
        'source': 'model_state',
    }


def distance_to_motion_track(x, y, axis, fixed, minimum, maximum):
    """Shortest centre distance to the finite swept obstacle track.

    Beyond an endpoint, distance to the infinite axis can be nearly zero
    while every physically possible obstacle position is metres away.
    Existing centre-clearance thresholds already include both bodies.
    """
    if axis not in ('x', 'y') or maximum < minimum:
        raise ValueError('invalid motion track')
    along, across = (x, y) if axis == 'x' else (y, x)
    nearest = min(maximum, max(minimum, along))
    return math.hypot(along - nearest, across - fixed)


def observation_age(now, observed_at, maximum_age=0.30, clock_skew_tolerance=0.10):
    """Return usable sensor age, allowing one asynchronous clock tick.

    Gazebo lidar and /clock are independent DDS topics; a fresh scan can
    arrive before the corresponding clock tick. This is not stale data.
    Large future stamps and old observations remain invalid.
    """
    values = (now, observed_at, maximum_age, clock_skew_tolerance)
    if not all(math.isfinite(float(value)) for value in values):
        return None
    age = float(now) - float(observed_at)
    if age < -float(clock_skew_tolerance) or age > float(maximum_age):
        return None
    return max(0.0, age)


class PathProgressConsistencyMonitor:
    """Accumulate disagreement between travel and A* path reduction."""

    def __init__(
        self,
        instant_mismatch_m=0.35,
        cumulative_mismatch_m=0.65,
        recovery_gain=0.50,
    ):
        self.instant_mismatch_m = max(0.05, float(instant_mismatch_m))
        self.cumulative_mismatch_m = max(
            self.instant_mismatch_m,
            float(cumulative_mismatch_m),
        )
        self.recovery_gain = max(0.0, min(1.0, float(recovery_gain)))
        self.cumulative_mismatch = 0.0

    def reset(self):
        self.cumulative_mismatch = 0.0

    def observe(
        self,
        previous_length,
        current_length,
        travelled_distance,
    ):
        travelled_distance = max(0.0, float(travelled_distance))
        actual_reduction = (
            float(previous_length) - float(current_length)
        )
        mismatch = travelled_distance - actual_reduction
        if mismatch > 0.0:
            self.cumulative_mismatch += mismatch
        else:
            self.cumulative_mismatch = max(
                0.0,
                self.cumulative_mismatch
                + mismatch * self.recovery_gain,
            )
        inconsistent = (
            mismatch >= self.instant_mismatch_m
            or self.cumulative_mismatch >= self.cumulative_mismatch_m
        )
        return (
            inconsistent,
            mismatch,
            self.cumulative_mismatch,
            actual_reduction,
        )


def path_length_detour_excess(
    previous_length,
    current_length,
    robot_displacement,
):
    """Return growth beyond the decrease expected from robot movement."""
    expected = max(
        0.0,
        float(previous_length) - max(0.0, float(robot_displacement)),
    )
    return float(current_length) - expected


def path_change_is_dynamic(
    previous_length,
    current_length,
    robot_displacement,
    absolute_threshold,
    relative_threshold,
):
    """Reject ordinary A* grid jitter and progress before flagging a detour."""
    excess = path_length_detour_excess(
        previous_length,
        current_length,
        robot_displacement,
    )
    threshold = max(
        float(absolute_threshold),
        max(0.0, float(relative_threshold))
        * max(1.0, float(previous_length)),
    )
    return excess >= threshold, excess, threshold


def route_crossing_coordinate(
    start_x,
    start_y,
    target_x,
    target_y,
    obstacle_axis,
    fixed_coordinate,
):
    """Return (route fraction, coordinate along obstacle motion), or None."""
    start_x = float(start_x)
    start_y = float(start_y)
    target_x = float(target_x)
    target_y = float(target_y)
    fixed_coordinate = float(fixed_coordinate)
    if obstacle_axis == 'x':
        denominator = target_y - start_y
        if abs(denominator) < 1.0e-6:
            return None
        fraction = (fixed_coordinate - start_y) / denominator
        coordinate = start_x + fraction * (target_x - start_x)
    else:
        denominator = target_x - start_x
        if abs(denominator) < 1.0e-6:
            return None
        fraction = (fixed_coordinate - start_x) / denominator
        coordinate = start_y + fraction * (target_y - start_y)
    if not math.isfinite(fraction) or not 0.0 <= fraction <= 1.0:
        return None
    return fraction, coordinate


def predict_reflected_position(position, velocity, horizon, minimum, maximum):
    """Predict constant-speed motion with reflection at track endpoints."""
    minimum = float(minimum)
    maximum = float(maximum)
    if maximum <= minimum:
        return minimum
    span = maximum - minimum
    unfolded = float(position) + float(velocity) * max(0.0, float(horizon))
    phase = (unfolded - minimum) % (2.0 * span)
    if phase <= span:
        return minimum + phase
    return maximum - (phase - span)


def endpoint_gaps(position, minimum, maximum, obstacle_half_extent):
    """Return free gaps between the obstacle body and both track endpoints."""
    half_extent = max(0.0, float(obstacle_half_extent))
    return (
        max(0.0, float(position) - half_extent - float(minimum)),
        max(0.0, float(maximum) - float(position) - half_extent),
    )


def crossing_window_is_clear(
    predicted_position,
    crossing_coordinate,
    required_center_separation,
    minimum,
    maximum,
    obstacle_half_extent,
    required_wall_gap,
):
    """Require both crossing separation and a robot-width endpoint gap."""
    separation = abs(
        float(predicted_position) - float(crossing_coordinate)
    )
    left_gap, right_gap = endpoint_gaps(
        predicted_position,
        minimum,
        maximum,
        obstacle_half_extent,
    )
    crossing_is_left = float(crossing_coordinate) <= float(
        predicted_position
    )
    crossing_side_gap = left_gap if crossing_is_left else right_gap
    return (
        separation >= float(required_center_separation)
        and crossing_side_gap >= float(required_wall_gap)
    ), separation, left_gap, right_gap


def crossing_interval_is_clear(
    position, velocity, start_time, end_time, crossing_coordinate,
    required_center_separation, minimum, maximum,
    obstacle_half_extent, required_wall_gap,
):
    """Check the entire crossing occupancy interval, including track bounces.

    Reflected constant-speed motion is continuous and piecewise linear.
    Its extrema occur at the interval endpoints or at a track endpoint;
    checking that swept interval cannot miss a collision between samples.
    """
    values = (position, velocity, start_time, end_time, crossing_coordinate,
              required_center_separation, minimum, maximum,
              obstacle_half_extent, required_wall_gap)
    if not all(math.isfinite(float(value)) for value in values):
        return False, 0.0
    start_time = max(0.0, float(start_time))
    end_time = float(end_time)
    minimum, maximum = float(minimum), float(maximum)
    if end_time < start_time or maximum <= minimum:
        return False, 0.0
    positions = [
        predict_reflected_position(position, velocity, instant, minimum, maximum)
        for instant in (start_time, end_time)
    ]
    span = maximum - minimum
    period = 2.0 * span
    low, high = sorted((
        float(position) + float(velocity) * start_time - minimum,
        float(position) + float(velocity) * end_time - minimum,
    ))
    if math.ceil(low / period) * period <= high:
        positions.append(minimum)
    if math.ceil((low - span) / period) * period + span <= high:
        positions.append(maximum)
    swept_min, swept_max = min(positions), max(positions)
    closest = min(swept_max, max(swept_min, float(crossing_coordinate)))
    checks = [
        crossing_window_is_clear(
            point, crossing_coordinate, required_center_separation,
            minimum, maximum, obstacle_half_extent, required_wall_gap,
        )
        for point in (swept_min, closest, swept_max)
    ]
    return all(check[0] for check in checks), min(check[1] for check in checks)


def estimate_track_center(coordinates, minimum, maximum, half_extent, minimum_points):
    """Use the visible box envelope, not density-biased surface medians.

    Reject walls outside the motion track and ambiguous groups wider than a
    single physical obstacle. An absent observation is never a clear window.
    """
    values = [float(value) for value in coordinates
              if math.isfinite(float(value)) and minimum <= float(value) <= maximum]
    if len(values) < max(2, int(minimum_points)):
        return None
    low, high = min(values), max(values)
    if high - low > 2.0 * float(half_extent) + 0.15:
        return None
    return (low + high) / 2.0


def path_crossing_coordinate(points, robot_x, robot_y, obstacle_axis, fixed_coordinate):
    """Return the first crossing ahead on a published path as (distance, coordinate)."""
    if len(points) < 2:
        return None
    nearest = min(range(len(points)), key=lambda index:
                  math.hypot(points[index][0] - robot_x, points[index][1] - robot_y))
    route = [(float(robot_x), float(robot_y))] + list(points[nearest:])
    distance = 0.0
    for start, end in zip(route, route[1:]):
        length = math.hypot(end[0] - start[0], end[1] - start[1])
        crossing = route_crossing_coordinate(
            start[0], start[1], end[0], end[1], obstacle_axis, fixed_coordinate,
        )
        if crossing is not None:
            fraction, coordinate = crossing
            return distance + fraction * length, coordinate
        distance += length
    return None


def estimate_track_velocity(samples):
    """Median time-separated slopes over <=0.6s reject single-face jitter."""
    if len(samples) < 3:
        return None
    newest = samples[-1][0]
    recent = [(t, p) for t, p in samples if newest - t <= 0.60]
    if len(recent) < 3 or recent[-1][0] - recent[0][0] < 0.25:
        return None
    slopes = [(p2 - p1) / (t2 - t1)
              for i, (t1, p1) in enumerate(recent)
              for t2, p2 in recent[i + 1:] if t2 - t1 >= 0.20]
    if not slopes:
        return None
    velocity = median(slopes)
    return velocity if math.isfinite(velocity) else None
