import math
import time
from collections import deque

import rclpy
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Path
from rclpy.qos import qos_profile_sensor_data
from rclpy.time import Time
from sensor_msgs.msg import LaserScan

from tf2_ros import Buffer
from tf2_ros import TransformException
from tf2_ros import TransformListener

from yzbot_mission.approach_planner import compute_approach_pose
from yzbot_mission.angle_pid import AnglePid
from yzbot_mission.chassis_align_node import ChassisAlignNode
from yzbot_mission.mission_geometry import check_base_inside_zone
from yzbot_mission.mission_geometry import check_point_inside_zone
from yzbot_mission.mission_geometry import compensate_navigation_goal
from yzbot_mission.mission_logic import destination_to_waypoint
from yzbot_mission.mission_logic import select_nearest_known_pickup
from yzbot_mission.moving_obstacle_prediction import crossing_window_is_clear
from yzbot_mission.moving_obstacle_prediction import crossing_interval_is_clear
from yzbot_mission.moving_obstacle_prediction import distance_to_motion_track
from yzbot_mission.moving_obstacle_prediction import estimate_track_center
from yzbot_mission.moving_obstacle_prediction import estimate_track_velocity
from yzbot_mission.moving_obstacle_prediction import observation_age
from yzbot_mission.moving_obstacle_prediction import path_crossing_coordinate
from yzbot_mission.moving_obstacle_prediction import predict_reflected_position
from yzbot_mission.moving_obstacle_prediction import route_crossing_coordinate
from yzbot_mission.moving_obstacle_prediction import select_known_track_observation
from yzbot_mission.safety_monitor import localization_lost
from yzbot_mission.target_detector import TargetDetector
from yzbot_mission.target_search import search_for_target
from yzbot_mission.tf_utils import wait_for_transform
from yzbot_mission.trajectory_prediction import trajectory_is_clear


class TransportExecutor:
    """可由任务管理器重复调用的底盘搬运执行器。

    当前只完成抓取准备位、投放准备位和返回资源区，
    不调用机械臂，也不声明物块已被实际搬运。
    """

    def __init__(self, node):
        self.node = node
        self._used_known_pickup_waypoints = set()
        self._active_pickup = None
        self._active_pickup_target_class = ''

        detection_topic = str(
            node.get_parameter('detection_topic').value
        )

        self.detector = TargetDetector(
            node,
            topic=detection_topic,
            expected_frame='map',
        )

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(
            self.tf_buffer,
            node,
            spin_thread=False,
        )
        self._gazebo_model_positions = {}
        self._gazebo_model_velocities = {}
        self._model_state_sample_time = None
        self._gazebo_model_states_subscription = node.create_subscription(
            ModelStates,
            '/gazebo/model_states',
            self._model_states_callback,
            10,
        )
        self._initial_pose_publisher = node.create_publisher(
            PoseWithCovarianceStamped,
            '/initialpose',
            10,
        )
        self._world_to_map_anchor = None
        self._latest_dynamic_scan = None
        self._latest_dynamic_scan_received_at = 0.0
        self._dynamic_scan_queue = deque(maxlen=6)
        self._processed_dynamic_scan = None
        self._laser_obstacle_observations = {}
        self._laser_obstacle_histories = {}
        self._dynamic_scan_subscription = node.create_subscription(
            LaserScan,
            str(node.get_parameter(
                'dynamic_obstacle_scan_topic'
            ).value),
            self._dynamic_scan_callback,
            qos_profile_sensor_data,
        )
        self._latest_navigation_path = None
        self._navigation_path_subscription = node.create_subscription(
            Path, '/plan',
            lambda message: setattr(self, '_latest_navigation_path', message),
            10,
        )

    def _model_states_callback(self, message):
        now = time.monotonic()
        new_positions = {
            str(name): (
                float(pose.position.x),
                float(pose.position.y),
                self._yaw_from_orientation(pose.orientation),
            )
            for name, pose in zip(message.name, message.pose)
        }
        if self._model_state_sample_time is not None:
            dt = now - self._model_state_sample_time
            if 0.005 <= dt <= 1.0:
                for name, current in new_positions.items():
                    previous = self._gazebo_model_positions.get(name)
                    if previous is None:
                        continue
                    measured_x = (current[0] - previous[0]) / dt
                    measured_y = (current[1] - previous[1]) / dt
                    old_x, old_y = self._gazebo_model_velocities.get(
                        name,
                        (measured_x, measured_y),
                    )
                    self._gazebo_model_velocities[name] = (
                        0.45 * measured_x + 0.55 * old_x,
                        0.45 * measured_y + 0.55 * old_y,
                    )
        self._gazebo_model_positions = new_positions
        self._model_state_sample_time = now

    def _ensure_sim_localization_consistent(self, force=False):
        """Repair AMCL drift between repeated runs in the official simulator.

        The first healthy sample fixes the rigid world->map relationship.  A
        later multi-metre AMCL correction must not be used as a new anchor,
        otherwise the next A* request can start outside the static map.
        """
        robot_model = str(self.node.get_parameter(
            'gazebo_robot_model'
        ).value).strip()
        world_pose = self._gazebo_model_positions.get(robot_model)
        if world_pose is None:
            self.node.get_logger().warning(
                '尚未收到Gazebo底盘状态，跳过本轮定位一致性检查'
            )
            return True
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_footprint', Time()
            )
        except TransformException as error:
            self.node.get_logger().error(
                f'无法读取map到底盘位姿：{error}'
            )
            return False

        map_x = float(transform.transform.translation.x)
        map_y = float(transform.transform.translation.y)
        map_yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        world_x, world_y, world_yaw = map(float, world_pose)
        if self._world_to_map_anchor is None:
            anchor_yaw = math.atan2(
                math.sin(map_yaw - world_yaw),
                math.cos(map_yaw - world_yaw),
            )
            cosine = math.cos(anchor_yaw)
            sine = math.sin(anchor_yaw)
            self._world_to_map_anchor = (
                map_x - cosine * world_x + sine * world_y,
                map_y - sine * world_x - cosine * world_y,
                anchor_yaw,
            )
            self.node.get_logger().info(
                '已建立Gazebo world到map的固定定位锚点'
            )
            return True

        offset_x, offset_y, anchor_yaw = self._world_to_map_anchor
        cosine = math.cos(anchor_yaw)
        sine = math.sin(anchor_yaw)
        expected_x = offset_x + cosine * world_x - sine * world_y
        expected_y = offset_y + sine * world_x + cosine * world_y
        expected_yaw = math.atan2(
            math.sin(world_yaw + anchor_yaw),
            math.cos(world_yaw + anchor_yaw),
        )
        position_error = math.hypot(map_x - expected_x, map_y - expected_y)
        yaw_error = abs(math.atan2(
            math.sin(map_yaw - expected_yaw),
            math.cos(map_yaw - expected_yaw),
        ))
        # A drift of only ~0.17 m already fails the drop release-point gate in
        # the narrow y direction, so re-anchor far earlier than the former
        # 0.65 m threshold.  This runs while the chassis is stopped, so the
        # small /initialpose correction cannot disturb an active Nav2 goal.
        if not force and position_error <= 0.15 and yaw_error <= 0.20:
            return True

        self.node.publish_stop()
        self.node.get_logger().error(
            '检测到AMCL与Gazebo真值不一致，暂停下一循环并自动重定位：'
            f'位置误差={position_error:.3f}m，航向误差={yaw_error:.3f}rad'
        )
        message = PoseWithCovarianceStamped()
        message.header.frame_id = 'map'
        message.pose.pose.position.x = expected_x
        message.pose.pose.position.y = expected_y
        message.pose.pose.orientation.z = math.sin(expected_yaw * 0.5)
        message.pose.pose.orientation.w = math.cos(expected_yaw * 0.5)
        message.pose.covariance[0] = 0.25
        message.pose.covariance[7] = 0.25
        message.pose.covariance[35] = 0.10
        deadline = time.monotonic() + 8.0
        next_publish = 0.0
        while rclpy.ok() and time.monotonic() < deadline:
            now = time.monotonic()
            if now >= next_publish:
                message.header.stamp = self.node.get_clock().now().to_msg()
                self._initial_pose_publisher.publish(message)
                next_publish = now + 0.40
            rclpy.spin_once(self.node, timeout_sec=0.10)
            try:
                current = self.tf_buffer.lookup_transform(
                    'map', 'base_footprint', Time()
                )
            except TransformException:
                continue
            current_yaw = self._yaw_from_orientation(
                current.transform.rotation
            )
            current_error = math.hypot(
                float(current.transform.translation.x) - expected_x,
                float(current.transform.translation.y) - expected_y,
            )
            current_yaw_error = abs(math.atan2(
                math.sin(current_yaw - expected_yaw),
                math.cos(current_yaw - expected_yaw),
            ))
            if current_error <= 0.15 and current_yaw_error <= 0.15:
                self.node.get_logger().info(
                    'AMCL自动重定位已收敛：'
                    f'位置误差={current_error:.3f}m，'
                    f'航向误差={current_yaw_error:.3f}rad'
                )
                self.node.clear_navigation_costmaps()
                return True
        self.node.get_logger().error('AMCL自动重定位8秒内未收敛')
        return False

    def _reanchor_after_turn(self):
        """Re-anchor AMCL after an in-place turn, retrying up to 3 times."""
        for attempt in range(1, 4):
            if self._ensure_sim_localization_consistent(force=True):
                return True
            self.node.get_logger().warning(
                f'原地转向后AMCL重定位第{attempt}次未收敛'
            )
        self.node.get_logger().error('AMCL重定位3次均未收敛')
        return False

    def _repair_sim_localization_during_navigation(self):
        """Do not inject ``/initialpose`` while a Nav2 goal is active.

        AMCL and the laser scan are time-filtered.  At route speed the newest
        Gazebo model pose can therefore lead the latest ``map->base`` sample
        by several tenths of a metre.  Treating that normal latency as drift
        and publishing a new initial pose every 0.5 s makes AMCL jump between
        particle clouds; MPPI then receives discontinuous robot poses and can
        abort a perfectly valid long route.  Localization is still checked
        and, when necessary, repaired while the chassis is stopped between
        transport cycles by ``_ensure_sim_localization_consistent``.  During
        motion Nav2/AMCL remain the sole owners of localization.
        """
        return

    def _dynamic_scan_callback(self, message):
        self._latest_dynamic_scan = message
        self._latest_dynamic_scan_received_at = time.monotonic()
        self._dynamic_scan_queue.append(message)
        # Keep perception at sensor cadence even while navigation is stopped.
        # The 0.4s stop/wait loop is too sparse for a 0.6s velocity window;
        # querying the guard must not be what advances the observation history.
        self._laser_obstacles_in_known_tracks()

    def _laser_obstacles_in_known_tracks(self):
        """Locate moving-obstacle candidates from LaserScan in map frame."""
        if not self._dynamic_scan_queue:
            return {}
        if time.monotonic() - self._latest_dynamic_scan_received_at > 0.60:
            return {}
        transform = None
        # TF is often 10-30ms behind the newest lidar scan. Consume the newest
        # stamped scan whose transform is ready, never pair it with another
        # instant's robot pose and never wait synchronously in the control loop.
        for scan in reversed(self._dynamic_scan_queue):
            if scan is self._processed_dynamic_scan:
                return dict(self._laser_obstacle_observations)
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map', str(scan.header.frame_id),
                    Time.from_msg(scan.header.stamp),
                )
                break
            except TransformException:
                continue
        if transform is None:
            return {}
        translation = transform.transform.translation
        yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        cosine = math.cos(yaw)
        sine = math.sin(yaw)
        corridor = max(0.20, float(self.node.get_parameter(
            'dynamic_obstacle_track_corridor_half_width_m'
        ).value))
        minimum_points = max(2, int(self.node.get_parameter(
            'dynamic_obstacle_min_laser_points'
        ).value))
        specs = self._moving_obstacle_specs()
        candidate_coordinates = {
            spec['model']: [] for spec in specs
        }
        angle = float(scan.angle_min)
        # Thin/distant moving faces may occupy only a few angular samples.
        # Keep every measured ray; decimation can manufacture observation
        # loss even when the sensor supplies enough independent returns.
        for measured_range in scan.ranges:
            measured_range = float(measured_range)
            if (
                not math.isfinite(measured_range)
                or measured_range < float(scan.range_min)
                or measured_range > float(scan.range_max)
            ):
                angle += float(scan.angle_increment)
                continue
            laser_x = measured_range * math.cos(angle)
            laser_y = measured_range * math.sin(angle)
            map_x = (
                float(translation.x)
                + cosine * laser_x
                - sine * laser_y
            )
            map_y = (
                float(translation.y)
                + sine * laser_x
                + cosine * laser_y
            )
            for spec in specs:
                if spec['axis'] == 'y':
                    fixed_error = abs(map_x - spec['fixed'])
                    coordinate = map_y
                else:
                    fixed_error = abs(map_y - spec['fixed'])
                    coordinate = map_x
                if (
                    fixed_error <= corridor
                    and spec['minimum'] - 0.20
                    <= coordinate
                    <= spec['maximum'] + 0.20
                ):
                    candidate_coordinates[spec['model']].append(coordinate)
            angle += float(scan.angle_increment)

        # Velocity must use sensor time, not the time a busy task loop happens
        # to consume the scan (especially under Gazebo real-time slowdown).
        now = float(scan.header.stamp.sec) + float(scan.header.stamp.nanosec) * 1.0e-9
        observations = {}
        for spec in specs:
            coordinates = candidate_coordinates[spec['model']]
            coordinate = estimate_track_center(
                coordinates, spec['minimum'], spec['maximum'],
                spec['half_extent'], minimum_points,
            )
            previous = self._laser_obstacle_observations.get(spec['model'])
            if coordinate is None:
                # Coast through at most four missing 20Hz frames. The motion
                # window below accounts for observation age; stale data fails
                # closed. Never feed extrapolated samples back into velocity.
                if (previous is not None and previous['velocity_valid']
                        and 0.0 <= now - previous['observed_at'] <= 0.20):
                    observations[spec['model']] = dict(previous)
                continue
            history = self._laser_obstacle_histories.setdefault(spec['model'], deque(maxlen=16))
            if history and (now <= history[-1][0] or now - history[-1][0] > 0.60):
                history.clear()
            history.append((now, coordinate))
            velocity = estimate_track_velocity(list(history))
            observed_velocity = 0.0 if velocity is None else float(velocity)
            velocity_valid = velocity is not None
            max_speed = max(0.20, float(self.node.get_parameter(
                'dynamic_obstacle_max_observed_speed_mps').value))
            # A single lidar cluster jump is not a physically credible track
            # velocity. Let the known Gazebo model observation take over rather
            # than feeding the jump into the crossing-time prediction.
            if abs(observed_velocity) > max_speed:
                observed_velocity = 0.0
                velocity_valid = False
            observations[spec['model']] = {
                'coordinate': coordinate,
                'velocity': observed_velocity,
                'velocity_valid': velocity_valid,
                'observed_at': now,
                'point_count': len(coordinates),
            }
        self._processed_dynamic_scan = scan
        self._laser_obstacle_observations = observations
        return dict(observations)

    def _live_model_point_in_map(
        self,
        target_model,
        fallback_x,
        fallback_y,
    ):
        """Transform a Gazebo world model point into the current map frame.

        Gazebo world and AMCL map are nearly aligned but not identical after
        localization corrections.  Anchor the rigid 2-D transform with the
        robot pose that is simultaneously available in both frames.

        When the fixed world->map anchor exists it is authoritative: it was
        established from a healthy localization sample and re-anchored on
        drift, so it is immune to the per-sample AMCL error that can shift a
        live pickup pose by several decimetres.
        """
        target_state = self._gazebo_model_positions.get(str(target_model))
        if target_state is None:
            return float(fallback_x), float(fallback_y), 'nominal map'

        anchor = self._world_to_map_anchor
        if anchor is not None:
            offset_x, offset_y, anchor_yaw = anchor
            cosine = math.cos(anchor_yaw)
            sine = math.sin(anchor_yaw)
            return (
                offset_x + cosine * float(target_state[0])
                - sine * float(target_state[1]),
                offset_y + sine * float(target_state[0])
                + cosine * float(target_state[1]),
                'Gazebo world -> map (anchor)',
            )

        robot_model = str(self.node.get_parameter(
            'gazebo_robot_model'
        ).value).strip()
        robot_state = self._gazebo_model_positions.get(robot_model)
        if robot_state is None:
            return float(fallback_x), float(fallback_y), 'nominal map'

        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                'base_footprint',
                Time(),
            )
        except TransformException:
            return float(fallback_x), float(fallback_y), 'nominal map'

        map_robot_x = float(transform.transform.translation.x)
        map_robot_y = float(transform.transform.translation.y)
        map_robot_yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        world_robot_x = float(robot_state[0])
        world_robot_y = float(robot_state[1])
        world_robot_yaw = float(robot_state[2])
        frame_yaw = math.atan2(
            math.sin(map_robot_yaw - world_robot_yaw),
            math.cos(map_robot_yaw - world_robot_yaw),
        )
        delta_x = float(target_state[0]) - world_robot_x
        delta_y = float(target_state[1]) - world_robot_y
        cosine = math.cos(frame_yaw)
        sine = math.sin(frame_yaw)
        return (
            map_robot_x + cosine * delta_x - sine * delta_y,
            map_robot_y + sine * delta_x + cosine * delta_y,
            'Gazebo world -> map',
        )

    def _pickup_distance_geometry(
        self,
        target_model,
        target_x,
        target_y,
        map_robot_x,
        map_robot_y,
    ):
        """Return target/base positions expressed in one common frame."""
        if target_model:
            live_target = self._gazebo_model_positions.get(str(target_model))
            robot_model = str(
                self.node.get_parameter('gazebo_robot_model').value
            ).strip()
            live_robot = self._gazebo_model_positions.get(robot_model)
            if live_target is not None and live_robot is not None:
                return (
                    float(live_target[0]),
                    float(live_target[1]),
                    float(live_robot[0]),
                    float(live_robot[1]),
                    'Gazebo world',
                )

        return (
            float(target_x),
            float(target_y),
            float(map_robot_x),
            float(map_robot_y),
            'map TF',
        )

    def _moving_obstacle_specs(self):
        node = self.node
        return (
            {
                'label': 'O1',
                'model': str(node.get_parameter(
                    'moving_obstacle_1_model'
                ).value),
                'axis': 'y',
                'fixed': float(node.get_parameter(
                    'moving_obstacle_1_track_x'
                ).value),
                'minimum': float(node.get_parameter(
                    'moving_obstacle_1_track_min_y'
                ).value),
                'maximum': float(node.get_parameter(
                    'moving_obstacle_1_track_max_y'
                ).value),
                'half_extent': float(node.get_parameter(
                    'moving_obstacle_1_half_extent_m'
                ).value),
            },
            {
                'label': 'O2',
                'model': str(node.get_parameter(
                    'moving_obstacle_2_model'
                ).value),
                'axis': 'x',
                'fixed': float(node.get_parameter(
                    'moving_obstacle_2_track_y'
                ).value),
                'minimum': float(node.get_parameter(
                    'moving_obstacle_2_track_min_x'
                ).value),
                'maximum': float(node.get_parameter(
                    'moving_obstacle_2_track_max_x'
                ).value),
                'half_extent': float(node.get_parameter(
                    'moving_obstacle_2_half_extent_m'
                ).value),
            },
        )

    def _wait_for_predicted_crossing(self, spec, crossing, stop_condition):
        """Wait for a predicted robot-width opening at one obstacle axis."""
        node = self.node
        clearance = max(0.55, float(node.get_parameter(
            'moving_obstacle_crossing_clearance_m'
        ).value))
        wall_gap = max(0.55, float(node.get_parameter(
            'moving_obstacle_required_wall_gap_m'
        ).value))
        prediction_horizon = max(0.2, float(node.get_parameter(
            'moving_obstacle_prediction_horizon_sec'
        ).value))
        timeout_sec = max(5.0, float(node.get_parameter(
            'moving_obstacle_crossing_wait_timeout_sec'
        ).value))
        started_at = time.monotonic()
        next_log_at = started_at
        stable_samples = 0

        while rclpy.ok() and time.monotonic() - started_at < timeout_sec:
            node.publish_stop()
            rclpy.spin_once(node, timeout_sec=0.10)
            if stop_condition is not None and stop_condition():
                return False
            state = self._gazebo_model_positions.get(spec['model'])
            velocity = self._gazebo_model_velocities.get(
                spec['model'],
                (0.0, 0.0),
            )
            if state is None:
                if time.monotonic() - started_at >= 3.0:
                    node.get_logger().warning(
                        f"未收到{spec['label']}实时位置，交给雷达和MPPI"
                    )
                    return True
                continue
            coordinate_index = 1 if spec['axis'] == 'y' else 0
            coordinate = float(state[coordinate_index])
            axis_velocity = float(velocity[coordinate_index])
            predicted = predict_reflected_position(
                coordinate,
                axis_velocity,
                prediction_horizon,
                spec['minimum'],
                spec['maximum'],
            )
            clear, separation, left_gap, right_gap = (
                crossing_window_is_clear(
                    predicted,
                    crossing,
                    clearance,
                    spec['minimum'],
                    spec['maximum'],
                    spec['half_extent'],
                    wall_gap,
                )
            )
            stable_samples = stable_samples + 1 if clear else 0
            if stable_samples >= 4:
                node.get_logger().info(
                    f"{spec['label']}预测窗口放行：当前位置={coordinate:.3f}，"
                    f"速度={axis_velocity:+.3f}m/s，预测={predicted:.3f}，"
                    f"交叉间距={separation:.3f}m，"
                    f"端点净空=({left_gap:.3f}, {right_gap:.3f})m"
                )
                return True
            now = time.monotonic()
            if now >= next_log_at:
                node.get_logger().info(
                    f"{spec['label']}预测等待：当前位置={coordinate:.3f}，"
                    f"速度={axis_velocity:+.3f}m/s，"
                    f"{prediction_horizon:.2f}s后={predicted:.3f}，"
                    f"交叉间距={separation:.3f}m"
                )
                next_log_at = now + 1.0
        node.get_logger().error(
            f"等待{spec['label']}安全预测窗口超过{timeout_sec:.1f}s"
        )
        return False

    def _legacy_stage_before_o2_crossing(
        self, target_x, target_y, stop_condition
    ):
        """Split A* route into guarded multi-point obstacle crossings."""
        node = self.node
        if not bool(node.get_parameter(
            'moving_obstacle_crossing_guard_enabled'
        ).value):
            return True
        try:
            transform = wait_for_transform(
                node, self.tf_buffer, 'map', 'base_footprint', timeout_sec=3.0,
            )
        except RuntimeError as error:
            node.get_logger().error(str(error))
            return False
        start_x = float(transform.transform.translation.x)
        start_y = float(transform.transform.translation.y)
        target_x = float(target_x)
        target_y = float(target_y)
        crossings = []
        for spec in self._moving_obstacle_specs():
            if spec['axis'] == 'x':
                start_side = start_y - spec['fixed']
                target_side = target_y - spec['fixed']
                denominator = target_y - start_y
                if start_side * target_side >= 0.0 or abs(denominator) < 0.20:
                    continue
                alpha = (spec['fixed'] - start_y) / denominator
                crossing = start_x + alpha * (target_x - start_x)
            else:
                start_side = start_x - spec['fixed']
                target_side = target_x - spec['fixed']
                denominator = target_x - start_x
                if start_side * target_side >= 0.0 or abs(denominator) < 0.20:
                    continue
                alpha = (spec['fixed'] - start_x) / denominator
                crossing = start_y + alpha * (target_y - start_y)
            if spec['minimum'] - 0.45 <= crossing <= spec['maximum'] + 0.45:
                crossings.append((alpha, spec, crossing, start_side))
        for _, spec, crossing, start_side in sorted(
            crossings, key=lambda item: item[0]
        ):
            staging_offset = max(0.65, float(node.get_parameter(
                'moving_obstacle_staging_offset_m'
            ).value))
            exit_offset = max(0.55, float(node.get_parameter(
                'moving_obstacle_exit_offset_m'
            ).value))
            candidate_minimum = spec['minimum'] + 0.45
            candidate_maximum = spec['maximum'] - 0.45
            if candidate_minimum > candidate_maximum:
                candidate_minimum = spec['minimum']
                candidate_maximum = spec['maximum']
            nominal_crossing = min(
                candidate_maximum,
                max(candidate_minimum, crossing),
            )

            def crossing_points(candidate):
                if spec['axis'] == 'x':
                    staging = (
                        candidate,
                        spec['fixed'] + math.copysign(
                            staging_offset, start_side
                        ),
                    )
                    exit_point = (
                        candidate,
                        spec['fixed'] - math.copysign(
                            exit_offset, start_side
                        ),
                    )
                else:
                    staging = (
                        spec['fixed'] + math.copysign(
                            staging_offset, start_side
                        ),
                        candidate,
                    )
                    exit_point = (
                        spec['fixed'] - math.copysign(
                            exit_offset, start_side
                        ),
                        candidate,
                    )
                yaw = math.atan2(
                    exit_point[1] - staging[1],
                    exit_point[0] - staging[0],
                )
                return staging, exit_point, yaw

            candidate_crossings = sorted({
                min(candidate_maximum, max(candidate_minimum, value))
                for value in (
                    nominal_crossing - 1.20,
                    nominal_crossing - 0.60,
                    nominal_crossing,
                    nominal_crossing + 0.60,
                    nominal_crossing + 1.20,
                )
            })
            path_length_function = getattr(node, 'compute_path_length', None)
            ranked_candidates = []
            if callable(path_length_function):
                for candidate in candidate_crossings:
                    staging, exit_point, yaw = crossing_points(candidate)
                    route_length = path_length_function(
                        staging[0], staging[1], yaw, timeout_sec=0.70,
                    )
                    if route_length is None:
                        continue
                    remaining_estimate = math.hypot(
                        target_x - exit_point[0],
                        target_y - exit_point[1],
                    )
                    ranked_candidates.append((
                        route_length + remaining_estimate,
                        candidate,
                        staging,
                        exit_point,
                        yaw,
                    ))
            if ranked_candidates:
                (
                    selected_cost,
                    crossing,
                    staging,
                    exit_point,
                    crossing_yaw,
                ) = min(ranked_candidates, key=lambda item: item[0])
                node.get_logger().info(
                    f"{spec['label']}轴A*候选束："
                    f"{len(ranked_candidates)}/{len(candidate_crossings)}个可行，"
                    f"选择坐标={crossing:.3f}，估计总代价={selected_cost:.3f}m"
                )
            else:
                crossing = nominal_crossing
                staging, exit_point, crossing_yaw = crossing_points(crossing)
                node.get_logger().warning(
                    f"{spec['label']}轴候选束暂未取得A*路径，"
                    '使用名义交叉点并交给Nav2实时重规划'
                )
            staging_x, staging_y = staging
            exit_x, exit_y = exit_point
            node.get_logger().info(
                f"A*多点路线横穿{spec['label']}轴：停车点="
                f"({staging_x:.3f},{staging_y:.3f})，离开点="
                f"({exit_x:.3f},{exit_y:.3f})"
            )
            if not node.navigate_to_pose(
                staging_x, staging_y, crossing_yaw,
                label=f"moving_{spec['label'].lower()}_staging",
                stop_condition=lambda: self._navigation_should_stop(
                    stop_condition
                ),
                arrival_condition=lambda sx=staging_x, sy=staging_y: (
                    self._base_position_ready(sx, sy, 0.18)
                ),
            ):
                return False
            if callable(path_length_function):
                first_length = path_length_function(
                    exit_x, exit_y, crossing_yaw, timeout_sec=1.0,
                )
                rclpy.spin_once(node, timeout_sec=0.25)
                second_length = path_length_function(
                    exit_x, exit_y, crossing_yaw, timeout_sec=1.0,
                )
                if first_length is not None and second_length is not None:
                    delta = abs(second_length - first_length)
                    node.get_logger().info(
                        f"{spec['label']}局部A*长度变化={delta:.3f}m；"
                        + ('障碍正在改变可行路线' if delta >= 0.08 else '路线当前稳定')
                    )
            if not self._wait_for_predicted_crossing(
                spec, crossing, stop_condition,
            ):
                return False
            profile_function = getattr(node, 'set_obstacle_crossing_profile', None)
            if callable(profile_function) and not profile_function(True):
                return False
            try:
                if not node.navigate_to_pose(
                    exit_x, exit_y, crossing_yaw,
                    label=f"moving_{spec['label'].lower()}_exit",
                    stop_condition=lambda: self._navigation_should_stop(
                        stop_condition
                    ),
                    arrival_condition=lambda ex=exit_x, ey=exit_y: (
                        self._base_position_ready(ex, ey, 0.18)
                    ),
                    retry_count_override=0,
                    no_progress_timeout_override=8.0,
                ):
                    return False
            finally:
                if callable(profile_function):
                    profile_function(False)
            node.clear_navigation_costmaps()
            start_x, start_y = exit_x, exit_y
        return True

    def _build_dynamic_navigation_monitor(
        self, target_x, target_y, target_yaw, stop_condition,
    ):
        """Guard known moving tracks without waiting for a global-plan detour.

        The global costmap deliberately filters moving objects for stable A*.
        Its path length therefore cannot be the trigger for dynamic safety.
        Raw lidar and the crossing occupancy interval decide when to yield;
        Nav2 retains the real goal and all of its own collision checking.
        """
        node = self.node
        state = {'active': None, 'start_side': None, 'crossing': None,
                 'slowed': False, 'committed_crossing': False,
                 'replanned': False, 'next_log_at': 0.0,
                 'window_observation': None, 'safe_samples': 0,
                 'uncertain_samples': 0, 'exit_samples': 0,
                 'profile_speed': None}
        clearance = float(node.get_parameter(
            'moving_obstacle_crossing_clearance_m').value)
        stop_distance = float(node.get_parameter(
            'dynamic_obstacle_stop_distance_m').value)
        detection_distance = float(node.get_parameter(
            'dynamic_obstacle_detection_axis_distance_m').value)
        deceleration_distance = float(node.get_parameter(
            'dynamic_obstacle_deceleration_distance_m').value)
        crossing_speed = max(0.20, float(node.get_parameter(
            'moving_obstacle_crossing_linear_velocity_mps').value))
        uncertain_speed = max(0.20, float(node.get_parameter(
            'dynamic_obstacle_uncertain_speed_mps').value))
        safe_margin = max(0.0, float(node.get_parameter(
            'dynamic_obstacle_safe_margin_m').value))
        risk_margin = max(0.0, float(node.get_parameter(
            'dynamic_obstacle_risk_margin_m').value))
        safe_sample_count = max(1, int(node.get_parameter(
            'dynamic_obstacle_safe_sample_count').value))
        exit_confirm_samples = max(1, int(node.get_parameter(
            'dynamic_obstacle_exit_confirm_samples').value))
        exit_clear_distance = max(
            stop_distance + 0.10,
            float(node.get_parameter(
                'dynamic_obstacle_exit_clear_distance_m').value),
        )
        max_observed_speed = max(0.20, float(node.get_parameter(
            'dynamic_obstacle_max_observed_speed_mps').value))

        def robot_position():
            # Also works after action cancellation while waiting at a crossing.
            pose = self._accurate_base_pose_in_map(use_map_yaw=False)
            return pose[:2] if pose is not None else None

        def signed_distance(position, spec):
            return (position[1] if spec['axis'] == 'x' else position[0]) - spec['fixed']

        def track_distance(position, spec):
            return distance_to_motion_track(
                position[0], position[1], spec['axis'], spec['fixed'],
                spec['minimum'], spec['maximum'],
            )

        def route_crossing(position, spec):
            path = self._latest_navigation_path
            if path is not None and path.poses and path.header.frame_id.lstrip('/') == 'map':
                end = path.poses[-1].pose.position
                # Ignore a previous task's cached path while a new goal starts.
                if math.hypot(end.x - target_x, end.y - target_y) <= 0.50:
                    return path_crossing_coordinate(
                        [(p.pose.position.x, p.pose.position.y) for p in path.poses],
                        position[0], position[1], spec['axis'], spec['fixed'],
                    )
            return route_crossing_coordinate(
                position[0], position[1], target_x, target_y,
                spec['axis'], spec['fixed'],
            )

        def restore_speed():
            if state['slowed']:
                if node.set_obstacle_crossing_profile(False):
                    state['slowed'] = False
                    state['profile_speed'] = None

        def apply_buffer_speed(speed):
            speed = float(speed)
            if state['slowed'] and state['profile_speed'] == speed:
                return True
            if node.set_obstacle_crossing_profile(True, speed):
                state['slowed'] = True
                state['profile_speed'] = speed
                return True
            return False

        def window_status(position):
            spec = state['active']
            laser_observation = self._laser_obstacles_in_known_tracks().get(
                spec['model']
            )
            observation = select_known_track_observation(
                laser_observation=laser_observation,
                model_position=self._gazebo_model_positions.get(spec['model']),
                model_velocity=self._gazebo_model_velocities.get(spec['model']),
                axis=spec['axis'],
                observed_at=node.get_clock().now().nanoseconds * 1.0e-9,
            )
            state['window_observation'] = observation
            if observation is None:
                return False, 0.0
            age = observation_age(
                node.get_clock().now().nanoseconds * 1.0e-9,
                observation['observed_at'])
            if age is None:
                return False, 0.0
            # Compare both bodies at the same future time along the real
            # local section of the global path, not at a vacated fixed point.
            route = [position, (target_x, target_y)]
            path = self._latest_navigation_path
            if path is not None and path.poses and path.header.frame_id.lstrip('/') == 'map':
                end = path.poses[-1].pose.position
                if math.hypot(end.x - target_x, end.y - target_y) <= 0.50:
                    points = [(p.pose.position.x, p.pose.position.y) for p in path.poses]
                    nearest = min(range(len(points)), key=lambda i:
                                  math.hypot(points[i][0]-position[0], points[i][1]-position[1]))
                    route = [position] + points[nearest:]
            horizon = detection_distance + 2.0 * clearance
            trajectory = [(0.0, position[0], position[1])]
            travelled = 0.0
            for end in route[1:]:
                _, x, y = trajectory[-1]
                length = math.hypot(end[0]-x, end[1]-y)
                if length < 1.0e-6:
                    continue
                step = min(length, horizon - travelled)
                travelled += step
                route_speed = state['profile_speed']
                if route_speed is None:
                    route_speed = float(node.get_parameter(
                        'carried_linear_velocity_mps'
                        if bool(getattr(node, 'carried_motion_profile_active', False))
                        else 'empty_linear_velocity_mps'
                    ).value)
                route_speed = max(0.20, route_speed)
                trajectory.append((travelled / route_speed,
                                   x + (end[0]-x)*step/length,
                                   y + (end[1]-y)*step/length))
                if travelled >= horizon:
                    break
            # Allow half a second of launch/sensor timing error in obstacle
            # travel, in addition to (never instead of) the existing clearance.
            uncertainty = abs(float(observation['velocity'])) * 0.50
            return trajectory_is_clear(
                trajectory=trajectory,
                position=float(observation['coordinate']),
                velocity=float(observation['velocity']),
                observation_age=age,
                axis=spec['axis'], fixed=spec['fixed'],
                required_center_separation=clearance + uncertainty,
                minimum=spec['minimum'], maximum=spec['maximum'],
                obstacle_half_extent=spec['half_extent'],
                required_wall_gap=float(node.get_parameter(
                    'moving_obstacle_required_wall_gap_m').value),
            )

        def crossing_clear_waiter():
            required = max(2, int(node.get_parameter(
                'dynamic_replan_stable_sample_count').value))
            waiting = {'clear_samples': 0, 'next_sample_at': 0.0, 'next_log_at': 0.0}

            def clear_to_resume():
                now = time.monotonic()
                if now < waiting['next_sample_at']:
                    return False
                waiting['next_sample_at'] = now + 0.20
                position = robot_position()
                clear = position is not None and window_status(position)[0]
                waiting['clear_samples'] = waiting['clear_samples'] + 1 if clear else 0
                if now >= waiting['next_log_at']:
                    observation = state['window_observation']
                    sensor_age = (node.get_clock().now().nanoseconds * 1.0e-9
                                  - observation['observed_at']) if observation else None
                    node.get_logger().info(
                        f"动态通道等待：位置={position}，交叉坐标={state['crossing']:.2f}，"
                        f"可通行={clear}，连续={waiting['clear_samples']}，"
                        f"观测龄期={sensor_age}，雷达={observation}"
                    )
                    waiting['next_log_at'] = now + 1.0
                if waiting['clear_samples'] >= required:
                    state['replanned'] = False
                return waiting['clear_samples'] >= required

            return clear_to_resume

        def monitor():
            if stop_condition is not None and stop_condition():
                return None
            if not bool(node.get_parameter('dynamic_path_monitor_enabled').value):
                return None
            position = robot_position()
            if position is None:
                return None
            # Keep velocity observations warm even when the global path is
            # unchanged. The old anomaly-only sampling left velocity at zero.
            self._laser_obstacles_in_known_tracks()
            if state['active'] is None:
                candidates = []
                for spec in self._moving_obstacle_specs():
                    crossing = route_crossing(position, spec)
                    distance = track_distance(position, spec)
                    if (crossing is not None and distance <= detection_distance
                            and spec['minimum'] - clearance <= crossing[1]
                            <= spec['maximum'] + clearance):
                        candidates.append((distance, spec, crossing[1]))
                if not candidates:
                    return None
                _, spec, crossing = min(candidates, key=lambda item: item[0])
                state.update(
                    active=spec,
                    crossing=crossing,
                    start_side=signed_distance(position, spec),
                    committed_crossing=False,
                    replanned=False,
                    safe_samples=0,
                    uncertain_samples=0,
                    exit_samples=0,
                )
                node.get_logger().info(
                    f"提前监测{spec['label']}移动通道：交叉坐标={crossing:.2f}，不等待A*变化"
                )

            spec = state['active']
            side = signed_distance(position, spec)
            distance = track_distance(position, spec)
            if state['start_side'] * side < 0.0 and distance >= exit_clear_distance:
                state['exit_samples'] += 1
                if state['exit_samples'] >= exit_confirm_samples:
                    restore_speed()
                    if not state['slowed']:
                        state['active'] = None
                return None
            state['exit_samples'] = 0
            # Once the centre has crossed, continue clearing the track under
            # Nav2 rather than stopping inside a moving obstacle's corridor.
            crossed = state['start_side'] * side < 0.0
            crossing = route_crossing(position, spec)
            if not crossed and crossing is not None:
                state['crossing'] = crossing[1]
            clear, separation = window_status(position)
            observation = state['window_observation']
            observation_valid = bool(
                observation is not None
                and observation.get('velocity_valid', False)
            )
            state['safe_samples'] = state['safe_samples'] + 1 if clear else 0
            state['uncertain_samples'] = (
                state['uncertain_samples'] + 1
                if not observation_valid else 0
            )
            required_separation = clearance
            if observation is not None:
                required_separation += abs(float(
                    observation.get('velocity', 0.0))) * 0.50
            margin = separation - required_separation

            if distance <= deceleration_distance and not crossed:
                if not state['committed_crossing']:
                    if clear and state['safe_samples'] >= safe_sample_count:
                        if margin >= safe_margin:
                            # Lock the normal route profile for a wide safe
                            # window; do not rewrite it on every scan.
                            restore_speed()
                            selected_profile = 'normal'
                        elif margin >= risk_margin:
                            apply_buffer_speed(crossing_speed)
                            selected_profile = f'{crossing_speed:.2f}'
                        else:
                            apply_buffer_speed(uncertain_speed)
                            selected_profile = f'{uncertain_speed:.2f}'
                        state['committed_crossing'] = True
                        node.get_logger().info(
                            f"{spec['label']}已锁定穿越速度策略：{selected_profile}，"
                            f"安全余量={margin:.2f}m"
                        )
                    else:
                        # Keep the short confirmation phase bounded. Once
                        # committed, this branch is never entered again.
                        apply_buffer_speed(uncertain_speed)
            now = time.monotonic()
            if now >= state['next_log_at']:
                node.get_logger().info(
                    f"{spec['label']}二维穿越预测：距轨道={distance:.2f}m，"
                    f"交叉坐标={state['crossing']:.2f}，最小中心间距={separation:.2f}m，"
                    f"安全余量={margin:.2f}m，连续安全={state['safe_samples']}/"
                    f"{safe_sample_count}，速度策略="
                    f"{state['profile_speed'] if state['slowed'] else 'normal'}，"
                    f"可通行={clear}，障碍观测={state['window_observation']}"
                )
                state['next_log_at'] = now + 1.0
            if (
                not crossed
                and not state['committed_crossing']
                and not clear
                and (
                    observation_valid
                    or state['uncertain_samples'] >= safe_sample_count
                )
                and distance <= stop_distance
                and not state['replanned']
            ):
                state['replanned'] = True
                return {
                    'action': 'replan',
                    'reason': f"{spec['label']}穿越时间窗不安全或雷达速度尚未就绪",
                    'wait_until': crossing_clear_waiter(),
                    'require_clear_before_retry': True,
                    'wait_timeout_sec': float(node.get_parameter(
                        'moving_obstacle_crossing_wait_timeout_sec').value),
                    'retry_delay_sec': 0.15,
                    'preserve_costmaps': True,
                }
            return None

        return monitor, restore_speed

    def _navigate_to_pose_with_dynamic_guard(
        self,
        x,
        y,
        yaw,
        stop_condition,
        use_dynamic_monitor=True,
        **navigation_arguments,
    ):
        navigation_arguments.setdefault(
            'stop_condition',
            lambda: self._navigation_should_stop(stop_condition),
        )
        navigation_arguments.setdefault('retry_count_override', 2)
        if not use_dynamic_monitor:
            self.node.get_logger().info(
                '终端抓取接近段禁用长距离动态障碍路径变化判据；'
                'Nav2碰撞层与MPPI局部避障仍保持启用'
            )
            return self.node.navigate_to_pose(
                x,
                y,
                yaw,
                **navigation_arguments,
            )

        monitor, cleanup = self._build_dynamic_navigation_monitor(
            float(x), float(y), float(yaw), stop_condition
        )
        try:
            return self.node.navigate_to_pose(
                x,
                y,
                yaw,
                navigation_monitor=monitor,
                **navigation_arguments,
            )
        finally:
            cleanup()

    def _navigate_to_named_target_with_dynamic_guard(
        self,
        target_name,
        stop_condition,
        **navigation_arguments,
    ):
        waypoint = self.node.get_waypoint(target_name)
        if waypoint is None:
            return False
        monitor, cleanup = self._build_dynamic_navigation_monitor(
            waypoint['x'], waypoint['y'], waypoint['yaw'], stop_condition
        )
        navigation_arguments.setdefault(
            'stop_condition',
            lambda: self._navigation_should_stop(stop_condition),
        )
        navigation_arguments.setdefault('retry_count_override', 2)
        try:
            return self.node.navigate_to_named_target(
                target_name,
                navigation_monitor=monitor,
                **navigation_arguments,
            )
        finally:
            cleanup()

    def reset_known_pickup_sequence(self):
        """Start a new plan with all five red and blue instances available."""  
        self._used_known_pickup_waypoints = set()
        self._active_pickup = None
        self._active_pickup_target_class = ''

    @property
    def active_pickup_model(self):
        """Gazebo model selected by the latest successful pickup approach."""
        if self._active_pickup is None:
            return ''

        return str(self._active_pickup.model_name)

    def _navigation_should_stop(self, stop_condition):
        if stop_condition is not None and stop_condition():
            return True

        self._repair_sim_localization_during_navigation()

        return localization_lost(
            self.node,
            self.tf_buffer,
        )

    def _new_angle_pid(self):
        """Create one PID state for an individual yaw manoeuvre."""
        return AnglePid(
            kp=float(self.node.get_parameter('angle_pid_kp').value),
            ki=float(self.node.get_parameter('angle_pid_ki').value),
            kd=float(self.node.get_parameter('angle_pid_kd').value),
            integral_limit=float(self.node.get_parameter(
                'angle_pid_integral_limit'
            ).value),
            derivative_alpha=float(self.node.get_parameter(
                'angle_pid_derivative_alpha'
            ).value),
        )

    def _bounded_pid_angular_velocity(
        self,
        pid,
        error,
        maximum_velocity,
        tolerance,
    ):
        velocity = pid.update(error, time.monotonic())
        velocity = max(
            -float(maximum_velocity),
            min(float(maximum_velocity), velocity),
        )
        minimum_velocity = max(0.0, float(self.node.get_parameter(
            'angle_pid_min_velocity_rps'
        ).value))
        if abs(error) > tolerance and abs(velocity) < minimum_velocity:
            velocity = math.copysign(minimum_velocity, error)
        return velocity

    @staticmethod
    def _yaw_from_orientation(orientation):
        return math.atan2(
            2.0 * (
                orientation.w * orientation.z
                + orientation.x * orientation.y
            ),
            1.0 - 2.0 * (
                orientation.y * orientation.y
                + orientation.z * orientation.z
            ),
        )

    def _hard_stop(self, repeat=8):
        """One stop burst, not repeat times the configured stop burst."""
        self.node.publish_stop(count=max(1, int(repeat)))

    def _pickup_pose_ready(
        self,
        approach_x,
        approach_y,
        approach_yaw,
        position_tolerance_m,
        yaw_tolerance_rad,
        target_model=None,
        target_x=None,
        target_y=None,
        desired_distance=None,
        distance_tolerance_m=None,
        pre_approach=False,
    ):
        """Stop Nav2 at a safe pre-approach pose or final grasp pose.

        Pre-approach handoff uses live cube/base range and a wider position
        gate so MPPI does not stall at the edge of the cube costmap.
        """
        position_tolerance_m = max(
            0.01,
            float(position_tolerance_m),
        )
        yaw_tolerance_rad = max(
            0.05,
            float(yaw_tolerance_rad),
        )

        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                'base_footprint',
                Time(),
            )
        except TransformException:
            return False

        robot_x = float(transform.transform.translation.x)
        robot_y = float(transform.transform.translation.y)
        position_error = math.hypot(
            robot_x - float(approach_x),
            robot_y - float(approach_y),
        )

        robot_yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        yaw_error = abs(math.atan2(
            math.sin(float(approach_yaw) - robot_yaw),
            math.cos(float(approach_yaw) - robot_yaw),
        ))

        if pre_approach:
            if not target_model or target_x is None or target_y is None:
                return False
            (
                geometry_target_x,
                geometry_target_y,
                geometry_robot_x,
                geometry_robot_y,
                geometry_source,
            ) = self._pickup_distance_geometry(
                target_model, target_x, target_y, robot_x, robot_y
            )
            actual_distance = math.hypot(
                geometry_target_x - geometry_robot_x,
                geometry_target_y - geometry_robot_y,
            )
            distance_tolerance = max(0.02, float(self.node.get_parameter(
                'pickup_pre_approach_distance_tolerance_m').value))
            speed_limit = max(0.02, float(self.node.get_parameter(
                'pickup_pre_approach_speed_limit_mps').value))
            robot_velocity = self._gazebo_model_velocities.get(
                str(self.node.get_parameter('gazebo_robot_model').value).strip(),
                (0.0, 0.0),
            )
            robot_speed = math.hypot(float(robot_velocity[0]), float(robot_velocity[1]))
            if (
                abs(actual_distance - float(desired_distance)) > distance_tolerance
                or position_error > position_tolerance_m
                or robot_speed > speed_limit
            ):
                return False
            self._hard_stop(repeat=10)
            self.node.get_logger().info(
                '抓取预接近交接条件满足：'
                f'实际距离={actual_distance:.3f}m，'
                f'预接近点误差={position_error:.3f}m，'
                f'底盘速度={robot_speed:.3f}m/s，'
                f'坐标系={geometry_source}'
            )
            return True

        # A physical cube/base range is authoritative for the final grasp pose.
        if target_model and desired_distance is not None:
            (
                geometry_target_x,
                geometry_target_y,
                geometry_robot_x,
                geometry_robot_y,
                geometry_source,
            ) = self._pickup_distance_geometry(
                target_model,
                target_x,
                target_y,
                robot_x,
                robot_y,
            )
            live_robot = self._gazebo_model_positions.get(str(
                self.node.get_parameter('gazebo_robot_model').value
            ).strip())
            geometry_robot_yaw = (
                float(live_robot[2])
                if geometry_source == 'Gazebo world'
                and live_robot is not None
                and len(live_robot) >= 3
                else robot_yaw
            )
            delta_x = geometry_target_x - geometry_robot_x
            delta_y = geometry_target_y - geometry_robot_y
            actual_distance = math.hypot(delta_x, delta_y)
            robot_velocity = self._gazebo_model_velocities.get(
                str(self.node.get_parameter(
                    'gazebo_robot_model'
                ).value).strip(),
                (0.0, 0.0),
            )
            robot_speed = math.hypot(
                float(robot_velocity[0]),
                float(robot_velocity[1]),
            )
            closing_speed = 0.0
            if actual_distance > 1.0e-3:
                closing_speed = max(
                    0.0,
                    (
                        delta_x * float(robot_velocity[0])
                        + delta_y * float(robot_velocity[1])
                    ) / actual_distance,
                )
            prediction_sec = max(0.0, float(self.node.get_parameter(
                'pickup_brake_prediction_sec'
            ).value))
            maximum_lead = max(0.0, float(self.node.get_parameter(
                'pickup_brake_prediction_max_m'
            ).value))
            minimum_lead = max(0.0, float(self.node.get_parameter(
                'pickup_brake_prediction_min_m'
            ).value))
            predicted_travel = (
                min(
                    maximum_lead,
                    max(minimum_lead, closing_speed * prediction_sec),
                )
                if closing_speed > 0.03
                else 0.0
            )
            predicted_robot_x = geometry_robot_x
            predicted_robot_y = geometry_robot_y
            if closing_speed > 0.03 and predicted_travel > 0.0:
                predicted_robot_x += (
                    delta_x / actual_distance * predicted_travel
                )
                predicted_robot_y += (
                    delta_y / actual_distance * predicted_travel
                )
            predicted_distance = math.hypot(
                geometry_target_x - predicted_robot_x,
                geometry_target_y - predicted_robot_y,
            )
            distance_error = abs(
                predicted_distance - float(desired_distance)
            )
            # Keep both sides of the approach-point comparison in one frame.
            # target_x/approach_x are map coordinates, while Gazebo truth (when
            # available) is in world.  Reapply the map-space approach offset
            # to the live target instead of subtracting map from world.
            geometry_approach_x = (
                geometry_target_x
                + float(approach_x) - float(target_x)
            )
            geometry_approach_y = (
                geometry_target_y
                + float(approach_y) - float(target_y)
            )
            predicted_position_error = math.hypot(
                predicted_robot_x - geometry_approach_x,
                predicted_robot_y - geometry_approach_y,
            )
            target_bearing = math.atan2(delta_y, delta_x)
            geometry_yaw_error = abs(math.atan2(
                math.sin(target_bearing - geometry_robot_yaw),
                math.cos(target_bearing - geometry_robot_yaw),
            ))
            distance_tolerance_m = max(
                0.01,
                float(distance_tolerance_m),
            )
            stationary_position_tolerance = max(
                position_tolerance_m,
                float(self.node.get_parameter(
                    'pickup_stationary_handoff_position_tolerance_m'
                ).value),
            )
            effective_position_tolerance = (
                stationary_position_tolerance
                if robot_speed <= 0.03
                else position_tolerance_m
            )
            # Range alone describes a circle around the cube.  Accepting any
            # point on that circle let MPPI stop beside the package, after
            # which a large close-range turn displaced the chassis and hid the
            # cube below the camera.  Require the calibrated approach point and
            # MPPI coarse heading at the same time; PID then handles only the
            # explicitly bounded fine yaw remainder.
            if (
                distance_error > distance_tolerance_m
                or predicted_position_error > effective_position_tolerance
            ):
                return False
            self._hard_stop()
            self.node.get_logger().info(
                'MPPI真实抓取几何交接条件满足：'
                f'实际距离={actual_distance:.3f}m，'
                f'闭合速度={closing_speed:.3f}m/s，'
                f'预测滑行={predicted_travel:.3f}m，'
                f'预测停车距离={predicted_distance:.3f}m，'
                f'预测距离误差={distance_error:.3f}m，'
                f'预测接近点误差={predicted_position_error:.3f}m，'
                f'接近点容差={effective_position_tolerance:.3f}m，'
                f'底盘速度={robot_speed:.3f}m/s，'
                f'待快速旋转修正航向误差={geometry_yaw_error:.3f}rad，'
                f'坐标系={geometry_source}'
            )
            return True

        if position_error > position_tolerance_m:
            return False

        self._hard_stop()
        self.node.get_logger().info(
            'MPPI抓取位交接条件满足：'
            f'平面误差={position_error:.3f}m，'
            f'待快速旋转修正航向误差={yaw_error:.3f}rad；'
            '立即停止Nav2，最终航向交给实时反馈旋转校准'
        )
        return True

    def _rotate_to_known_pickup_yaw(
        self,
        target_x,
        target_y,
        stop_condition,
        target_model=None,
    ):
        """Face the live cube with fast feedback rotation and hard braking."""
        node = self.node
        tolerance = max(
            0.05,
            float(node.get_parameter(
                'pickup_coarse_yaw_tolerance_rad'
            ).value),
        )
        maximum_velocity = max(
            0.06,
            float(node.get_parameter(
                'pickup_coarse_yaw_max_velocity_rps'
            ).value),
        )
        timeout_sec = max(
            1.0,
            float(node.get_parameter(
                'pickup_coarse_yaw_timeout_sec'
            ).value),
        )
        deadline = time.monotonic() + timeout_sec
        required_stable_samples = max(1, int(node.get_parameter(
            'pickup_pid_stable_samples'
        ).value))
        stable_samples = 0
        next_log_at = time.monotonic()

        node.get_logger().info(
            '开始抓取位实时反馈快速旋转；不使用角度PID，'
            '进入目标角度容差后立即强制制动'
        )

        try:
            while rclpy.ok() and time.monotonic() < deadline:
                if stop_condition is not None and stop_condition():
                    return False

                rclpy.spin_once(node, timeout_sec=0.05)

                try:
                    transform = self.tf_buffer.lookup_transform(
                        'map',
                        'base_footprint',
                        Time(),
                    )
                except TransformException:
                    node.publish_stop()
                    continue

                current_yaw = self._yaw_from_orientation(
                    transform.transform.rotation
                )
                robot_x = float(transform.transform.translation.x)
                robot_y = float(transform.transform.translation.y)
                geometry_source = 'map TF'
                live_target = self._gazebo_model_positions.get(
                    str(target_model)
                ) if target_model else None
                robot_model = str(node.get_parameter(
                    'gazebo_robot_model'
                ).value).strip()
                live_robot = self._gazebo_model_positions.get(robot_model)
                if live_target is not None and live_robot is not None:
                    robot_x = float(live_robot[0])
                    robot_y = float(live_robot[1])
                    current_yaw = float(live_robot[2])
                    target_x_for_yaw = float(live_target[0])
                    target_y_for_yaw = float(live_target[1])
                    geometry_source = 'Gazebo world'
                else:
                    target_x_for_yaw = float(target_x)
                    target_y_for_yaw = float(target_y)
                target_yaw = math.atan2(
                    target_y_for_yaw - robot_y,
                    target_x_for_yaw - robot_x,
                )
                error = math.atan2(
                    math.sin(float(target_yaw) - current_yaw),
                    math.cos(float(target_yaw) - current_yaw),
                )

                if abs(error) <= tolerance:
                    stable_samples += 1
                    self._hard_stop(repeat=3)
                    if stable_samples >= required_stable_samples:
                        self._hard_stop(repeat=10)
                        node.get_logger().info(
                            '抓取位快速旋转校准完成并已强制制动：'
                            f'底盘=({robot_x:.3f}, {robot_y:.3f}, '
                            f'{current_yaw:.3f}rad)，'
                            f'物块=({target_x_for_yaw:.3f}, '
                            f'{target_y_for_yaw:.3f})，'
                            f'目标航向={target_yaw:.3f}rad，'
                            f'航向误差={abs(error):.3f}rad，'
                            f'稳定帧={stable_samples}/'
                            f'{required_stable_samples}，'
                            f'坐标系={geometry_source}'
                        )
                        return True
                    continue
                stable_samples = 0

                # Bang-bang style feedback control: rotate quickly for a
                # large error, then use a short bounded finishing command.
                # This intentionally has no PID integral/derivative tail.
                absolute_error = abs(error)
                if absolute_error >= 0.45:
                    speed = maximum_velocity
                elif absolute_error >= 0.20:
                    speed = min(maximum_velocity, 0.85)
                elif absolute_error >= 0.10:
                    speed = min(maximum_velocity, 0.50)
                else:
                    speed = min(maximum_velocity, 0.28)
                angular_velocity = math.copysign(speed, error)

                node.publish_velocity(
                    linear_x=0.0,
                    angular_z=angular_velocity,
                )
                now = time.monotonic()
                if now >= next_log_at:
                    node.get_logger().info(
                        '抓取航向快速旋转状态：'
                        f'底盘=({robot_x:.3f}, {robot_y:.3f}, '
                        f'{current_yaw:.3f}rad)，'
                        f'目标=({target_x_for_yaw:.3f}, '
                        f'{target_y_for_yaw:.3f}, '
                        f'{target_yaw:.3f}rad)，'
                        f'误差={error:.3f}rad，'
                        f'cmd_wz={angular_velocity:.3f}rad/s，'
                        f'坐标系={geometry_source}'
                    )
                    next_log_at = now + 0.5

            node.get_logger().error(
                '抓取位实时反馈快速旋转超时'
            )
            return False
        finally:
            self._hard_stop(repeat=10)

    def _known_grasp_geometry_ready(
        self,
        target_x,
        target_y,
        desired_distance,
        distance_tolerance,
        yaw_tolerance,
        target_model=None,
        require_world_yaw=True,
    ):
        """Validate live pickup distance and, when requested, world yaw.

        Once OpenCV has centred the cube, the camera optical axis is the
        authoritative heading reference.  The line from ``base_footprint``
        to the cube is offset from that optical axis by the camera/arm
        mounting geometry, so applying the world-bearing gate again can
        incorrectly reject a visually centred grasp pose.
        """
        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                'base_footprint',
                Time(),
            )
        except TransformException:
            return False

        (
            geometry_target_x,
            geometry_target_y,
            robot_x,
            robot_y,
            geometry_source,
        ) = self._pickup_distance_geometry(
            target_model,
            target_x,
            target_y,
            float(transform.transform.translation.x),
            float(transform.transform.translation.y),
        )
        dx = geometry_target_x - robot_x
        dy = geometry_target_y - robot_y
        actual_distance = math.hypot(dx, dy)
        desired_yaw = math.atan2(dy, dx)
        current_yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        # Keep position and heading in the same frame.  When the distance
        # geometry comes from Gazebo world, comparing its bearing with the
        # AMCL/map yaw mixes two frames and can create a false 0.3--0.4 rad
        # error immediately after the world-frame rotation has succeeded.
        if geometry_source == 'Gazebo world':
            robot_model = str(self.node.get_parameter(
                'gazebo_robot_model'
            ).value).strip()
            live_robot = self._gazebo_model_positions.get(robot_model)
            if live_robot is not None:
                current_yaw = float(live_robot[2])
        yaw_error = abs(math.atan2(
            math.sin(desired_yaw - current_yaw),
            math.cos(desired_yaw - current_yaw),
        ))
        distance_error = abs(
            actual_distance - float(desired_distance)
        )
        minimum_safe_distance = max(0.0, float(
            self.node.get_parameter(
                'pickup_minimum_safe_distance_m'
            ).value
        ))

        ready = (
            actual_distance >= minimum_safe_distance
            and
            distance_error <= max(0.01, float(distance_tolerance))
            and (
                not require_world_yaw
                or yaw_error <= max(0.05, float(yaw_tolerance))
            )
        )
        self.node.get_logger().info(
            '已知物块抓取几何校验：'
            f'实际距离={actual_distance:.3f}m，'
            f'距离误差={distance_error:.3f}m，'
            f'安全下限={minimum_safe_distance:.3f}m，'
            f'航向误差={yaw_error:.3f}rad，'
            f'航向基准={"世界坐标" if require_world_yaw else "OpenCV已确认"}，'
            f'量测坐标系={geometry_source}，'
            f'结果={ready}'
        )
        return ready

    def _drop_handoff_ready(self, target_x, target_y, target_yaw):
        """Require centreline alignment and a settled predicted stop point."""
        accurate = self._accurate_base_pose_in_map(use_map_yaw=False)
        if accurate is None:
            return False
        robot_x, robot_y, robot_yaw = accurate
        forward_x = math.cos(float(target_yaw))
        forward_y = math.sin(float(target_yaw))
        dx = float(target_x) - robot_x
        dy = float(target_y) - robot_y
        longitudinal = dx * forward_x + dy * forward_y
        lateral = -dx * forward_y + dy * forward_x
        lateral_tolerance = max(0.02, float(self.node.get_parameter(
            'drop_handoff_lateral_tolerance_m').value))
        longitudinal_tolerance = max(0.03, float(self.node.get_parameter(
            'drop_handoff_longitudinal_tolerance_m').value))
        velocity = self._gazebo_model_velocities.get(
            str(self.node.get_parameter('gazebo_robot_model').value).strip(),
            (0.0, 0.0),
        )
        closing_speed = max(
            0.0,
            float(velocity[0]) * forward_x
            + float(velocity[1]) * forward_y,
        )
        decel = 2.0 if bool(getattr(
            self.node, 'carried_motion_profile_active', False)) else 3.6
        predicted_lead = min(0.30, closing_speed * closing_speed / (2.0 * decel))
        predicted_longitudinal = longitudinal - predicted_lead
        ready = (
            abs(lateral) <= max(0.02, lateral_tolerance)
            and abs(predicted_longitudinal) <= max(0.03, longitudinal_tolerance)
        )
        if ready:
            self.node.get_logger().info(
                '已进入投放中心线交接条件：'
                f'横向误差={lateral:.3f}m，'
                f'预测纵向误差={predicted_longitudinal:.3f}m，'
                f'刹停预估={predicted_lead:.3f}m'
            )
        return ready

    def _drop_a_control_handoff_ready(self, target_x, target_y, target_yaw):
        """Handoff only inside the final A-zone 2D alignment corridor."""
        accurate = self._accurate_base_pose_in_map(use_map_yaw=False)
        if accurate is None:
            return False
        robot_x, robot_y, robot_yaw = accurate
        forward_x = math.cos(float(target_yaw))
        forward_y = math.sin(float(target_yaw))
        dx = float(target_x) - robot_x
        dy = float(target_y) - robot_y
        longitudinal = dx * forward_x + dy * forward_y
        lateral = -dx * forward_y + dy * forward_x
        yaw_error = abs(math.atan2(
            math.sin(float(target_yaw) - robot_yaw),
            math.cos(float(target_yaw) - robot_yaw),
        ))
        velocity = self._gazebo_model_velocities.get(
            str(self.node.get_parameter('gazebo_robot_model').value).strip(),
            (0.0, 0.0),
        )
        speed = math.hypot(float(velocity[0]), float(velocity[1]))
        min_distance = float(self.node.get_parameter(
            'drop_a_control_handoff_min_distance_m').value)
        max_distance = float(self.node.get_parameter(
            'drop_a_control_handoff_max_distance_m').value)
        lateral_tolerance = float(self.node.get_parameter(
            'drop_a_control_handoff_lateral_tolerance_m').value)
        yaw_tolerance = float(self.node.get_parameter(
            'drop_a_control_handoff_yaw_tolerance_rad').value)
        speed_limit = float(self.node.get_parameter(
            'drop_a_control_handoff_speed_limit_mps').value)
        ready = (
            min_distance <= longitudinal <= max_distance
            and abs(lateral) <= lateral_tolerance
            and yaw_error <= yaw_tolerance
            and speed <= speed_limit
        )
        if ready:
            self.node.get_logger().info(
                'A区进入最终投放控制走廊：'
                f'最终纵向距离={longitudinal:.3f}m，'
                f'横向误差={lateral:.3f}m，'
                f'航向误差={yaw_error:.3f}rad，速度={speed:.3f}m/s'
            )
        return ready

    def _base_position_ready(self, target_x, target_y, tolerance):
        """Return true once the base reaches a position-only hand-off."""
        accurate = self._accurate_base_pose_in_map()
        if accurate is not None:
            robot_x, robot_y, _ = accurate
        else:
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            except TransformException:
                return False
            robot_x = float(transform.transform.translation.x)
            robot_y = float(transform.transform.translation.y)

        error = math.hypot(
            robot_x - float(target_x),
            robot_y - float(target_y),
        )
        if error > max(0.02, float(tolerance)):
            return False

        self.node.get_logger().info(
            f'已进入投放位置交接容差：平面误差={error:.3f}m'
        )
        return True

    def _base_pose_handoff_ready(
        self,
        target_x,
        target_y,
        target_yaw,
        position_tolerance,
        yaw_tolerance,
    ):
        """Stop MPPI immediately on position; refine yaw in later stages."""
        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                'base_footprint',
                Time(),
            )
        except TransformException:
            return False

        position_error = math.hypot(
            float(transform.transform.translation.x) - float(target_x),
            float(transform.transform.translation.y) - float(target_y),
        )
        current_yaw = self._yaw_from_orientation(
            transform.transform.rotation
        )
        yaw_error = abs(math.atan2(
            math.sin(float(target_yaw) - current_yaw),
            math.cos(float(target_yaw) - current_yaw),
        ))
        ready = position_error <= max(0.02, float(position_tolerance))
        if ready:
            self.node.get_logger().info(
                'MPPI已进入投放入口位置容差，立即停车：'
                f'位置误差={position_error:.3f}m，'
                f'待后续修正航向误差={yaw_error:.3f}rad'
            )
        return ready

    def _rotate_to_absolute_yaw(
        self,
        target_yaw,
        stop_condition,
        maximum_velocity_override=None,
        label='投放位车头回正',
        pickup_departure=False,
    ):
        """Use wrapped-angle PID for an in-place map-frame rotation."""
        node = self.node
        tolerance = (
            max(0.05, float(node.get_parameter(
                'pickup_departure_turn_goal_tolerance_rad').value))
            if pickup_departure else
            max(0.05, float(node.get_parameter(
                'drop_yaw_tolerance_rad').value))
        )
        maximum_velocity = max(
            0.06,
            float(node.get_parameter(
                'pickup_departure_turn_effective_max_velocity_rps'
                if pickup_departure else 'drop_yaw_max_velocity_rps'
            ).value),
        )
        if maximum_velocity_override is not None:
            maximum_velocity = max(
                0.06,
                min(maximum_velocity, float(maximum_velocity_override)),
            )
        if pickup_departure:
            # Estimate from the actual wrapped error, not the absolute target
            # angle. A target near -pi/pi can otherwise be mistaken for a
            # short turn and hit the minimum timeout before final settling.
            try:
                initial_transform = self.tf_buffer.lookup_transform(
                    'map', 'base_footprint', Time()
                )
                initial_yaw = self._yaw_from_orientation(
                    initial_transform.transform.rotation
                )
            except TransformException:
                initial_yaw = 0.0
            accurate_initial = self._accurate_base_pose_in_map(
                use_map_yaw=False
            )
            if accurate_initial is not None:
                initial_yaw = accurate_initial[2]
            initial_error = abs(math.atan2(
                math.sin(float(target_yaw) - initial_yaw),
                math.cos(float(target_yaw) - initial_yaw),
            ))
            fast_threshold = float(node.get_parameter(
                'pickup_departure_turn_fast_threshold_rad').value)
            middle_threshold = float(node.get_parameter(
                'pickup_departure_turn_middle_threshold_rad').value)
            final_threshold = float(node.get_parameter(
                'pickup_departure_turn_final_threshold_rad').value)
            fast_speed = max(0.1, float(node.get_parameter(
                'pickup_departure_turn_effective_max_velocity_rps').value))
            middle_speed = max(0.1, float(node.get_parameter(
                'pickup_departure_turn_middle_velocity_rps').value))
            low_speed = max(0.1, float(node.get_parameter(
                'pickup_departure_turn_low_velocity_rps').value))
            final_speed = max(0.1, float(node.get_parameter(
                'pickup_departure_turn_final_velocity_rps').value))
            estimated = (
                max(0.0, initial_error - fast_threshold) / fast_speed
                + max(0.0, min(initial_error, fast_threshold)
                      - middle_threshold) / middle_speed
                + max(0.0, min(initial_error, middle_threshold)
                      - final_threshold) / low_speed
                + min(initial_error, final_threshold) / final_speed
            )
            timeout_sec = max(
                float(node.get_parameter(
                    'pickup_departure_turn_timeout_min_sec').value),
                min(
                    float(node.get_parameter(
                        'pickup_departure_turn_timeout_max_sec').value),
                    estimated * 1.5 + float(node.get_parameter(
                        'pickup_departure_turn_timeout_margin_sec').value),
                ),
            )
            node.get_logger().info(
                f'抓取后转向动态超时={timeout_sec:.1f}s，'
                f'初始航向误差={initial_error:.3f}rad，'
                f'预计转向={estimated:.1f}s'
            )
        else:
            timeout_sec = max(1.0, float(node.get_parameter(
                'drop_yaw_timeout_sec').value))
        deadline = time.monotonic() + timeout_sec
        next_diagnostic_at = time.monotonic()
        pid = self._new_angle_pid()
        stable_samples = 0

        node.get_logger().info(
            f'开始{label}：'
            f'target_yaw={float(target_yaw):.3f}rad，'
            f'最大角速度={maximum_velocity:.3f}rad/s，'
            f'允许误差={tolerance:.3f}rad'
        )

        try:
            while rclpy.ok() and time.monotonic() < deadline:
                if stop_condition is not None and stop_condition():
                    return False

                rclpy.spin_once(node, timeout_sec=0.05)
                try:
                    transform = self.tf_buffer.lookup_transform(
                        'map',
                        'base_footprint',
                        Time(),
                    )
                except TransformException:
                    node.publish_stop()
                    continue

                # AMCL map yaw lags during an in-place turn and can report the
                # drop heading as converged while the chassis is still ~1 rad
                # off in the Gazebo world.  Prefer the drift-free anchor yaw so
                # the correction actually reaches the requested release heading;
                # the following trim then only has to remove a small position
                # error instead of a large residual yaw.
                accurate = self._accurate_base_pose_in_map(
                    use_map_yaw=False
                )
                if accurate is not None:
                    current_yaw = accurate[2]
                else:
                    current_yaw = self._yaw_from_orientation(
                        transform.transform.rotation
                    )
                error = math.atan2(
                    math.sin(float(target_yaw) - current_yaw),
                    math.cos(float(target_yaw) - current_yaw),
                )
                if abs(error) <= tolerance:
                    stable_samples += 1
                    required_samples = max(1, int(node.get_parameter(
                        'pickup_departure_turn_stable_samples').value
                    )) if pickup_departure else 1
                    if stable_samples < required_samples:
                        node.publish_stop()
                        continue
                    # The in-place turn can still carry angular momentum when
                    # the error first drops below tolerance.  Declaring done
                    # immediately lets the chassis coast past the 0.05 rad
                    # drop-acceptance band, which then reports a spurious
                    # yaw_error and triggers a redundant trim re-turn.  Hold
                    # zero velocity and re-measure so the heading is genuinely
                    # settled before handing back.
                    hold_deadline = min(
                        deadline,
                        time.monotonic() + max(0.1, float(
                            node.get_parameter(
                                'pickup_departure_turn_stop_hold_sec'
                            ).value
                        ) if pickup_departure else 0.50),
                    )
                    while (
                        rclpy.ok()
                        and time.monotonic() < hold_deadline
                    ):
                        if stop_condition is not None and stop_condition():
                            return False
                        node.publish_stop()
                        rclpy.spin_once(node, timeout_sec=0.05)

                    settled = self._accurate_base_pose_in_map(
                        use_map_yaw=False
                    )
                    if settled is not None:
                        settled_yaw = settled[2]
                    else:
                        try:
                            settled_transform = (
                                self.tf_buffer.lookup_transform(
                                    'map',
                                    'base_footprint',
                                    Time(),
                                )
                            )
                        except TransformException:
                            settled_yaw = None
                        else:
                            settled_yaw = self._yaw_from_orientation(
                                settled_transform.transform.rotation
                            )
                    if settled_yaw is not None:
                        settled_error = abs(math.atan2(
                            math.sin(float(target_yaw) - settled_yaw),
                            math.cos(float(target_yaw) - settled_yaw),
                        ))
                        if settled_error <= tolerance:
                            node.get_logger().info(
                                f'{label}完成：'
                                f'航向误差={settled_error:.3f}rad'
                            )
                            return True
                    continue

                stable_samples = 0
                if pickup_departure:
                    magnitude = abs(error)
                    if magnitude > float(node.get_parameter(
                        'pickup_departure_turn_fast_threshold_rad').value
                    ):
                        maximum_velocity = float(node.get_parameter(
                            'pickup_departure_turn_effective_max_velocity_rps'
                        ).value)
                    elif magnitude > float(node.get_parameter(
                        'pickup_departure_turn_middle_threshold_rad').value
                    ):
                        maximum_velocity = float(node.get_parameter(
                            'pickup_departure_turn_middle_velocity_rps'
                        ).value)
                    elif magnitude > float(node.get_parameter(
                        'pickup_departure_turn_final_threshold_rad').value
                    ):
                        maximum_velocity = float(node.get_parameter(
                            'pickup_departure_turn_low_velocity_rps').value)
                    else:
                        maximum_velocity = float(node.get_parameter(
                            'pickup_departure_turn_final_velocity_rps'
                        ).value)
                velocity = self._bounded_pid_angular_velocity(
                    pid,
                    error,
                    maximum_velocity,
                    tolerance,
                )
                node.publish_velocity(angular_z=velocity)

                now = time.monotonic()
                if now >= next_diagnostic_at:
                    node.get_logger().info(
                        '车头回正状态：'
                        f'current_yaw={current_yaw:.3f}rad，'
                        f'误差={error:.3f}rad，'
                        f'角速度指令={velocity:.3f}rad/s'
                    )
                    next_diagnostic_at = now + 0.5

            node.get_logger().error(f'{label}航向对准超时')
            return False
        finally:
            node.publish_stop()

    def _rolling_route_handoff(
        self,
        target_x,
        target_y,
        target_yaw,
        stop_condition,
        label,
        preferred_route_yaw=None,
    ):
        """Rotate in place toward the target bearing when it lies behind.

        MPPI's sampled turn-around is unreliable near 180 deg (it oscillates
        between CW and CCW), so for a large heading error rotate
        deterministically with the anchor yaw, then re-anchor AMCL before
        handing back to Nav2.
        """
        node = self.node
        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        accurate = self._accurate_base_pose_in_map(use_map_yaw=False)
        if accurate is not None:
            current_x, current_y, current_yaw = accurate
        else:
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            except TransformException:
                node.get_logger().error(f'{label}无法读取底盘位姿')
                return False
            current_x = float(transform.transform.translation.x)
            current_y = float(transform.transform.translation.y)
            current_yaw = self._yaw_from_orientation(
                transform.transform.rotation
            )

        route_yaw = math.atan2(
            float(target_y) - current_y,
            float(target_x) - current_x,
        )
        heading_error = math.atan2(
            math.sin(route_yaw - current_yaw),
            math.cos(route_yaw - current_yaw),
        )

        if abs(heading_error) < 1.50:
            node.get_logger().info(
                f'{label}目标在前方，直接交给A*+MPPI连续起步'
            )
            return True

        node.get_logger().warning(
            f'{label}目标位于车头后方，原地转向目标方位角：'
            f'航向差={heading_error:+.3f}rad'
        )
        if not self._rotate_to_absolute_yaw(
            route_yaw,
            stop_condition,
            maximum_velocity_override=float(node.get_parameter(
                'drop_final_yaw_max_velocity_rps'
            ).value),
            label=f'{label}车头转向目标',
        ):
            return False
        # Reset AMCL yaw after the in-place turn before A* plans the route.
        if not self._reanchor_after_turn():
            return False
        return True

    def _trim_drop_base_position(
        self,
        target_x,
        target_y,
        target_yaw,
        stop_condition,
        is_zone_a=False,
    ):
        """Finish the last centimetres along the drop approach axis.

        The drop heading is fixed by the entry side (yaw=0 for the left entry,
        yaw=pi for the right entry); the release point is a fixed forward/
        lateral offset that only matches that heading.  So this controller
        only drives forward/backward along that x-axis while holding the drop
        heading, instead of steering toward the target bearing (which would
        rotate the chassis away from the release heading). Lateral errors
        outside the trim deadband require collision-checked Nav2 recovery.
        """
        node = self.node
        # Low-speed closed-loop trim: approach at <=0.05 m/s so inertial
        # coasting is sub-millimetre.  Stop inside a 10 cm longitudinal
        # deadband (the drop acceptance already tolerates ~0.28 m, so grinding
        # to 1 cm only wastes time), then hold zero velocity so the caster
        # wheels cannot drift afterwards.
        position_deadband = 0.10
        yaw_deadband = max(
            0.05,
            float(node.get_parameter('drop_yaw_tolerance_rad').value),
        )
        maximum_speed = 0.05
        maximum_angular_velocity = 0.30
        is_zone_a_trim = bool(is_zone_a)
        timeout_sec = max(2.0, float(node.get_parameter(
            'drop_position_trim_timeout_sec'
        ).value))
        intermediate_stop_distance = max(0.05, float(node.get_parameter(
            'drop_a_intermediate_stop_distance_m').value))
        intermediate_hold_sec = max(0.1, float(node.get_parameter(
            'drop_a_intermediate_stop_settle_sec').value))
        hold_sec = max(0.1, float(node.get_parameter(
            'drop_a_final_stop_settle_sec').value))
        intermediate_stopped = False
        timeout_initialized = False
        deadline = time.monotonic() + timeout_sec
        next_diagnostic_at = time.monotonic()
        forward_x = math.cos(float(target_yaw))
        forward_y = math.sin(float(target_yaw))

        node.get_logger().info(
            f'投放前低速闭环精调到底盘位置'
            f'({float(target_x):.3f}, {float(target_y):.3f})，'
            f'沿朝向yaw={float(target_yaw):.3f}rad纵向修正'
        )

        try:
            while rclpy.ok() and time.monotonic() < deadline:
                if stop_condition is not None and stop_condition():
                    return False

                rclpy.spin_once(node, timeout_sec=0.05)
                accurate = self._accurate_base_pose_in_map(
                    use_map_yaw=False
                )
                if accurate is not None:
                    robot_x, robot_y, current_yaw = accurate
                else:
                    try:
                        transform = self.tf_buffer.lookup_transform(
                            'map',
                            'base_footprint',
                            Time(),
                        )
                    except TransformException:
                        node.publish_stop()
                        continue
                    robot_x = float(transform.transform.translation.x)
                    robot_y = float(transform.transform.translation.y)
                    current_yaw = self._yaw_from_orientation(
                        transform.transform.rotation
                    )
                dx = float(target_x) - robot_x
                dy = float(target_y) - robot_y

                lateral_error = -dx * forward_y + dy * forward_x
                if is_zone_a_trim and not timeout_initialized:
                    initial_longitudinal = abs(dx * forward_x + dy * forward_y)
                    fast_threshold = float(node.get_parameter(
                        'drop_a_trim_fast_threshold_m').value)
                    final_threshold = float(node.get_parameter(
                        'drop_a_trim_final_threshold_m').value)
                    fast_speed = max(0.02, float(node.get_parameter(
                        'drop_a_trim_fast_speed_mps').value))
                    middle_speed = max(0.02, float(node.get_parameter(
                        'drop_a_trim_middle_speed_mps').value))
                    final_speed = max(0.02, float(node.get_parameter(
                        'drop_a_trim_final_speed_mps').value))
                    fast_distance = max(0.0, initial_longitudinal - fast_threshold)
                    middle_distance = max(
                        0.0,
                        min(initial_longitudinal, fast_threshold)
                        - final_threshold,
                    )
                    final_distance = min(initial_longitudinal, final_threshold)
                    estimated = (
                        fast_distance / fast_speed
                        + middle_distance / middle_speed
                        + final_distance / final_speed
                        + intermediate_hold_sec
                        + hold_sec
                    )
                    scale = max(1.0, float(node.get_parameter(
                        'drop_a_trim_timeout_scale').value))
                    margin = max(0.0, float(node.get_parameter(
                        'drop_a_trim_timeout_margin_sec').value))
                    minimum = max(2.0, float(node.get_parameter(
                        'drop_a_trim_timeout_min_sec').value))
                    maximum = max(minimum, float(node.get_parameter(
                        'drop_a_trim_timeout_max_sec').value))
                    timeout_sec = min(
                        maximum,
                        max(minimum, estimated * scale + margin),
                    )
                    deadline = time.monotonic() + timeout_sec
                    timeout_initialized = True
                    node.get_logger().info(
                        f'A区精调动态超时={timeout_sec:.1f}s，'
                        f'初始纵向误差={initial_longitudinal:.3f}m，'
                        f'预计耗时={estimated:.1f}s'
                    )
                if abs(lateral_error) > position_deadband:
                    node.get_logger().warning(
                        f'投放横向误差={lateral_error:.3f}m，纵向精调无法修复；'
                        '停车校正定位后交给MPPI进行一次有界二维补正'
                    )
                    self._hard_stop(repeat=10)
                    if not self._ensure_sim_localization_consistent(force=True):
                        return False
                    accurate = self._accurate_base_pose_in_map(use_map_yaw=False)
                    if accurate is None:
                        return False
                    try:
                        localized = self.tf_buffer.lookup_transform(
                            'map', 'base_footprint', Time()).transform.translation
                    except TransformException:
                        return False
                    if math.hypot(localized.x - accurate[0],
                                  localized.y - accurate[1]) > 0.20:
                        node.get_logger().error('短程补正定位差仍过大，保持停车')
                        return False
                    recovery_x, recovery_y = compensate_navigation_goal(
                        goal=(target_x, target_y),
                        accurate_position=accurate[:2],
                        localized_position=(localized.x, localized.y),
                    )
                    node.get_logger().info(
                        f'短程补正目标=({recovery_x:.3f},{recovery_y:.3f})，'
                        f'准确底盘=({accurate[0]:.3f},{accurate[1]:.3f})，'
                        f'导航定位=({localized.x:.3f},{localized.y:.3f})'
                    )

                    def recovery_should_stop():
                        return (time.monotonic() >= deadline or
                                (stop_condition is not None and stop_condition()))

                    return self._navigate_to_pose_with_dynamic_guard(
                        recovery_x, recovery_y,
                        float(target_yaw), recovery_should_stop,
                        label='drop_lateral_recovery',
                        arrival_condition=lambda: self._base_position_ready(
                            target_x, target_y, position_deadband),
                        retry_count_override=0,
                        no_progress_timeout_override=min(8.0, timeout_sec),
                    )

                # Longitudinal error along the entry heading (x-axis), plus the
                # small heading error to the same entry yaw.  We never steer
                # toward the target bearing: that would rotate the chassis away
                # from the release heading.
                longitudinal_error = dx * forward_x + dy * forward_y
                if (
                    not intermediate_stopped
                    and abs(longitudinal_error) <= intermediate_stop_distance
                    and abs(longitudinal_error) > position_deadband
                ):
                    node.get_logger().info(
                        f'A区进入中间停车窗口：纵向误差={longitudinal_error:.3f}m，'
                        f'停车稳定{intermediate_hold_sec:.2f}s'
                    )
                    hold_deadline = min(
                        deadline,
                        time.monotonic() + intermediate_hold_sec,
                    )
                    while rclpy.ok() and time.monotonic() < hold_deadline:
                        node.publish_stop()
                        rclpy.spin_once(node, timeout_sec=0.05)
                        if stop_condition is not None and stop_condition():
                            return False
                    intermediate_stopped = True
                    continue

                yaw_error = math.atan2(
                    math.sin(float(target_yaw) - current_yaw),
                    math.cos(float(target_yaw) - current_yaw),
                )

                if (
                    abs(longitudinal_error) <= position_deadband
                    and abs(yaw_error) <= yaw_deadband
                ):
                    # Hold zero velocity so the caster wheels cannot drift
                    # after the stop, then confirm the settled pose.
                    hold_deadline = min(
                        deadline,
                        time.monotonic() + hold_sec,
                    )
                    while (
                        rclpy.ok()
                        and time.monotonic() < hold_deadline
                    ):
                        node.publish_stop()
                        rclpy.spin_once(node, timeout_sec=0.05)
                    settled = self._accurate_base_pose_in_map(
                        use_map_yaw=False
                    )
                    if settled is not None:
                        settled_x, settled_y, settled_yaw = settled
                        settled_longitudinal = (
                            (float(target_x) - settled_x) * forward_x
                            + (float(target_y) - settled_y) * forward_y
                        )
                        settled_yaw_error = abs(math.atan2(
                            math.sin(float(target_yaw) - settled_yaw),
                            math.cos(float(target_yaw) - settled_yaw),
                        ))
                        if (
                            abs(settled_longitudinal)
                            <= position_deadband * 2.0
                            and settled_yaw_error <= yaw_deadband
                        ):
                            node.get_logger().info(
                                '投放低速闭环精调完成：'
                                f'纵向误差='
                                f'{abs(settled_longitudinal):.3f}m，'
                                f'航向误差={settled_yaw_error:.3f}rad'
                            )
                            return True
                    continue

                # Drive forward/backward along the entry axis while holding
                # the drop heading with a small angle correction.
                error_magnitude = abs(longitudinal_error)
                if is_zone_a_trim:
                    if error_magnitude > float(node.get_parameter(
                        'drop_a_trim_fast_threshold_m').value
                    ):
                        speed_limit = float(node.get_parameter(
                            'drop_a_trim_fast_speed_mps').value
                        )
                    elif error_magnitude > float(node.get_parameter(
                        'drop_a_trim_final_threshold_m').value
                    ):
                        speed_limit = float(node.get_parameter(
                            'drop_a_trim_middle_speed_mps').value
                        )
                    else:
                        speed_limit = float(node.get_parameter(
                            'drop_a_trim_final_speed_mps').value
                        )
                    speed_limit = max(0.02, speed_limit)
                else:
                    speed_limit = maximum_speed
                linear_velocity = max(
                    -speed_limit,
                    min(speed_limit, 0.5 * longitudinal_error),
                )
                angular_velocity = max(
                    -maximum_angular_velocity,
                    min(maximum_angular_velocity, 0.8 * yaw_error),
                )
                node.publish_velocity(
                    linear_x=linear_velocity,
                    angular_z=angular_velocity,
                )

                now = time.monotonic()
                if now >= next_diagnostic_at:
                    node.get_logger().info(
                        '投放精调状态：'
                        f'base=({robot_x:.3f}, {robot_y:.3f})，'
                        f'纵向误差={longitudinal_error:.3f}m，'
                        f'航向误差={yaw_error:.3f}rad，'
                        f'cmd=({linear_velocity:.3f}m/s, '
                        f'{angular_velocity:.3f}rad/s)'
                    )
                    next_diagnostic_at = now + 1.0

            node.get_logger().error(
                f'投放位置精调超时：{timeout_sec:.1f}s'
            )
            return False
        finally:
            node.publish_stop()

    def _adjust_known_pickup_distance(
        self,
        target_x,
        target_y,
        desired_distance,
        stop_condition,
        target_model=None,
    ):
        """Trim live distance while preserving the camera-calibrated heading.

        The early MPPI hand-off intentionally allows a wider position band to
        prevent overshoot.  The world file coordinates are only nominal: cube
        dynamics can shift a model by several centimetres before pickup.  Use
        the live Gazebo model position for range, but do not rotate toward its
        geometric bearing here: the fixed arm trajectory has a measured lateral
        grasp offset and the preceding camera centring step already calibrates
        that heading.  The low camera loses the cube during this final segment,
        so the calibrated heading must remain unchanged.
        """
        node = self.node
        tolerance = max(
            0.01,
            float(node.get_parameter(
                'pickup_distance_tolerance_m'
            ).value),
        )
        maximum_speed = max(
            0.03,
            float(node.get_parameter(
                'pickup_distance_adjust_speed_mps'
            ).value),
        )
        timeout_sec = max(
            1.0,
            float(node.get_parameter(
                'pickup_distance_adjust_timeout_sec'
            ).value),
        )
        deadline = time.monotonic() + timeout_sec
        _next_diag_at = time.monotonic()

        node.get_logger().info(
            f'低速闭环微调抓取距离到{desired_distance:.3f}m'
        )

        try:
            while rclpy.ok() and time.monotonic() < deadline:
                if stop_condition is not None and stop_condition():
                    return False

                rclpy.spin_once(node, timeout_sec=0.05)

                try:
                    transform = self.tf_buffer.lookup_transform(
                        'map',
                        'base_footprint',
                        Time(),
                    )
                except TransformException:
                    node.publish_stop()
                    continue

                (
                    range_target_x,
                    range_target_y,
                    robot_x,
                    robot_y,
                    range_source,
                ) = self._pickup_distance_geometry(
                    target_model,
                    target_x,
                    target_y,
                    float(transform.transform.translation.x),
                    float(transform.transform.translation.y),
                )

                delta_x = range_target_x - robot_x
                delta_y = range_target_y - robot_y
                actual_distance = math.hypot(
                    delta_x,
                    delta_y,
                )
                error = actual_distance - float(desired_distance)

                if abs(error) <= tolerance:
                    node.get_logger().info(
                        '抓取实时距离微调完成：'
                        f'实际距离={actual_distance:.3f}m，'
                        f'误差={error:+.3f}m，'
                        '已保持视觉标定航向，'
                        f'量距坐标系={range_source}，'
                        f'实时目标=({range_target_x:.3f}, '
                        f'{range_target_y:.3f})'
                    )
                    return True

                linear_velocity = max(
                    -maximum_speed,
                    min(maximum_speed, 0.8 * error),
                )
                if (
                    abs(error) > tolerance
                    and abs(linear_velocity) < 0.03
                ):
                    linear_velocity = math.copysign(
                        0.03,
                        linear_velocity,
                    )

                node.publish_velocity(
                    linear_x=linear_velocity,
                    angular_z=0.0,
                )

                now = time.monotonic()
                if now >= _next_diag_at:
                    node.get_logger().warning(
                        '抓取距离微调诊断：'
                        f'实际距离={actual_distance:.3f}m，'
                        f'误差={error:+.3f}m，'
                        f'命令={linear_velocity:+.3f}m/s，'
                        f'底盘=({robot_x:.3f}, {robot_y:.3f})，'
                        f'物块=({range_target_x:.3f}, '
                        f'{range_target_y:.3f})，'
                        f'坐标系={range_source}'
                    )
                    _next_diag_at = now + 1.0

            node.get_logger().error('抓取距离微调超时')
            return False
        finally:
            node.publish_stop()

    def execute_pickup_ready(
        self,
        target_class,
        stop_condition,
    ):
        node = self.node
        target_class = str(target_class).strip()

        if not target_class:
            node.get_logger().error('抓取目标类别不能为空')
            return False

        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        node.get_logger().info(
            f'开始寻找抓取目标：{target_class}'
        )

        target = search_for_target(
            node=node,
            detector=self.detector,
            tf_buffer=self.tf_buffer,
            target_class=target_class,
            observation_target=str(
                node.get_parameter('observation_target').value
            ),
            initial_wait_sec=float(
                node.get_parameter('detection_wait_sec').value
            ),
            scan_wait_sec=float(
                node.get_parameter('scan_wait_sec').value
            ),
            maximum_age_sec=float(
                node.get_parameter(
                    'detection_maximum_age_sec'
                ).value
            ),
            scan_cmd_vel_topic=str(
                node.get_parameter('scan_cmd_vel_topic').value
            ),
            scan_maximum_angular_velocity=float(
                node.get_parameter(
                    'scan_maximum_angular_velocity'
                ).value
            ),
            scan_yaw_tolerance=float(
                node.get_parameter('scan_yaw_tolerance').value
            ),
            scan_timeout_sec=float(
                node.get_parameter('scan_timeout_sec').value
            ),
            observation_position_tolerance=float(
                node.get_parameter(
                    'observation_position_tolerance'
                ).value
            ),
            stop_condition=stop_condition,
        )

        if target is None:
            node.publish_stop()

            if stop_condition is not None and stop_condition():
                node.get_logger().warning(
                    '搜索目标过程中任务被停止'
                )
            else:
                node.get_logger().error(
                    f'没有找到目标：{target_class}'
                )

            return False

        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        transform = wait_for_transform(
            node,
            self.tf_buffer,
            'map',
            'base_footprint',
            timeout_sec=3.0,
        )

        robot_x = float(transform.transform.translation.x)
        robot_y = float(transform.transform.translation.y)
        target_x = float(target.position.x)
        target_y = float(target.position.y)

        approach = compute_approach_pose(
            robot_x=robot_x,
            robot_y=robot_y,
            target_x=target_x,
            target_y=target_y,
            standoff_distance=float(
                node.get_parameter(
                    'pickup_navigation_distance'
                ).value
            ),
        )

        node.get_logger().info(
            '动态接近点：'
            f'x={approach.x:.3f}，'
            f'y={approach.y:.3f}，'
            f'yaw={approach.yaw:.3f}'
        )

        success = self._navigate_to_pose_with_dynamic_guard(
            approach.x,
            approach.y,
            approach.yaw,
            stop_condition,
            label=f'approach_{target_class}',
        )

        if not success:
            node.publish_stop()
            return False

        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        self._hard_stop(repeat=10)
        if not self._adjust_known_pickup_distance(
            target_x,
            target_y,
            float(node.get_parameter('pickup_standoff_distance').value),
            stop_condition,
        ):
            node.get_logger().error(
                '动态物块预接近后低速距离闭环未收敛'
            )
            return False

        node.get_logger().info(
            '动态接近完成，开始底盘相机朝向对准'
        )

        return self._align_to_target(
            target_class,
            stop_condition,
        )

    def _align_to_target(
        self,
        target_class,
        stop_condition,
    ):
        node = self.node
        image_topic = str(
            node.get_parameter(
                'chassis_image_topic'
            ).value
        )
        detection_topic = str(
            node.get_parameter(
                'chassis_detection_topic'
            ).value
        )

        alignment_node = ChassisAlignNode(
            target_class=target_class,
            preview_only=False,
            image_topic=image_topic,
            detection_topic=detection_topic,
        )

        try:
            while (
                rclpy.ok()
                and not alignment_node.completed
                and not alignment_node.failed
            ):
                # 朝向对准与任务管理器使用不同节点，
                # 两者都要spin，以便后续能处理stop指令。
                rclpy.spin_once(node, timeout_sec=0.0)
                rclpy.spin_once(
                    alignment_node,
                    timeout_sec=0.1,
                )

                if stop_condition is not None and stop_condition():
                    alignment_node.publish_stop(repeat=10)
                    node.publish_stop()
                    return False

            success = alignment_node.completed
        finally:
            if rclpy.ok():
                alignment_node.publish_stop(repeat=10)
                node.publish_stop()

            alignment_node.destroy_node()

        if success:
            node.get_logger().info(
                '底盘相机朝向对准完成，'
                '小车已制动，准备继续导航到任务指定区域'
            )
        else:
            node.get_logger().error('底盘相机朝向对准失败')

        return success

    def execute_known_pickup_ready(
        self,
        target_class,
        color,
        destination_waypoint,
        stop_condition,
    ):
        """Navigate to the arm-down pose, then align from OpenCV pixels."""
        node = self.node
        target_class = str(target_class).strip()
        color = str(color).strip()

        if not target_class or not color:
            node.get_logger().error(
                '普通摄像头抓取准备需要目标类别和颜色'
            )
            return False

        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        try:
            wait_for_transform(
                node,
                self.tf_buffer,
                'map',
                'base_footprint',
                # CoStudio can publish immediately after mission_manager is
                # discovered, while map_server/AMCL are still activating.
                # Treat that as startup readiness, not as a failed pickup.
                timeout_sec=15.0,
            )

            if stop_condition is not None and stop_condition():
                node.publish_stop()
                return False
            if not self._ensure_sim_localization_consistent():
                node.publish_stop()
                return False
            # A localization correction may have updated map -> odom.
            transform = wait_for_transform(
                node, self.tf_buffer, 'map', 'base_footprint',
                timeout_sec=3.0,
            )
            robot_x = float(transform.transform.translation.x)
            robot_y = float(transform.transform.translation.y)
            reference_distance = float(
                node.get_parameter(
                    'known_target_reference_distance'
                ).value
            )
            navigation_distance = float(
                node.get_parameter(
                    'pickup_navigation_distance'
                ).value
            )
            grasp_distance = float(
                node.get_parameter(
                    'pickup_standoff_distance'
                ).value
            )
            if (
                navigation_distance <= grasp_distance
                or navigation_distance - grasp_distance > 0.35
            ):
                raise ValueError(
                    '预接近距离配置不合理：'
                    f'grasp={grasp_distance:.2f}m, '
                    f'pre_approach={navigation_distance:.2f}m'
                )
            position_tolerance = float(
                node.get_parameter(
                    'pickup_position_tolerance_m'
                ).value
            )
            yaw_handoff_tolerance = float(
                node.get_parameter(
                    'pickup_yaw_handoff_tolerance_rad'
                ).value
            )
            waypoints = node.get_waypoints()
            destination_pose = waypoints.get(destination_waypoint)

            if destination_pose is None:
                raise ValueError(
                    f'缺少目标区导航点：{destination_waypoint}'
                )

            pickup = select_nearest_known_pickup(
                color=color,
                robot_x=robot_x,
                robot_y=robot_y,
                waypoints=waypoints,
                used_waypoints=self._used_known_pickup_waypoints,
                reference_distance=reference_distance,
                standoff_distance=navigation_distance,
                destination_x=float(destination_pose['x']),
                destination_y=float(destination_pose['y']),
                path_length_fn=node.compute_path_length,
                path_timeout_sec=float(node.get_parameter(
                    'pickup_selection_path_timeout_sec'
                ).value),
            )
        except (RuntimeError, ValueError) as error:
            node.get_logger().error(str(error))
            return False

        node.get_logger().info(
            f'总路线最短的未使用{color}物块：{pickup.waypoint}；'
            f'去程={pickup.travel_distance:.2f}m，'
            f'送达段={pickup.delivery_distance:.2f}m，'
            f'两段总代价={pickup.route_distance:.2f}m，'
            f'物块中心=({pickup.target_x:.3f}, '
            f'{pickup.target_y:.3f})，'
            f'MPPI牵引目标距离={navigation_distance:.3f}m，'
            f'真实抓取交接距离={grasp_distance:.3f}m'
        )

        # The waypoint is the official nominal placement.  Physics and prior
        # contact may move the cube, so use the live model centre for all final
        # pickup corrections while retaining the official point for A* routing.
        nominal_target_x = float(pickup.target_x)
        nominal_target_y = float(pickup.target_y)
        target_x, target_y, target_source = (
            self._live_model_point_in_map(
                pickup.model_name,
                nominal_target_x,
                nominal_target_y,
            )
        )
        correction = math.hypot(
            target_x - nominal_target_x,
            target_y - nominal_target_y,
        )
        node.get_logger().info(
            f'抓取导航统一使用map坐标：'
            f'({target_x:.3f}, {target_y:.3f})，'
            f'来源={target_source}，'
            f'相对标称点修正={correction:.3f}m'
        )

        # Preserve the collision-checked nominal approach bearing, but move
        # the final MPPI goal with the cube's live centre. This is the actual
        # arm-down base pose; there is no later straight TF position trim.
        approach_yaw = float(pickup.yaw)
        approach_x = (
            target_x - math.cos(approach_yaw) * navigation_distance
        )
        approach_y = (
            target_y - math.sin(approach_yaw) * navigation_distance
        )

        if not self._rolling_route_handoff(
            approach_x,
            approach_y,
            approach_yaw,
            stop_condition,
            label='抓取路线',
            preferred_route_yaw=approach_yaw,
        ):
            return False
        node.clear_navigation_costmaps()

        success = self._navigate_to_pose_with_dynamic_guard(
            approach_x,
            approach_y,
            approach_yaw,
            stop_condition,
            use_dynamic_monitor=True,
            label=f'pickup_{pickup.waypoint}',
            arrival_condition=lambda: self._pickup_pose_ready(
                approach_x,
                approach_y,
                approach_yaw,
                float(node.get_parameter(
                    'pickup_pre_approach_position_tolerance_m'
                ).value),
                yaw_handoff_tolerance,
                target_model=pickup.model_name,
                target_x=target_x,
                target_y=target_y,
                desired_distance=navigation_distance,
                distance_tolerance_m=float(node.get_parameter(
                    'pickup_pre_approach_distance_tolerance_m'
                ).value),
                pre_approach=True,
            ),
            no_progress_timeout_override=float(node.get_parameter(
                'pickup_pre_approach_no_progress_timeout_sec'
            ).value),
        )

        if success:
            self._hard_stop(repeat=10)
            if not self._adjust_known_pickup_distance(
                target_x,
                target_y,
                grasp_distance,
                stop_condition,
                target_model=pickup.model_name,
            ):
                node.get_logger().error(
                    '预接近后低速距离闭环未收敛到目标抓取距离'
                )
                return False

        if not success:
            node.publish_stop()
            return False

        if stop_condition is not None and stop_condition():
            node.publish_stop()
            return False

        node.get_logger().info(
            f'已到达{pickup.waypoint}的'
            f'{grasp_distance:.3f}m真实抓取交接位；'
            '底盘已强制停车，立即使用OpenCV测量像素误差并换算角度差'
        )
        self._hard_stop(repeat=10)
        alignment_retry_count = max(0, int(node.get_parameter(
            'opencv_alignment_retry_count'
        ).value))
        alignment_deadline = time.monotonic() + max(2.0, float(
            node.get_parameter(
                'opencv_alignment_total_budget_sec'
            ).value
        ))

        def alignment_should_stop():
            return (
                time.monotonic() >= alignment_deadline
                or (
                    stop_condition is not None
                    and stop_condition()
                )
            )

        alignment_ok = False
        for alignment_attempt in range(alignment_retry_count + 1):
            if time.monotonic() >= alignment_deadline:
                node.get_logger().error(
                    'OpenCV对准已达到总时间预算，停止继续重锁定'
                )
                break
            if alignment_attempt > 0:
                node.get_logger().warning(
                    'OpenCV首次对准丢锁，已强制停车；'
                    f'直接进行第{alignment_attempt + 1}次/'
                    f'{alignment_retry_count + 1}次整幅图像颜色重锁定'
                )
                self._hard_stop(repeat=10)

            alignment_ok = self._align_to_target(
                target_class,
                alignment_should_stop,
            )
            if alignment_ok:
                break

        if not alignment_ok:
            node.get_logger().warning(
                'OpenCV经过有界重锁定后仍未能稳定对准；'
                '改用物块实时坐标完成最终抓取轴校准'
            )

        # OpenCV supplies the fast visual correction, but coloured walls or a
        # delayed frame can occasionally look stationary while the chassis is
        # turning.  Always finish with the live cube bearing from Gazebo/TF.
        # This bounded rotation changes heading only, preserves the validated
        # standoff distance, and prevents a false visual lock from sending the
        # arm down with a large lateral offset.
        if not self._rotate_to_known_pickup_yaw(
            target_x,
            target_y,
            stop_condition,
            target_model=pickup.model_name,
        ):
            node.get_logger().error(
                '物块实时坐标最终抓取轴校准失败'
            )
            return False

        geometry_ready = self._known_grasp_geometry_ready(
            target_x=target_x,
            target_y=target_y,
            desired_distance=grasp_distance,
            distance_tolerance=float(node.get_parameter(
                'known_pose_fallback_position_tolerance_m'
            ).value),
            yaw_tolerance=float(node.get_parameter(
                'known_pose_fallback_yaw_tolerance_rad'
            ).value),
            target_model=pickup.model_name,
            require_world_yaw=True,
        )
        if not geometry_ready:
            node.get_logger().warning(
                '预测制动后的最终抓取几何未通过；执行一次有界MPPI补近，'
                '以实时物块坐标收敛到0.400m后再校验'
            )
            # Reuse the strict recovery path: it has collision-checked MPPI
            # translation, live model coordinates, final yaw braking, and the
            # same arm safety gate.  This handles variable Gazebo braking
            # without restoring the old open-loop TF crawl.
            self._active_pickup = pickup
            if not self.recover_active_pickup_ready(stop_condition):
                self._active_pickup = None
                node.get_logger().error(
                    '有界MPPI补近后抓取几何仍不合格，拒绝启动机械臂'
                )
                return False

        # Keep the chassis stationary here.  The arm must first close, attach,
        # and lift the cube.  Only then may the base perform its short retreat.
        self._active_pickup = pickup
        self._active_pickup_target_class = target_class
        self._used_known_pickup_waypoints.add(pickup.waypoint)

        return True

    def execute_pickup_departure(
        self,
        stop_condition,
        destination=None,
    ):
        """Hand a successful pickup to route planning.

        When the drop zone lies behind the chassis, MPPI cannot turn around by
        itself (in-place rotation is discouraged and reverse is limited).  In
        that case rotate in place to the drop-zone bearing before handing back
        to Nav2, so MPPI starts facing the destination.
        """
        if self._active_pickup is None:
            self.node.get_logger().error(
                '没有已确认的抓取物块，拒绝执行抓取位退出'
            )
            return False

        destination_name = str(destination or '').strip().upper()
        destination_pose = None
        if destination_name:
            try:
                destination_pose = self.node.get_waypoint(
                    destination_to_waypoint(destination_name)
                )
            except ValueError as error:
                self.node.get_logger().error(str(error))
                return False

        needs_boundary_clearance = False
        start = None
        heading_error = 0.0
        route_yaw = 0.0
        if destination_pose is not None:
            try:
                start = wait_for_transform(
                    self.node,
                    self.tf_buffer,
                    'map',
                    'base_footprint',
                    timeout_sec=2.0,
                )
                start_x = float(start.transform.translation.x)
                start_y = float(start.transform.translation.y)
                # Decision must use the drift-free heading: the AMCL map yaw
                # can lag by a large amount after an in-place turn, which
                # under-reports the true heading error and skips the reverse
                # clearance move that far cubes at the map edge need.
                accurate = self._accurate_base_pose_in_map(
                    use_map_yaw=False,
                )
                if accurate is not None:
                    accurate_x, accurate_y, start_yaw = accurate
                else:
                    start_yaw = self._yaw_from_orientation(
                        start.transform.rotation
                    )
                    accurate_x, accurate_y = start_x, start_y
                route_yaw = math.atan2(
                    float(destination_pose['y']) - accurate_y,
                    float(destination_pose['x']) - accurate_x,
                )
                heading_error = math.atan2(
                    math.sin(route_yaw - start_yaw),
                    math.cos(route_yaw - start_yaw),
                )
                # For a large turn (drop zone behind the chassis) rotate in
                # place deterministically: MPPI's sampled turn-around is
                # unreliable near 180 deg (it oscillates between CW/CCW).
                needs_boundary_clearance = abs(heading_error) >= 1.50
            except (RuntimeError, KeyError, TypeError, ValueError) as error:
                self.node.get_logger().warning(
                    f'无法判定抓取位退出几何，直接交给Nav2：{error}'
                )

        if needs_boundary_clearance and start is not None:
            self.node.get_logger().warning(
                '目标区位于抓取车头后方，原地转向目标方位角：'
                f'航向差={heading_error:+.3f}rad'
            )
            if not self._rotate_to_absolute_yaw(
                route_yaw,
                stop_condition,
                label='抓取位车头转向目标区',
                pickup_departure=True,
            ):
                return False
            # The in-place turn desyncs AMCL's yaw (odometry/laser lag); reset
            # it to the Gazebo-truth pose before A* plans the next route.
            if not self._reanchor_after_turn():
                self.node.get_logger().error('拒绝继续导航')
                return False
        else:
            self.node.get_logger().info(
                '抓取完成：目标区不在车头后方，不原地转向，'
                '直接交给A*+MPPI'
            )

        self.node.clear_navigation_costmaps()
        return True

    def recover_active_pickup_ready(self, stop_condition):
        """Reacquire a displaced selected cube and rebuild grasp geometry.

        The arm can occasionally touch a free Gazebo cube before attachment.
        Keep the selected model, read its new world position, then ask MPPI to
        drive directly to the rebuilt arm-down pose. This never relaxes the arm
        capture-volume gate and is intentionally called at most once per cycle.
        """
        node = self.node
        pickup = self._active_pickup
        if pickup is None:
            node.get_logger().error(
                '抓取恢复缺少当前物块，拒绝重试'
            )
            return False
        if self._navigation_should_stop(stop_condition):
            node.publish_stop()
            return False

        # Process a fresh model-states sample after the failed arm subprocess
        # has returned and the free cube has settled.
        settle_deadline = time.monotonic() + 1.0
        while rclpy.ok() and time.monotonic() < settle_deadline:
            rclpy.spin_once(node, timeout_sec=0.05)
            if self._navigation_should_stop(stop_condition):
                node.publish_stop()
                return False

        live_position = self._gazebo_model_positions.get(pickup.model_name)
        if live_position is None:
            node.get_logger().error(
                f'抓取恢复无法读取{pickup.model_name}实时位置'
            )
            return False
        target_x, target_y, target_source = (
            self._live_model_point_in_map(
                pickup.model_name,
                float(pickup.target_x),
                float(pickup.target_y),
            )
        )
        node.get_logger().warning(
            f'物块在首次抓取中发生位移：{pickup.model_name} '
            f'map实时中心=({target_x:.3f}, {target_y:.3f})，'
            f'来源={target_source}；'
            '机械臂已回收，开始一次底盘重定位'
        )

        grasp_distance = float(node.get_parameter(
            'pickup_standoff_distance'
        ).value)
        # The cube is already within a few decimetres.  Nav2 deliberately
        # treats the cube as an obstacle, so asking MPPI for another 0.1--0.3 m
        # path can stall inside the inflated costmap.  Face the live cube and
        # use the bounded range controller for this simulator terminal motion.
        # It runs at <= pickup_distance_adjust_speed_mps and the final geometry
        # gate still enforces pickup_minimum_safe_distance_m before the arm runs.
        if not self._rotate_to_known_pickup_yaw(
            target_x,
            target_y,
            stop_condition,
            target_model=pickup.model_name,
        ):
            return False
        if not self._adjust_known_pickup_distance(
            target_x,
            target_y,
            grasp_distance,
            stop_condition,
            target_model=pickup.model_name,
        ):
            return False
        # Correct the small heading change caused by caster slip during the
        # forward/reverse range trim, then apply the unchanged arm safety gate.
        if not self._rotate_to_known_pickup_yaw(
            target_x,
            target_y,
            stop_condition,
            target_model=pickup.model_name,
        ):
            return False

        if not self._known_grasp_geometry_ready(
            target_x=target_x,
            target_y=target_y,
            desired_distance=grasp_distance,
            distance_tolerance=float(node.get_parameter(
                'known_pose_fallback_position_tolerance_m'
            ).value),
            yaw_tolerance=float(node.get_parameter(
                'known_pose_fallback_yaw_tolerance_rad'
            ).value),
            target_model=pickup.model_name,
        ):
            node.get_logger().error(
                '抓取恢复后底盘几何校验仍未通过，不启动机械臂'
            )
            return False
        node.publish_stop()
        node.get_logger().info(
            '抓取恢复完成：末端限速距离闭环已收敛，'
            '航向快速旋转校准和严格几何校验均通过'
        )
        return True

    def _retreat_after_drop(self, stop_condition):
        """Move 0.15 m away from the released cube before turning.

        The arm is not guaranteed to release on the geometric front side of
        ``base_footprint``.  A hard-coded reverse command can therefore drive
        the chassis *towards* the cube (this is the case at zone A).  Select
        forward/reverse from the live Gazebo geometry while retaining the
        final drop heading and the configured fixed travel distance.
        """
        node = self.node
        distance = max(0.0, float(node.get_parameter(
            'drop_departure_retreat_distance_m'
        ).value))
        if distance <= 0.0:
            return True

        speed = max(0.03, abs(float(node.get_parameter(
            'drop_departure_retreat_speed_mps'
        ).value)))
        timeout_sec = max(1.0, float(node.get_parameter(
            'drop_departure_retreat_timeout_sec'
        ).value))

        try:
            start = wait_for_transform(
                node,
                self.tf_buffer,
                'map',
                'base_footprint',
                timeout_sec=2.0,
            )
        except RuntimeError as error:
            node.get_logger().error(
                f'投放位退出前无法读取底盘位姿：{error}'
            )
            node.publish_stop()
            return False

        start_x = float(start.transform.translation.x)
        start_y = float(start.transform.translation.y)
        start_yaw = self._yaw_from_orientation(start.transform.rotation)
        direction = -1.0
        released_model = self.active_pickup_model
        released_pose = self._gazebo_model_positions.get(released_model)
        if released_pose is not None:
            to_cube_x = float(released_pose[0]) - start_x
            to_cube_y = float(released_pose[1]) - start_y
            forward_projection = (
                math.cos(start_yaw) * to_cube_x
                + math.sin(start_yaw) * to_cube_y
            )
            # Cube in front -> reverse; cube behind -> drive forward.  Either
            # choice monotonically increases the planar cube/base separation.
            direction = -1.0 if forward_projection >= 0.0 else 1.0
            node.get_logger().info(
                f'投放退出方向判定：物块={released_model}，'
                f'纵向投影={forward_projection:+.3f}m，'
                f'选择={"后退" if direction < 0.0 else "前进"}'
            )
        else:
            node.get_logger().warning(
                f'未读到已释放物块{released_model or "<unknown>"}位姿，'
                '投放退出回退为沿入口后退'
            )
        deadline = time.monotonic() + timeout_sec
        node.get_logger().info(
            f'保持投放朝向，以{speed:.2f}m/s'
            f'{"前进" if direction > 0.0 else "后退"}{distance:.2f}m'
            '，使底盘远离已放物块后再交给Nav2'
        )

        try:
            while rclpy.ok() and time.monotonic() < deadline:
                rclpy.spin_once(node, timeout_sec=0.05)
                if self._navigation_should_stop(stop_condition):
                    node.get_logger().warning('投放位安全退出被停止条件中断')
                    return False

                try:
                    current = self.tf_buffer.lookup_transform(
                        'map',
                        'base_footprint',
                        Time(),
                    )
                except TransformException:
                    node.publish_velocity(linear_x=direction * speed)
                    continue

                travelled = math.hypot(
                    float(current.transform.translation.x) - start_x,
                    float(current.transform.translation.y) - start_y,
                )
                if travelled >= distance:
                    node.get_logger().info(
                        f'投放位安全退出完成：实际移动={travelled:.3f}m'
                    )
                    return True
                node.publish_velocity(linear_x=direction * speed)

            node.get_logger().error(
                f'投放位安全退出超时：{timeout_sec:.1f}s'
            )
            return False
        finally:
            node.publish_stop()

    def execute_drop_departure(
        self,
        stop_condition,
        next_waypoint=None,
    ):
        """Retreat first, then let MPPI roll directly onto the next route."""
        if not self._retreat_after_drop(stop_condition):
            # The payload has already been released successfully.  A short
            # retreat is only a preferred departure manoeuvre, so wheel slip
            # or a blocked rear costmap must not invalidate the completed
            # transport cycle.  Stop deterministically and let the following
            # Nav2 goal re-plan from the robot's actual pose.
            self.node.get_logger().warning(
                '投放物已释放，但固定倒车未完成；已强制停车并清理代价地图，'
                '下一段A*将从当前位姿重新规划'
            )
            self._hard_stop(repeat=10)
            self.node.clear_navigation_costmaps()
            return True

        if not next_waypoint:
            self.node.clear_navigation_costmaps()
            return True

        if self.node.get_waypoint(next_waypoint) is None:
            self.node.get_logger().error(
                f'放置后退出缺少下一目标：{next_waypoint}'
            )
            return False
        self.node.get_logger().info(
            '安全后退完成；不原地掉头，下一目标将直接交给MPPI'
            '以滚动轨迹离开放置区'
        )
        self.node.clear_navigation_costmaps()
        return True

    def execute_drop_ready(
        self,
        destination,
        stop_condition,
        slot_index=0,
    ):
        waypoint = destination_to_waypoint(destination)

        target = self.node.get_waypoint(waypoint)

        if target is None:
            self.node.get_logger().error(f'缺少投放导航点：{waypoint}')
            return False

        required_zone_fields = (
            'zone_center_x',
            'zone_center_y',
            'zone_width',
            'zone_height',
        )

        if any(field not in target for field in required_zone_fields):
            self.node.get_logger().error(
                f'{waypoint}缺少放置区边界参数'
            )
            return False

        # Re-anchor AMCL from Gazebo truth before the drop navigation: the
        # long pickup->drop leg lets AMCL drift ~0.17 m, which the anchor-frame
        # release-point gate then rejects.  Repair it while the chassis is
        # stopped so Nav2 drives in a frame that matches the geometry checks.
        if not self._ensure_sim_localization_consistent():
            self.node.publish_stop()
            return False

        # Fill from the centre outwards. With 40 mm spacing, adjacent 30 mm
        # cubes keep a physical gap while all five slots retain boundary
        # margin under the measured bidirectional caster drift.
        slot_order = (0, -1, 1, -2, 2)
        slot_index = max(0, int(slot_index))
        slot_multiplier = slot_order[
            min(slot_index, len(slot_order) - 1)
        ]
        lateral_offset = slot_multiplier * float(
            self.node.get_parameter('drop_slot_spacing_m').value
        )
        entry_distance = max(0.45, float(
            self.node.get_parameter(
                'drop_entry_staging_distance_m'
            ).value
        ))
        base_offset = max(0.0, float(
            self.node.get_parameter(
                'drop_base_longitudinal_offset_m'
            ).value
        ))
        path_timeout = max(0.5, float(
            self.node.get_parameter(
                'drop_entry_path_timeout_sec'
            ).value
        ))
        zone_center_x = float(target['zone_center_x'])
        zone_center_y = float(target['zone_center_y'])

        try:
            selection_transform = self.tf_buffer.lookup_transform(
                'map',
                'base_footprint',
                Time(),
            )
            robot_x = float(
                selection_transform.transform.translation.x
            )
            robot_y = float(
                selection_transform.transform.translation.y
            )
        except TransformException:
            self.node.get_logger().error(
                '无法读取当前位置，不能选择放置区左右入口'
            )
            return False

        path_length_function = getattr(
            self.node,
            'compute_path_length',
            None,
        )
        entry_candidates = []

        for side, yaw in (
            ('左侧', 0.0),
            ('右侧', math.pi),
        ):
            # The base stops on the opposite side of the zone centre from the
            # gripper. This keeps the released cube near the centre for either
            # travel direction instead of assuming every approach faces -X.
            # The official physical footprint is about 0.372 x 0.420 m once
            # the rear caster and drive wheels are included. The marker's
            # short side is only 0.50 m, so keep the base on its centreline.
            # Spread repeated drops along the 1.00 m long side instead.
            candidate_target_x = (
                zone_center_x
                - math.cos(yaw) * base_offset
                + lateral_offset
            )
            # The calibrated waypoint y is the desired chassis centre.  The
            # zone centre remains authoritative only for boundary checks.
            candidate_target_y = float(target.get('y', zone_center_y))
            candidate_entry_x = (
                candidate_target_x
                - math.cos(yaw) * entry_distance
            )
            candidate_entry_y = (
                candidate_target_y
                - math.sin(yaw) * entry_distance
            )
            entry_path_length = None
            inside_path_length = None
            path_length = None

            if callable(path_length_function):
                entry_path_length = path_length_function(
                    candidate_entry_x,
                    candidate_entry_y,
                    yaw,
                    timeout_sec=path_timeout,
                )
                if entry_path_length is not None:
                    # Validate the complete route, including the segment from
                    # the selected side into the official marker.  Ranking
                    # only the outside entry can choose a short side whose
                    # final in-zone base pose is blocked by inflation.
                    inside_path_length = path_length_function(
                        candidate_target_x,
                        candidate_target_y,
                        yaw,
                        start_x=candidate_entry_x,
                        start_y=candidate_entry_y,
                        start_yaw=yaw,
                        timeout_sec=path_timeout,
                    )
                if (
                    entry_path_length is not None
                    and inside_path_length is not None
                ):
                    path_length = entry_path_length + inside_path_length

            straight_distance = math.hypot(
                candidate_entry_x - robot_x,
                candidate_entry_y - robot_y,
            )
            entry_candidates.append({
                'side': side,
                'yaw': yaw,
                'target_x': candidate_target_x,
                'target_y': candidate_target_y,
                'entry_x': candidate_entry_x,
                'entry_y': candidate_entry_y,
                'entry_path_length': entry_path_length,
                'inside_path_length': inside_path_length,
                'path_length': path_length,
                'straight_distance': straight_distance,
            })

        reachable_candidates = [
            candidate
            for candidate in entry_candidates
            if candidate['path_length'] is not None
        ]

        if reachable_candidates:
            selected_entry = min(
                reachable_candidates,
                key=lambda candidate: candidate['path_length'],
            )
            selection_source = 'A*路径长度'
        else:
            selected_entry = min(
                entry_candidates,
                key=lambda candidate: candidate['straight_distance'],
            )
            selection_source = '直线距离后备'

        side = selected_entry['side']
        yaw = selected_entry['yaw']
        target_x = selected_entry['target_x']
        target_y = selected_entry['target_y']
        entry_x = selected_entry['entry_x']
        entry_y = selected_entry['entry_y']

        for candidate in entry_candidates:
            total_path_text = (
                '不可达'
                if candidate['path_length'] is None
                else f"{candidate['path_length']:.2f}m"
            )
            entry_path_text = (
                '不可达'
                if candidate['entry_path_length'] is None
                else f"{candidate['entry_path_length']:.2f}m"
            )
            inside_path_text = (
                '不可达'
                if candidate['inside_path_length'] is None
                else f"{candidate['inside_path_length']:.2f}m"
            )
            self.node.get_logger().info(
                f"{waypoint}{candidate['side']}入口候选："
                f"A*总长={total_path_text}，"
                f"入口段={entry_path_text}，"
                f"区内段={inside_path_text}，"
                f"直线={candidate['straight_distance']:.2f}m"
            )

        self.node.get_logger().info(
            f'前往{str(destination).strip().upper()}区'
            f'投放槽位{slot_index + 1}：'
            f'选择{side}入口（{selection_source}），'
            f'入口=({entry_x:.3f}, {entry_y:.3f})，'
            f'区内目标=({target_x:.3f}, {target_y:.3f})，'
            f'yaw={yaw:.3f}'
        )

        # The selected entry is a path-shape constraint, not a stop point.
        # Send only the in-zone pull-through goal so Nav2 keeps velocity
        # continuous: A* owns the global route and MPPI naturally owns the
        # final 1--2 metres without a cancel/restart hand-off at the entry.
        pull_through_distance = max(0.0, float(
            self.node.get_parameter(
                'drop_mppi_pull_through_distance_m'
            ).value
        ))
        is_zone_a = str(destination).strip().upper() == 'A'
        pre_approach_distance = max(0.0, float(
            self.node.get_parameter('drop_a_pre_approach_distance_m').value
        )) if is_zone_a else 0.0
        forward_x = math.cos(yaw)
        forward_y = math.sin(yaw)
        # For A, stop outside the final slot and let the bounded drop trim own
        # the last 0.50 m. Subtracting the heading vector places the chassis
        # before the target along its entry direction.
        pull_target_x = (
            target_x - forward_x * pre_approach_distance
            + forward_x * pull_through_distance
        )
        pull_target_y = (
            target_y - forward_y * pre_approach_distance
            + forward_y * pull_through_distance
        )
        self.node.get_logger().info(
            '投放采用A*到MPPI连续单目标导航：'
            f'选定入口=({entry_x:.3f}, {entry_y:.3f})，入口不停车；'
            f'期望底盘中心=({target_x:.3f}, {target_y:.3f})，'
            f'牵引目标=({pull_target_x:.3f}, {pull_target_y:.3f})；'
            + ('A区先到0.50m预接近点并停车，再低速进入最终槽位'
               if is_zone_a else
               '最后1--2m由MPPI保持速度连续并完成局部规划')
        )
        self.node.clear_navigation_costmaps()
        # C has the narrowest final approach and its MPPI goal can settle a few
        # centimetres short while still being geometrically recoverable. Let
        # the drop controller take over near the final pose instead of starting
        # three identical 30 s Nav2 retries.
        handoff = (
            lambda: self._base_position_ready(
                target_x, target_y, 0.18
            )
            if str(destination).strip().upper() == 'C'
            else (
                self._drop_a_control_handoff_ready(
                    target_x, target_y, yaw
                )
                if is_zone_a else
                self._drop_handoff_ready(target_x, target_y, yaw)
            )
        )
        success = self._navigate_to_pose_with_dynamic_guard(
            pull_target_x,
            pull_target_y,
            yaw,
            stop_condition,
            label=f'{waypoint}_final_slot_{slot_index + 1}',
            arrival_condition=handoff,
            retry_count_override=2,
            # A-zone terminal motion is handed to the bounded trim early;
            # do not spend 30 seconds repeating the same inflated goal.
            no_progress_timeout_override=(8.0 if is_zone_a else 30.0),
        )
        if not success:
            return False

        if is_zone_a:
            self.node.publish_stop(count=12)
            settle_deadline = time.monotonic() + max(0.2, float(
                self.node.get_parameter('drop_a_pre_approach_settle_sec').value
            ))
            while rclpy.ok() and time.monotonic() < settle_deadline:
                self.node.publish_stop()
                rclpy.spin_once(self.node, timeout_sec=0.05)
                if self._navigation_should_stop(stop_condition):
                    return False
            if not self._trim_drop_base_position(
                target_x, target_y, yaw, stop_condition, is_zone_a=True
            ):
                self.node.get_logger().error('A区预接近后低速投放精调失败')
                return False

        # The final stationary heading is angle PID.
        if not self._rotate_to_absolute_yaw(
            yaw,
            stop_condition,
            maximum_velocity_override=float(self.node.get_parameter(
                'drop_final_yaw_max_velocity_rps'
            ).value),
        ):
            return False

        if not self._wait_for_drop_pose_inside(
            target=target,
            required_yaw=yaw,
            stop_condition=stop_condition,
        ):
            self.node.get_logger().warning(
                '投放位初次几何验收未通过，尝试一次有界低速前移修正'
            )
            if not self._trim_drop_base_position(
                target_x,
                target_y,
                yaw,
                stop_condition,
                is_zone_a=(str(destination).strip().upper() == 'A'),
            ):
                return False
            # The trim holds the drop heading, but its small angle correction
            # plus caster settling can leave a residual yaw.  Restore the exact
            # heading before the strict base/release geometry gate so a correct
            # position is not rejected over a few hundredths of a radian.
            if not self._rotate_to_absolute_yaw(
                yaw,
                stop_condition,
                maximum_velocity_override=float(self.node.get_parameter(
                    'drop_final_yaw_max_velocity_rps'
                ).value),
            ):
                return False
            if not self._wait_for_drop_pose_inside(
                target=target,
                required_yaw=yaw,
                stop_condition=stop_condition,
            ):
                self.node.get_logger().error(
                    '当前底盘轮廓或预测释放点未完整位于投放区内'
                )
                return False

        self.node.get_logger().info(
            f'已到达{str(destination).strip().upper()}'
            '区投放准备位'
        )

        return True

    def _wait_for_drop_pose_inside(
        self,
        target,
        required_yaw,
        stop_condition,
    ):
        """Let the zero-command wheel brake settle before final acceptance."""
        timeout_sec = max(0.2, float(self.node.get_parameter(
            'drop_pose_settle_timeout_sec'
        ).value))
        required_samples = max(1, int(self.node.get_parameter(
            'drop_pose_stable_samples'
        ).value))
        deadline = time.monotonic() + timeout_sec
        stable_samples = 0

        while rclpy.ok() and time.monotonic() < deadline:
            self.node.publish_stop()
            rclpy.spin_once(self.node, timeout_sec=0.05)
            if self._navigation_should_stop(stop_condition):
                return False
            if self._drop_pose_inside_zone(
                target,
                required_yaw,
                log_result=False,
            ):
                stable_samples += 1
                if stable_samples >= required_samples:
                    return self._drop_pose_inside_zone(
                        target,
                        required_yaw,
                        log_result=True,
                    )
            else:
                stable_samples = 0

        # At the timeout boundary, accept the final settled object outcome.
        # With a low simulation frame rate the required consecutive samples
        # can straddle the deadline even though the brake has already settled.
        base_inside = self._drop_base_inside_zone(
            target,
            required_yaw,
            log_result=True,
        )
        release_inside = self._drop_release_inside_zone(
            target,
            required_yaw,
            log_result=True,
        )
        return base_inside and release_inside

    def _accurate_base_pose_in_map(self, use_map_yaw=True):
        """Base pose in map via Gazebo truth and the fixed world->map anchor.

        AMCL drift shifts the ``map -> base_footprint`` transform by up to
        several decimetres.  The anchor is established once and repaired on
        drift, so converting the Gazebo base pose through it gives a stable,
        accurate map pose for the drop acceptance checks.  Returns ``None``
        when the anchor or a Gazebo sample is not yet available.

        ``use_map_yaw=True`` keeps the heading in the AMCL map frame so it
        matches the drop yaw correction.  ``use_map_yaw=False`` derives the
        heading from the Gazebo world yaw through the anchor, which updates
        continuously during an in-place turn (AMCL can lag there); the trim
        controller uses this so its steering does not oscillate.
        """
        anchor = self._world_to_map_anchor
        if anchor is None:
            return None
        robot_model = str(
            self.node.get_parameter('gazebo_robot_model').value
        ).strip()
        robot_state = self._gazebo_model_positions.get(robot_model)
        if robot_state is None:
            return None
        offset_x, offset_y, anchor_yaw = anchor
        cosine = math.cos(anchor_yaw)
        sine = math.sin(anchor_yaw)
        world_x = float(robot_state[0])
        world_y = float(robot_state[1])
        map_x = offset_x + cosine * world_x - sine * world_y
        map_y = offset_y + sine * world_x + cosine * world_y
        if use_map_yaw:
            # Position uses the drift-free anchor, but heading must stay in the
            # same AMCL map frame as the drop yaw correction, otherwise the two
            # disagree by the anchor yaw and the acceptance spuriously reports a
            # yaw error even though the chassis finished its in-place turn.
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            except TransformException:
                return None
            map_yaw = self._yaw_from_orientation(
                transform.transform.rotation
            )
        else:
            world_yaw = float(robot_state[2])
            map_yaw = math.atan2(
                math.sin(world_yaw + anchor_yaw),
                math.cos(world_yaw + anchor_yaw),
            )
        return map_x, map_y, map_yaw

    def _accurate_release_point_in_map(self):
        """Release point in map from Gazebo base truth plus the calibrated drop
        offset.

        The cube is detached with the arm lowered, i.e. at the calibrated
        forward/lateral offset from the base.  During the acceptance check the
        arm is still folded in the carry pose, so its live link6 sits ~0.17 m
        *behind* the base and using it pushed the predicted landing point
        outside the marker.  Apply the same calibrated offset used by
        ``_predicted_release_point`` to the anchor-corrected base pose instead.
        """
        accurate_base = self._accurate_base_pose_in_map(use_map_yaw=False)
        if accurate_base is None:
            return None
        base_x, base_y, base_yaw = accurate_base
        forward = float(
            self.node.get_parameter('drop_release_forward_m').value
        )
        lateral = float(
            self.node.get_parameter('drop_release_lateral_m').value
        )
        release_x = (
            base_x
            + math.cos(base_yaw) * forward
            - math.sin(base_yaw) * lateral
        )
        release_y = (
            base_y
            + math.sin(base_yaw) * forward
            + math.cos(base_yaw) * lateral
        )
        return release_x, release_y, 'anchor+forward'

    def _drop_base_inside_zone(
        self,
        target,
        required_yaw,
        log_result=True,
        yaw_tolerance_override=None,
    ):
        """Require the official chassis collision envelope inside the zone."""
        accurate = self._accurate_base_pose_in_map(use_map_yaw=False)
        if accurate is not None:
            robot_x, robot_y, robot_yaw = accurate
        else:
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            except TransformException:
                return False
            robot_x = float(transform.transform.translation.x)
            robot_y = float(transform.transform.translation.y)
            robot_yaw = self._yaw_from_orientation(
                transform.transform.rotation
            )
        yaw_tolerance = float(
            self.node.get_parameter('drop_yaw_tolerance_rad').value
        )
        if yaw_tolerance_override is not None:
            yaw_tolerance = max(
                yaw_tolerance,
                float(yaw_tolerance_override),
            )

        check = check_base_inside_zone(
            robot_x=robot_x,
            robot_y=robot_y,
            robot_yaw=robot_yaw,
            required_yaw=float(required_yaw),
            yaw_tolerance=yaw_tolerance,
            front_extent=float(self.node.get_parameter(
                'drop_base_front_extent_m'
            ).value),
            rear_extent=float(self.node.get_parameter(
                'drop_base_rear_extent_m'
            ).value),
            half_width=float(self.node.get_parameter(
                'drop_base_half_width_m'
            ).value),
            margin=float(self.node.get_parameter(
                'drop_base_boundary_margin_m'
            ).value),
            overrun_tolerance=float(self.node.get_parameter(
                'drop_base_boundary_overrun_tolerance_m'
            ).value),
            zone_center_x=float(target['zone_center_x']),
            zone_center_y=float(target['zone_center_y']),
            zone_width=float(target['zone_width']),
            zone_height=float(target['zone_height']),
        )

        if log_result:
            if check.strictly_inside:
                message = '底盘（含轮子）已完整进入放置区'
            elif check.tolerated_inside:
                message = '底盘边界轻微超限，按安全容忍量接受'
            else:
                message = '底盘（含轮子）超出放置区安全容忍量'
            detail = (
                f'{message}：状态={check.failure_reason or "ok"}，'
                f'中心偏差=({check.delta_x:.3f}, {check.delta_y:.3f})m，'
                f'严格允许偏差=({check.allowed_x:.3f}, '
                f'{check.allowed_y:.3f})m，'
                f'边界超限=({check.overrun_x:.3f}, '
                f'{check.overrun_y:.3f})m'
            )
            if check.strictly_inside:
                self.node.get_logger().info(detail)
            elif check.tolerated_inside:
                self.node.get_logger().warning(detail)
            else:
                self.node.get_logger().error(detail)
        return check.passed

    def _drop_pose_inside_zone(
        self,
        target,
        required_yaw,
        log_result=True,
        yaw_tolerance_override=None,
    ):
        base_inside = self._drop_base_inside_zone(
            target,
            required_yaw,
            log_result=log_result,
            yaw_tolerance_override=yaw_tolerance_override,
        )
        release_inside = self._drop_release_inside_zone(
            target,
            required_yaw,
            log_result=log_result,
            yaw_tolerance_override=yaw_tolerance_override,
        )
        if base_inside and release_inside and log_result:
            self.node.get_logger().info(
                '投放位双重验收通过：底盘满足边界安全条件，'
                '物块释放点位于区域内'
            )
        return base_inside and release_inside

    def _drop_release_inside_zone(
        self,
        target,
        required_yaw,
        log_result=True,
        yaw_tolerance_override=None,
    ):
        """Accept a drop pose from the object outcome, not base-pose error.

        The official markers are visual floor regions and have no collision.
        Near their edge Nav2 can stop short because walls and inflation make
        the nominal base pose unreachable.  The actual requirement is that
        the detached 30 mm cube lands inside the marker, so predict the
        gripper release point from TF and only finish when that point (plus a
        safety margin) is contained by the configured zone rectangle.
        """
        accurate_base = self._accurate_base_pose_in_map(use_map_yaw=False)
        accurate_release = self._accurate_release_point_in_map()
        if accurate_base is not None and accurate_release is not None:
            robot_yaw = accurate_base[2]
            release_x, release_y, release_source = accurate_release
        else:
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            except TransformException:
                return False
            robot_yaw = self._yaw_from_orientation(
                transform.transform.rotation
            )
            # The calibrated forward/lateral offset represents where the cube
            # is actually detached, unlike the folded carry-pose link6.
            release_x, release_y, release_source = (
                self._predicted_release_point(transform)
            )
        yaw_tolerance = float(
            self.node.get_parameter('drop_yaw_tolerance_rad').value
        )
        if yaw_tolerance_override is not None:
            yaw_tolerance = max(
                yaw_tolerance,
                float(yaw_tolerance_override),
            )

        check = check_point_inside_zone(
            point_x=release_x,
            point_y=release_y,
            robot_yaw=robot_yaw,
            required_yaw=float(required_yaw),
            yaw_tolerance=yaw_tolerance,
            cube_half_extent=float(self.node.get_parameter(
                'drop_cube_half_extent_m'
            ).value),
            boundary_margin=float(self.node.get_parameter(
                'drop_boundary_margin_m'
            ).value),
            zone_center_x=float(target['zone_center_x']),
            zone_center_y=float(target['zone_center_y']),
            zone_width=float(target['zone_width']),
            zone_height=float(target['zone_height']),
        )

        if check.passed and log_result:
            self.node.get_logger().info(
                '预测释放点已完全进入放置区：'
                f'x={check.point_x:.3f}，y={check.point_y:.3f}，'
                f'航向误差={check.yaw_error_rad:.3f}rad，'
                f'来源={release_source}'
            )

        elif not check.passed and log_result:
            self.node.get_logger().error(
                '预测释放点越界：'
                f'x={check.point_x:.3f}，y={check.point_y:.3f}，'
                f'状态={check.failure_reason}，'
                f'允许中心范围x±{check.allowed_x:.3f}/'
                f'y±{check.allowed_y:.3f}，'
                f'来源={release_source}'
            )

        return check.passed

    def _gripper_release_point_in_map(self):
        """Return the live gripper-frame release point when TF is available."""
        release_frame = str(
            self.node.get_parameter('drop_release_frame').value
        ).strip() or 'link6'
        try:
            transform = self.tf_buffer.lookup_transform(
                'map',
                release_frame,
                Time(),
            )
        except TransformException:
            return None

        return (
            float(transform.transform.translation.x),
            float(transform.transform.translation.y),
            f'{release_frame}_tf',
        )

    def _predicted_release_point(self, base_transform):
        """Fallback calibrated release point from the base footprint pose."""
        forward = float(
            self.node.get_parameter('drop_release_forward_m').value
        )
        lateral = float(
            self.node.get_parameter('drop_release_lateral_m').value
        )
        robot_x = float(base_transform.transform.translation.x)
        robot_y = float(base_transform.transform.translation.y)
        robot_yaw = self._yaw_from_orientation(
            base_transform.transform.rotation
        )
        release_x = (
            robot_x
            + math.cos(robot_yaw) * forward
            - math.sin(robot_yaw) * lateral
        )
        release_y = (
            robot_y
            + math.sin(robot_yaw) * forward
            + math.cos(robot_yaw) * lateral
        )
        return release_x, release_y, 'base_estimate'

    def return_to_resource(self, stop_condition):
        self.node.get_logger().info('返回资源观察区')

        return self._navigate_to_named_target_with_dynamic_guard(
            'resource_observation',
            stop_condition,
        )
