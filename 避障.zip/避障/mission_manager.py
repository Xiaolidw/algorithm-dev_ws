import math
import time

import rclpy

from rcl_interfaces.msg import Parameter
from rcl_interfaces.msg import ParameterType
from rcl_interfaces.msg import ParameterValue
from rcl_interfaces.srv import SetParameters
from robot_interfaces.msg import TaskPlan
from robot_interfaces.msg import TaskProgress
from rclpy.time import Time
from std_msgs.msg import String
from tf2_ros import TransformException

from yzbot_mission.arm_operation_runner import ArmOperationRunner
from yzbot_mission.command_parser import task_plan_from_message
from yzbot_mission.mission_logic import expand_mission_steps
from yzbot_mission.navigation_client import NavigationClient
from yzbot_mission.transport_executor import TransportExecutor


class MissionManager(NavigationClient):

    def __init__(self):
        super().__init__('mission_manager')

        self.declare_parameter(
            'task_plan_topic',
            '/llm/task_plan',
        )
        self.declare_parameter(
            'progress_topic',
            '/mission/progress',
        )
        self.declare_parameter(
            'feedback_topic',
            '/mission/feedback',
        )
        self.declare_parameter('dry_run', True)
        self.declare_parameter('route_only_mode', True)
        self.declare_parameter('navigation_only_mode', True)
        self.declare_parameter(
            'return_between_cycles',
            True,
        )
        self.declare_parameter(
            'return_after_last_cycle',
            False,
        )
        self.declare_parameter(
            'stop_on_cycle_failure',
            True,
        )
        self.declare_parameter(
            'observation_target',
            'resource_observation',
        )
        self.declare_parameter(
            'detection_topic',
            '/vision/localized_detections',
        )
        self.declare_parameter('detection_wait_sec', 2.0)
        self.declare_parameter(
            'detection_maximum_age_sec',
            1.0,
        )
        self.declare_parameter(
            'chassis_image_topic',
            '/camera/image_raw',
        )
        self.declare_parameter(
            'chassis_detection_topic',
            '/vision/yolo_detections',
        )
        self.declare_parameter('opencv_alignment_retry_count', 1)
        self.declare_parameter('opencv_alignment_total_budget_sec', 8.0)
        self.declare_parameter(
            'pickup_standoff_distance',
            0.360,
        )
        self.declare_parameter(
            'known_target_reference_distance',
            0.85,
        )
        self.declare_parameter(
            'pickup_navigation_distance',
            0.330,
        )
        self.declare_parameter(
            'pickup_selection_path_timeout_sec',
            0.50,
        )
        self.declare_parameter(
            'pickup_final_distance_m',
            0.360,
        )
        self.declare_parameter(
            'pickup_position_tolerance_m',
            0.060,
        )
        self.declare_parameter(
            'pickup_stationary_handoff_position_tolerance_m',
            0.22,
        )
        self.declare_parameter(
            'pickup_grasp_handoff_tolerance_m',
            0.020,
        )
        self.declare_parameter(
            'pickup_minimum_safe_distance_m',
            0.29,
        )
        self.declare_parameter('pickup_brake_prediction_sec', 0.70)
        self.declare_parameter('pickup_brake_prediction_min_m', 0.28)
        self.declare_parameter('pickup_brake_prediction_max_m', 0.35)
        self.declare_parameter(
            'pickup_yaw_handoff_tolerance_rad',
            0.35,
        )
        self.declare_parameter(
            'pickup_coarse_yaw_tolerance_rad',
            0.08,
        )
        self.declare_parameter(
            'pickup_coarse_yaw_max_velocity_rps',
            1.15,
        )
        self.declare_parameter(
            'pickup_coarse_yaw_timeout_sec',
            6.0,
        )
        self.declare_parameter('pickup_pid_stable_samples', 2)
        self.declare_parameter(
            'pickup_distance_tolerance_m',
            0.02,
        )
        self.declare_parameter(
            'pickup_distance_adjust_speed_mps',
            0.08,
        )
        self.declare_parameter(
            'pickup_distance_adjust_timeout_sec',
            20.0,
        )
        self.declare_parameter('gazebo_robot_model', 'six_arm')
        self.declare_parameter('allow_known_pose_visual_fallback', True)
        self.declare_parameter(
            'known_pose_fallback_position_tolerance_m',
            0.05,
        )
        self.declare_parameter(
            'known_pose_fallback_yaw_tolerance_rad',
            0.12,
        )
        self.declare_parameter(
            'drop_departure_retreat_distance_m',
            0.15,
        )
        self.declare_parameter(
            'drop_departure_retreat_speed_mps',
            0.30,
        )
        self.declare_parameter(
            'drop_departure_retreat_timeout_sec',
            8.0,
        )
        self.declare_parameter(
            'drop_departure_turn_max_velocity_rps',
            1.80,
        )
        self.declare_parameter('rolling_route_speed_mps', 0.64)
        self.declare_parameter(
            'rolling_route_max_angular_velocity_rps',
            2.40,
        )
        self.declare_parameter(
            'rolling_route_arc_trigger_rad',
            0.18,
        )
        self.declare_parameter(
            'rolling_route_yaw_tolerance_rad',
            0.08,
        )
        self.declare_parameter(
            'rolling_route_path_lookahead_m',
            1.50,
        )
        self.declare_parameter(
            'rolling_route_max_turn_radius_m',
            0.20,
        )
        self.declare_parameter('rolling_route_max_distance_m', 0.40)
        self.declare_parameter('rolling_route_timeout_sec', 8.0)
        self.declare_parameter('angle_pid_kp', 1.80)
        self.declare_parameter('angle_pid_ki', 0.06)
        self.declare_parameter('angle_pid_kd', 0.22)
        self.declare_parameter('angle_pid_integral_limit', 0.50)
        self.declare_parameter('angle_pid_derivative_alpha', 0.35)
        self.declare_parameter('angle_pid_min_velocity_rps', 0.10)
        # Empty and loaded profiles are both configurable.  Keeping the empty
        # profile out of hard-coded constants is important in Gazebo because
        # the tall arm can still tip the chassis after a placement cycle.
        self.declare_parameter('empty_linear_velocity_mps', 1.20)
        self.declare_parameter('empty_reverse_velocity_mps', 0.35)
        self.declare_parameter('empty_angular_velocity_rps', 1.90)
        self.declare_parameter('empty_linear_acceleration_mps2', 3.60)
        self.declare_parameter('empty_angular_acceleration_rps2', 7.00)
        # The raised arm and attached cube increase the chassis centre of
        # gravity. Use a separate envelope only while carrying.
        self.declare_parameter('carried_linear_velocity_mps', 1.00)
        self.declare_parameter('carried_reverse_velocity_mps', 0.35)
        self.declare_parameter('carried_angular_velocity_rps', 1.20)
        self.declare_parameter('carried_linear_acceleration_mps2', 2.00)
        self.declare_parameter('carried_angular_acceleration_rps2', 4.00)
        self.declare_parameter('pickup_pre_approach_position_tolerance_m', 0.18)
        self.declare_parameter('pickup_pre_approach_distance_tolerance_m', 0.12)
        self.declare_parameter('pickup_pre_approach_speed_limit_mps', 0.12)
        self.declare_parameter('pickup_pre_approach_no_progress_timeout_sec', 3.0)
        self.declare_parameter(
            'moving_obstacle_crossing_guard_enabled',
            True,
        )
        self.declare_parameter(
            'moving_obstacle_1_model',
            'moving_obstacle_1',
        )
        self.declare_parameter('moving_obstacle_1_track_x', -2.5)
        self.declare_parameter('moving_obstacle_1_track_min_y', 1.0)
        self.declare_parameter('moving_obstacle_1_track_max_y', 4.6)
        self.declare_parameter('moving_obstacle_1_half_extent_m', 0.39)
        self.declare_parameter(
            'moving_obstacle_2_model',
            'moving_obstacle_2',
        )
        self.declare_parameter('moving_obstacle_2_track_y', -5.5)
        self.declare_parameter('moving_obstacle_2_track_min_x', -2.8)
        self.declare_parameter('moving_obstacle_2_track_max_x', 3.0)
        self.declare_parameter('moving_obstacle_2_half_extent_m', 0.35)
        self.declare_parameter(
            'moving_obstacle_staging_offset_m',
            0.85,
        )
        self.declare_parameter('moving_obstacle_exit_offset_m', 0.70)
        self.declare_parameter(
            'moving_obstacle_prediction_horizon_sec',
            1.20,
        )
        self.declare_parameter(
            'moving_obstacle_required_wall_gap_m',
            0.70,
        )
        self.declare_parameter(
            'moving_obstacle_crossing_linear_velocity_mps',
            0.80,
        )
        self.declare_parameter(
            'moving_obstacle_crossing_angular_velocity_rps',
            0.90,
        )
        self.declare_parameter(
            'moving_obstacle_crossing_clearance_m',
            0.90,
        )
        self.declare_parameter(
            'moving_obstacle_crossing_wait_timeout_sec',
            30.0,
        )
        self.declare_parameter('dynamic_path_monitor_enabled', True)
        self.declare_parameter('dynamic_obstacle_scan_topic', '/scan')
        self.declare_parameter(
            'dynamic_obstacle_track_corridor_half_width_m', 0.45
        )
        self.declare_parameter(
            'dynamic_obstacle_min_laser_points', 3
        )
        self.declare_parameter(
            'dynamic_path_sample_interval_sec', 0.60
        )
        self.declare_parameter(
            'dynamic_path_change_absolute_m', 0.45
        )
        self.declare_parameter(
            'dynamic_path_change_relative_ratio', 0.08
        )
        self.declare_parameter(
            'dynamic_path_instant_mismatch_m', 0.35
        )
        self.declare_parameter(
            'dynamic_path_cumulative_mismatch_m', 0.65
        )
        self.declare_parameter(
            'dynamic_replan_stable_path_delta_m', 0.12
        )
        self.declare_parameter(
            'dynamic_replan_stable_sample_count', 3
        )
        self.declare_parameter(
            'dynamic_replan_stationary_timeout_sec', 8.0
        )
        self.declare_parameter(
            'dynamic_obstacle_detection_axis_distance_m', 0.80
        )
        self.declare_parameter(
            'dynamic_obstacle_match_distance_m', 1.20
        )
        self.declare_parameter(
            'dynamic_obstacle_deceleration_distance_m', 0.80
        )
        self.declare_parameter(
            'dynamic_obstacle_stop_distance_m', 0.80
        )
        self.declare_parameter('dynamic_obstacle_uncertain_speed_mps', 0.70)
        self.declare_parameter('dynamic_obstacle_safe_margin_m', 0.40)
        self.declare_parameter('dynamic_obstacle_risk_margin_m', 0.20)
        self.declare_parameter('dynamic_obstacle_safe_sample_count', 3)
        self.declare_parameter('dynamic_obstacle_exit_confirm_samples', 2)
        self.declare_parameter('dynamic_obstacle_exit_clear_distance_m', 1.15)
        self.declare_parameter('dynamic_obstacle_max_observed_speed_mps', 0.70)
        self.declare_parameter('drop_slot_spacing_m', 0.08)
        self.declare_parameter('drop_release_forward_m', 0.235)
        self.declare_parameter('drop_release_lateral_m', -0.058)
        self.declare_parameter('drop_release_frame', 'link6')
        self.declare_parameter('drop_cube_half_extent_m', 0.015)
        self.declare_parameter('drop_boundary_margin_m', 0.005)
        self.declare_parameter('drop_base_front_extent_m', 0.205)
        self.declare_parameter('drop_base_rear_extent_m', 0.167)
        self.declare_parameter('drop_base_half_width_m', 0.210)
        self.declare_parameter('drop_base_boundary_margin_m', 0.003)
        self.declare_parameter(
            'drop_base_boundary_overrun_tolerance_m',
            0.015,
        )
        self.declare_parameter('drop_pose_settle_timeout_sec', 3.0)
        self.declare_parameter('drop_pose_stable_samples', 3)
        self.declare_parameter('drop_yaw_tolerance_rad', 0.10)
        self.declare_parameter('drop_yaw_max_velocity_rps', 1.80)
        self.declare_parameter('drop_final_yaw_max_velocity_rps', 0.65)
        self.declare_parameter('pickup_departure_turn_requested_max_velocity_rps', 2.0)
        self.declare_parameter('pickup_departure_turn_effective_max_velocity_rps', 1.5)
        self.declare_parameter('pickup_departure_turn_middle_velocity_rps', 0.90)
        self.declare_parameter('pickup_departure_turn_low_velocity_rps', 0.50)
        self.declare_parameter('pickup_departure_turn_final_velocity_rps', 0.25)
        self.declare_parameter('pickup_departure_turn_fast_threshold_rad', 0.80)
        self.declare_parameter('pickup_departure_turn_middle_threshold_rad', 0.30)
        self.declare_parameter('pickup_departure_turn_final_threshold_rad', 0.10)
        self.declare_parameter('pickup_departure_turn_goal_tolerance_rad', 0.05)
        self.declare_parameter('pickup_departure_turn_stable_samples', 3)
        self.declare_parameter('pickup_departure_turn_stop_hold_sec', 0.40)
        self.declare_parameter('pickup_departure_turn_timeout_min_sec', 12.0)
        self.declare_parameter('pickup_departure_turn_timeout_max_sec', 22.0)
        self.declare_parameter('pickup_departure_turn_timeout_margin_sec', 4.0)
        self.declare_parameter('drop_yaw_timeout_sec', 8.0)
        self.declare_parameter(
            'drop_mppi_pull_through_distance_m',
            0.15,
        )
        self.declare_parameter(
            'drop_position_handoff_tolerance_m',
            0.07,
        )
        self.declare_parameter('drop_handoff_lateral_tolerance_m', 0.06)
        self.declare_parameter('drop_handoff_longitudinal_tolerance_m', 0.18)
        self.declare_parameter('drop_a_pre_approach_distance_m', 0.50)
        self.declare_parameter('drop_a_pre_approach_handoff_tolerance_m', 0.12)
        self.declare_parameter('drop_a_pre_approach_settle_sec', 0.60)
        self.declare_parameter('drop_a_control_handoff_min_distance_m', 0.30)
        self.declare_parameter('drop_a_control_handoff_max_distance_m', 0.65)
        self.declare_parameter('drop_a_control_handoff_lateral_tolerance_m', 0.08)
        self.declare_parameter('drop_a_control_handoff_yaw_tolerance_rad', 0.15)
        self.declare_parameter('drop_a_control_handoff_speed_limit_mps', 0.15)
        self.declare_parameter('drop_a_intermediate_stop_distance_m', 0.20)
        self.declare_parameter('drop_a_intermediate_stop_settle_sec', 0.50)
        self.declare_parameter('drop_a_final_stop_settle_sec', 0.70)
        self.declare_parameter('drop_a_trim_fast_speed_mps', 0.12)
        self.declare_parameter('drop_a_trim_middle_speed_mps', 0.08)
        self.declare_parameter('drop_a_trim_final_speed_mps', 0.045)
        self.declare_parameter('drop_a_trim_fast_threshold_m', 0.25)
        self.declare_parameter('drop_a_trim_final_threshold_m', 0.10)
        self.declare_parameter('drop_a_trim_timeout_min_sec', 12.0)
        self.declare_parameter('drop_a_trim_timeout_max_sec', 30.0)
        self.declare_parameter('drop_a_trim_timeout_margin_sec', 4.0)
        self.declare_parameter('drop_a_trim_timeout_scale', 1.8)
        self.declare_parameter('drop_position_trim_tolerance_m', 0.10)
        self.declare_parameter('drop_position_trim_speed_mps', 0.12)
        self.declare_parameter('drop_position_trim_timeout_sec', 18.0)
        self.declare_parameter('drop_entry_staging_distance_m', 0.75)
        self.declare_parameter(
            'drop_base_longitudinal_offset_m',
            0.20,
        )
        self.declare_parameter('drop_entry_path_timeout_sec', 3.0)
        self.declare_parameter(
            'arm_operation_timeout_sec',
            60.0,
        )
        self.declare_parameter(
            'arm_minimum_motion_seconds',
            0.70,
        )
        self.declare_parameter('arm_pick_retry_count', 1)
        self.declare_parameter('arm_gripper_close_seconds', 0.55)
        self.declare_parameter('arm_cube_link', 'link')
        self.declare_parameter(
            'observation_position_tolerance',
            0.15,
        )
        self.declare_parameter(
            'resource_approach_tolerance_m',
            0.30,
        )
        self.declare_parameter('scan_wait_sec', 1.2)
        self.declare_parameter(
            'scan_cmd_vel_topic',
            '/cmd_vel_nav',
        )
        self.declare_parameter(
            'scan_maximum_angular_velocity',
            0.15,
        )
        self.declare_parameter(
            'scan_yaw_tolerance',
            0.08,
        )
        self.declare_parameter(
            'scan_timeout_sec',
            20.0,
        )

        task_plan_topic = str(
            self.get_parameter(
                'task_plan_topic'
            ).value
        )
        progress_topic = str(
            self.get_parameter(
                'progress_topic'
            ).value
        )
        feedback_topic = str(
            self.get_parameter(
                'feedback_topic'
            ).value
        )

        self.dry_run = bool(
            self.get_parameter('dry_run').value
        )
        self.route_only_mode = bool(
            self.get_parameter(
                'route_only_mode'
            ).value
        )
        self.chassis_image_topic = str(
            self.get_parameter(
                'chassis_image_topic'
            ).value
        )
        self.chassis_detection_topic = str(
            self.get_parameter(
                'chassis_detection_topic'
            ).value
        )
        self.resource_approach_tolerance_m = float(
            self.get_parameter(
                'resource_approach_tolerance_m'
            ).value
        )

        self.navigation_only_mode = bool(
            self.get_parameter(
                'navigation_only_mode'
            ).value
        )

        self.return_between_cycles = bool(
            self.get_parameter(
                'return_between_cycles'
            ).value
        )

        self.return_after_last_cycle = bool(
            self.get_parameter(
                'return_after_last_cycle'
            ).value
        )

        self.stop_on_cycle_failure = bool(
            self.get_parameter(
                'stop_on_cycle_failure'
            ).value
        )

        self.pending_plan = None
        self.active_plan = None
        self.active_cycles = ()
        self.current_cycle = None
        self.current_cycle_index = 0
        self.completed_cycles = 0
        self.busy = False
        self.stop_requested = False
        # Unknown until the first remote parameter transaction.  ``None``
        # forces the configured empty profile to be sent at mission startup
        # instead of assuming Nav2's launch-time defaults already match it.
        self.carried_motion_profile_active = None
        self._crossing_previous_carried_profile = False
        self._motion_parameter_clients = {}

        self.task_plan_subscription = (
            self.create_subscription(
                TaskPlan,
                task_plan_topic,
                self.task_plan_callback,
                10,
            )
        )

        self.feedback_publisher = (
            self.create_publisher(
                String,
                feedback_topic,
                10,
            )
        )

        self.progress_publisher = (
            self.create_publisher(
                TaskProgress,
                progress_topic,
                10,
            )
        )

        self.transport_executor = TransportExecutor(self)
        self.arm_runner = (
            None
            if self.navigation_only_mode
            else ArmOperationRunner(self)
        )
        self.drop_slot_counts = {
            'A': 0,
            'B': 0,
            'C': 0,
        }

        self.get_logger().info(
            '任务管理器已启动：'
            f'task_plan_topic={task_plan_topic}，'
            f'dry_run={self.dry_run}，'
            f'route_only_mode='
            f'{self.route_only_mode}，'
            f'navigation_only_mode='
            f'{self.navigation_only_mode}'
        )

    @staticmethod
    def _remote_parameter(name, value):
        """Build a ROS parameter message for a scalar or vector."""
        parameter_value = ParameterValue()
        if isinstance(value, (list, tuple)):
            parameter_value.type = ParameterType.PARAMETER_DOUBLE_ARRAY
            parameter_value.double_array_value = [
                float(item) for item in value
            ]
        else:
            parameter_value.type = ParameterType.PARAMETER_DOUBLE
            parameter_value.double_value = float(value)
        return Parameter(name=str(name), value=parameter_value)

    def _set_remote_parameters(self, node_name, values):
        """Set one coherent motion envelope on another ROS node."""
        service_name = f'/{str(node_name).strip("/")}/set_parameters'
        client = self._motion_parameter_clients.get(service_name)
        if client is None:
            client = self.create_client(SetParameters, service_name)
            self._motion_parameter_clients[service_name] = client

        if not client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error(
                f'携物速度切换服务不可用：{service_name}'
            )
            return False

        request = SetParameters.Request()
        request.parameters = [
            self._remote_parameter(name, value)
            for name, value in values.items()
        ]
        future = client.call_async(request)
        deadline = time.monotonic() + 3.0
        while rclpy.ok() and not future.done() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)

        response = future.result() if future.done() else None
        if response is None:
            self.get_logger().error(
                f'携物速度切换超时：{service_name}'
            )
            return False

        failures = [
            result.reason or 'parameter rejected'
            for result in response.results
            if not result.successful
        ]
        if failures:
            self.get_logger().error(
                f'携物速度切换被拒绝：{service_name}：'
                + '；'.join(failures)
            )
            return False
        return True

    def set_carried_motion_profile(self, enabled):
        """Synchronize MPPI limits and the final velocity smoother."""
        enabled = bool(enabled)
        if enabled == self.carried_motion_profile_active:
            return True

        if enabled:
            vx_max = float(self.get_parameter(
                'carried_linear_velocity_mps'
            ).value)
            reverse = float(self.get_parameter(
                'carried_reverse_velocity_mps'
            ).value)
            wz_max = float(self.get_parameter(
                'carried_angular_velocity_rps'
            ).value)
            linear_accel = float(self.get_parameter(
                'carried_linear_acceleration_mps2'
            ).value)
            angular_accel = float(self.get_parameter(
                'carried_angular_acceleration_rps2'
            ).value)
            linear_decel = max(1.80, linear_accel)
            angular_decel = max(3.00, angular_accel)
            smoother_reverse = reverse
            smoother_reverse_angular = wz_max
            profile_name = '携物平稳'
        else:
            vx_max = float(self.get_parameter(
                'empty_linear_velocity_mps'
            ).value)
            reverse = float(self.get_parameter(
                'empty_reverse_velocity_mps'
            ).value)
            wz_max = float(self.get_parameter(
                'empty_angular_velocity_rps'
            ).value)
            linear_accel = float(self.get_parameter(
                'empty_linear_acceleration_mps2'
            ).value)
            angular_accel = float(self.get_parameter(
                'empty_angular_acceleration_rps2'
            ).value)
            linear_decel = max(1.50, linear_accel)
            angular_decel = max(3.00, angular_accel)
            # Direct safety/departure commands may reverse quickly, while
            # MPPI remains forward-biased at vx_min=-0.05 m/s.
            smoother_reverse = vx_max
            smoother_reverse_angular = wz_max
            profile_name = '空载正常'

        # MPPI exposes velocity bounds dynamically, but its acceleration
        # settings are construction-time parameters on this Nav2 version.
        # Apply acceleration/deceleration at the velocity smoother instead.
        controller_ok = self._set_remote_parameters(
            'controller_server',
            {
                'FollowPath.vx_max': vx_max,
                'FollowPath.vx_min': -reverse,
                'FollowPath.wz_max': wz_max,
            },
        )
        smoother_ok = self._set_remote_parameters(
            'velocity_smoother',
            {
                'max_velocity': [vx_max, 0.0, wz_max],
                'min_velocity': [
                    -smoother_reverse,
                    0.0,
                    -smoother_reverse_angular,
                ],
                'max_accel': [linear_accel, 0.0, angular_accel],
                'max_decel': [-linear_decel, 0.0, -angular_decel],
            },
        )
        if not (controller_ok and smoother_ok):
            self.publish_stop()
            return False

        self.carried_motion_profile_active = enabled
        self.get_logger().info(
            f'已切换为{profile_name}速度曲线：'
            f'vx={vx_max:.2f}m/s，wz={wz_max:.2f}rad/s，'
            f'ax={linear_accel:.2f}m/s^2，az={angular_accel:.2f}rad/s^2，'
            f'decel=({linear_decel:.2f}, {angular_decel:.2f})'
        )
        return True

    def set_obstacle_crossing_profile(self, enabled, velocity_override=None):
        """Apply a temporary safety envelope only when crossing risk warrants it."""
        enabled = bool(enabled)
        if enabled:
            self._crossing_previous_carried_profile = bool(
                self.carried_motion_profile_active
            )
            vx_max = (
                float(velocity_override)
                if velocity_override is not None
                else float(self.get_parameter(
                    'moving_obstacle_crossing_linear_velocity_mps'
                ).value)
            )
            wz_max = float(self.get_parameter(
                'moving_obstacle_crossing_angular_velocity_rps'
            ).value)
            controller_ok = self._set_remote_parameters(
                'controller_server',
                {
                    'FollowPath.vx_max': vx_max,
                    'FollowPath.vx_min': -0.05,
                    'FollowPath.wz_max': wz_max,
                },
            )
            smoother_ok = self._set_remote_parameters(
                'velocity_smoother',
                {
                    'max_velocity': [vx_max, 0.0, wz_max],
                    'min_velocity': [-0.15, 0.0, -wz_max],
                    'max_accel': [1.20, 0.0, 2.00],
                    'max_decel': [-1.60, 0.0, -2.40],
                },
            )
            if controller_ok and smoother_ok:
                self.get_logger().info(
                    '已切换移动障碍轴低速预测模式：'
                    f'vx={vx_max:.2f}m/s，wz={wz_max:.2f}rad/s'
                )
                return True
            self.publish_stop()
            return False

        restore_carried = self._crossing_previous_carried_profile
        # Force set_carried_motion_profile to re-send its parameters.
        self.carried_motion_profile_active = not restore_carried
        restored = self.set_carried_motion_profile(restore_carried)
        if restored:
            self.get_logger().info('已离开移动障碍轴，恢复路线速度')
        return restored

    def publish_feedback(self, text):
        message = String()
        message.data = str(text)
        self.feedback_publisher.publish(message)

        self.get_logger().info(
            f'任务反馈：{message.data}'
        )

    def publish_progress(
        self,
        state,
        detail,
        plan=None,
        cycle=None,
        step_completed=None,
        total_completed=None,
        success=False,
    ):
        """发布供比赛界面使用的结构化任务进度。"""
        plan = plan or self.active_plan
        cycle = cycle or self.current_cycle

        message = TaskProgress()
        message.header.stamp = (
            self.get_clock().now().to_msg()
        )
        message.task_id = (
            str(plan.task_id) if plan is not None else ''
        )
        message.state = str(state).strip().upper()
        message.detail = str(detail)
        message.current_step = (
            int(cycle.step_index) if cycle is not None else 0
        )
        message.total_steps = (
            len(plan.steps) if plan is not None else 0
        )
        message.current_color = (
            str(cycle.color) if cycle is not None else ''
        )
        message.current_destination = (
            str(cycle.destination) if cycle is not None else ''
        )

        if step_completed is None:
            step_completed = (
                max(int(cycle.iteration) - 1, 0)
                if cycle is not None
                else 0
            )

        message.step_completed = int(step_completed)
        message.step_total = (
            int(cycle.step_count) if cycle is not None else 0
        )
        message.total_completed = int(
            self.completed_cycles
            if total_completed is None
            else total_completed
        )
        message.total_target = (
            int(plan.total_count) if plan is not None else 0
        )
        message.success = bool(success)

        self.progress_publisher.publish(message)
        self.get_logger().info(
            '任务进度：'
            f'state={message.state}，'
            f'total={message.total_completed}/'
            f'{message.total_target}，'
            f'detail={message.detail}'
        )

    def task_plan_callback(self, message):
        action = str(
            message.action
        ).strip().lower()

        if action == 'stop':
            stopped_plan = self.active_plan or self.pending_plan
            stopped_cycle = self.current_cycle
            self.stop_requested = True
            self.pending_plan = None
            self.publish_stop()
            self.publish_feedback(
                '已收到停止任务指令'
            )
            self.publish_progress(
                'STOPPING' if self.busy else 'STOPPED',
                '已收到停止任务指令',
                plan=stopped_plan,
                cycle=stopped_cycle,
                total_completed=(
                    self.completed_cycles if self.busy else 0
                ),
            )
            return

        if action != 'execute':
            self.publish_feedback(
                f'收到非执行任务：'
                f'{action}，{message.reason}'
            )
            return

        if (
            self.busy
            or self.pending_plan is not None
        ):
            self.publish_feedback(
                '机器人正在执行任务，'
                '暂不接受新的执行指令'
            )
            return

        try:
            self.pending_plan = (
                task_plan_from_message(
                    message
                )
            )
        except ValueError as error:
            self.publish_feedback(
                f'任务计划校验失败：{error}'
            )
            return

        self.publish_feedback(
            '任务计划已接收：'
            f'task_id={self.pending_plan.task_id}，'
            f'total_count='
            f'{self.pending_plan.total_count}'
        )

        self.publish_progress(
            'RECEIVED',
            '任务计划已接收，等待执行',
            plan=self.pending_plan,
            total_completed=0,
        )

    def should_stop(self):
        return self.stop_requested

    def _before_navigation_retry(self):
        """Repair AMCL from Gazebo ground truth before retrying navigation.

        A stalled delivery is frequently caused by AMCL thrashing near a
        moving obstacle.  The chassis is stationary here, so re-anchoring
        AMCL to the Gazebo ground truth is safe and lets the retry proceed
        with a correct map pose.
        """
        if (
            self.navigation_only_mode
            or self.transport_executor is None
        ):
            return True

        repaired = (
            self.transport_executor._ensure_sim_localization_consistent()
        )
        if not repaired:
            self.get_logger().warning(
                '导航重试前无法用Gazebo真值修复AMCL定位，'
                '继续使用当前定位重试'
            )
        return True

    def _near_waypoint(
        self,
        target_name,
        tolerance_m,
    ):
        waypoint = self.get_waypoint(target_name)

        if waypoint is None:
            return False

        try:
            transform = (
                self.transport_executor.tf_buffer.lookup_transform(
                    'map',
                    'base_footprint',
                    Time(),
                )
            )
        except TransformException:
            return False

        delta_x = (
            float(transform.transform.translation.x)
            - waypoint['x']
        )
        delta_y = (
            float(transform.transform.translation.y)
            - waypoint['y']
        )

        return (
            math.hypot(delta_x, delta_y)
            <= tolerance_m
        )

    def _navigate_to_resource_observation(self):
        """前往资源观察区，位置进入容差后即可停止，不苛求最终朝向。"""
        tolerance = self.resource_approach_tolerance_m
        reached = [False]

        def stop_when_near():
            if self.should_stop():
                return True

            if self._near_waypoint(
                'resource_observation',
                tolerance,
            ):
                reached[0] = True
                return True

            return False

        success = self.navigate_to_named_target(
            'resource_observation',
            stop_condition=stop_when_near,
        )

        return success or reached[0]

    def execute_route_only_plan(
        self,
        plan,
        cycles,
    ):
        if not cycles:
            self.publish_feedback(
                '任务中没有执行循环'
            )
            return False

        self.transport_executor.reset_known_pickup_sequence()
        self.drop_slot_counts = {
            'A': 0,
            'B': 0,
            'C': 0,
        }
        pickup_navigation_distance = float(
            self.get_parameter(
                'pickup_navigation_distance'
            ).value
        )
        pickup_grasp_distance = float(
            self.get_parameter('pickup_standoff_distance').value
        )
        self.get_logger().info(
            'MPPI牵引抓取路线模式：'
            '根据当前位置选择A*总路线最短的未使用物块，'
            f'规划目标={pickup_navigation_distance:.3f}m，'
            f'真实距离达到{pickup_grasp_distance:.3f}m时提前交接，'
            '随后由OpenCV像素误差直接生成角度目标并快速对准'
        )

        for cycle_index, cycle in enumerate(
            cycles,
            start=1,
        ):
            self.current_cycle = cycle
            self.current_cycle_index = cycle_index

            if self.stop_requested:
                self.publish_feedback(
                    '任务已停止'
                )
                return False

            self.get_logger().info(
                f'固定路线循环'
                f'{cycle_index}/{len(cycles)}：'
                f'{cycle.color} → '
                f'{cycle.destination}区，'
                f'目标点={cycle.waypoint}'
            )

            self.publish_progress(
                'NAVIGATING_TO_PICKUP',
                f'正在评估A*路线并前往{cycle.color}物块'
                f'{pickup_grasp_distance:.3f}m真实抓取交接位',
                plan=plan,
                cycle=cycle,
            )

            pickup_success = (
                self.transport_executor.execute_known_pickup_ready(
                    cycle.target_class,
                    cycle.color,
                    cycle.waypoint,
                    self.should_stop,
                )
            )

            if not pickup_success:
                if self.stop_requested:
                    self.publish_feedback(
                        '前往物块准备位或车头回正过程中'
                        '任务被停止'
                    )
                else:
                    self.publish_feedback(
                        f'{cycle.color}物块抓取准备位导航'
                        '或车头回正失败'
                    )
                return False

            self.publish_progress(
                'PICKUP_READY',
                f'已到达{cycle.color}物块'
                f'{pickup_grasp_distance:.3f}m抓取准备位，'
                'OpenCV角度目标环朝向校准已完成',
                plan=plan,
                cycle=cycle,
            )

            cube_model = (
                self.transport_executor.active_pickup_model
            )

            if not cube_model:
                self.publish_feedback(
                    '抓取准备完成，但没有取得实际物块模型名'
                )
                return False

            if not self.navigation_only_mode:
                self.publish_progress(
                    'ARM_PICKING',
                    f'机械臂正在抓取并抬升{cube_model}',
                    plan=plan,
                    cycle=cycle,
                )

                pick_success = self.arm_runner.run(
                    'pick',
                    cube_model,
                    self.should_stop,
                )
                retry_count = max(0, int(self.get_parameter(
                    'arm_pick_retry_count'
                ).value))
                for retry_index in range(retry_count):
                    if pick_success or self.should_stop():
                        break
                    self.publish_progress(
                        'PICK_REALIGNING',
                        f'{cube_model}首次抓取未进入夹爪，'
                        '正根据实时位置重新对准',
                        plan=plan,
                        cycle=cycle,
                    )
                    if not self.transport_executor.recover_active_pickup_ready(
                        self.should_stop
                    ):
                        break
                    self.publish_progress(
                        'ARM_PICK_RETRY',
                        f'正在第{retry_index + 2}次抓取{cube_model}',
                        plan=plan,
                        cycle=cycle,
                    )
                    pick_success = self.arm_runner.run(
                        'pick',
                        cube_model,
                        self.should_stop,
                    )
                if not pick_success:
                    self.publish_feedback(
                        f'机械臂抓取失败：{cube_model}；'
                        '已执行安全回收和单次实时重定位'
                    )
                    return False

                self.publish_progress(
                    'OBJECT_CARRIED',
                    f'{cube_model}已夹紧、绑定并抬升',
                    plan=plan,
                    cycle=cycle,
                )

                if not self.set_carried_motion_profile(True):
                    self.publish_feedback(
                        '无法启用携物平稳速度曲线，已停止底盘'
                    )
                    return False

            # In navigation-only acceptance this keeps the old behavior.  In
            # physical mode it runs only after attach + lift have succeeded.
            if not self.transport_executor.execute_pickup_departure(
                self.should_stop,
                destination=cycle.destination,
            ):
                self.publish_feedback('抓取完成后的安全退出失败')
                return False

            self.publish_progress(
                'NAVIGATING_TO_DESTINATION',
                f'固定路线模式：正在前往{cycle.destination}区',
                plan=plan,
                cycle=cycle,
            )

            destination = str(cycle.destination).strip().upper()
            slot_index = self.drop_slot_counts.get(destination, 0)
            success = self.transport_executor.execute_drop_ready(
                destination,
                self.should_stop,
                slot_index=slot_index,
            )

            if not success:
                if self.stop_requested:
                    self.publish_feedback(
                        f'前往{cycle.destination}区'
                        '过程中任务被停止'
                    )
                else:
                    self.publish_feedback(
                        f'前往{cycle.destination}区失败'
                    )
                return False

            self.get_logger().info(
                f'已到达{destination}区投放槽位{slot_index + 1}'
            )

            if not self.navigation_only_mode:
                self.publish_progress(
                    'ARM_PLACING',
                    f'机械臂正在把{cube_model}放入'
                    f'{destination}区槽位{slot_index + 1}',
                    plan=plan,
                    cycle=cycle,
                )

                if not self.arm_runner.run(
                    'place',
                    cube_model,
                    self.should_stop,
                ):
                    self.publish_feedback(
                        f'机械臂放置失败：{cube_model}'
                    )
                    return False

                if not self.set_carried_motion_profile(False):
                    self.get_logger().warning(
                        '物块已释放，但空载速度曲线恢复失败；'
                        '继续沿用更安全的携物限速'
                    )

                self.drop_slot_counts[destination] = slot_index + 1

                self.publish_progress(
                    'OBJECT_PLACED',
                    f'{cube_model}已进入{destination}区'
                    f'槽位{slot_index + 1}',
                    plan=plan,
                    cycle=cycle,
                )

            self.completed_cycles += 1
            self.publish_progress(
                'CYCLE_COMPLETED',
                (
                    f'{cube_model}抓取和放置循环完成'
                    if not self.navigation_only_mode
                    else '固定路线底盘循环完成，未执行机械臂抓放'
                ),
                plan=plan,
                cycle=cycle,
                step_completed=cycle.iteration,
                total_completed=self.completed_cycles,
            )

            has_next_cycle = (
                cycle_index < len(cycles)
            )

            should_return = (
                (
                    has_next_cycle
                    and self.return_between_cycles
                )
                or (
                    not has_next_cycle
                    and self.return_after_last_cycle
                )
            )

            # Always clear the just-released cube before another cycle.  When
            # the route intentionally skips the shared observation point, the
            # next pickup selector will compute the next A* heading after this
            # retreat.  When a return is requested we can pre-align here.
            if has_next_cycle or should_return:
                self.get_logger().info(
                    '先沿进入路线退出投放区，避免车轮碰到已放物块'
                )

                self.publish_progress(
                    'DEPARTING_DROP_ZONE',
                    '放置完成，正在远离已放物块固定移动0.15米',
                    plan=plan,
                    cycle=cycle,
                )

                if not self.transport_executor.execute_drop_departure(
                    self.should_stop,
                    next_waypoint=(
                        'resource_observation'
                        if should_return
                        else None
                    ),
                ):
                    self.publish_feedback('放置完成后的安全退出失败')
                    return False

            if should_return:
                self.publish_progress(
                    'RETURNING_TO_RESOURCE',
                    '已退出投放区，正在返回资源观察区',
                    plan=plan,
                    cycle=cycle,
                )

                success = (
                    self._navigate_to_resource_observation()
                )

                if not success:
                    if self.stop_requested:
                        self.publish_feedback(
                            '返回资源区过程中'
                            '任务被停止'
                        )
                    else:
                        self.publish_feedback(
                            '返回资源观察区失败'
                        )
                    return False

                self.publish_progress(
                    'AT_RESOURCE',
                    '已返回资源观察区，准备下一循环',
                    plan=plan,
                    cycle=cycle,
                )

        return True

    def execute_full_cycle(
        self,
        cycle,
        cycle_index,
        total_cycles,
    ):
        """执行一次视觉抓取准备位到目标区投放准备位的底盘流程。"""
        if self.should_stop():
            self.publish_stop()
            return False

        self.publish_progress(
            'SEARCHING_TARGET',
            f'正在识别并接近{cycle.color}物块',
            cycle=cycle,
        )

        self.get_logger().info(
            f'视觉导航循环{cycle_index}/{total_cycles}：'
            f'{cycle.color} -> {cycle.destination}区，'
            f'第{cycle.iteration}/{cycle.step_count}次'
        )

        pickup_success = (
            self.transport_executor.execute_pickup_ready(
                cycle.target_class,
                self.should_stop,
            )
        )

        if not pickup_success:
            if self.should_stop():
                self.publish_feedback(
                    f'寻找{cycle.color}物块或接近过程中任务被停止'
                )
            else:
                self.publish_feedback(
                    f'未能到达{cycle.color}物块抓取准备位'
                )
            return False

        self.publish_feedback(
            f'已到达{cycle.color}物块抓取准备位；'
            '机械臂阶段尚未启用'
        )
        self.publish_progress(
            'PICKUP_READY',
            f'已到达{cycle.color}物块抓取准备位，'
            '未执行机械臂抓取',
            cycle=cycle,
        )

        if self.should_stop():
            self.publish_stop()
            return False

        self.publish_progress(
            'NAVIGATING_TO_DESTINATION',
            f'正在前往{cycle.destination}区投放准备位',
            cycle=cycle,
        )

        drop_success = (
            self.transport_executor.execute_drop_ready(
                cycle.destination,
                self.should_stop,
            )
        )

        if not drop_success:
            if self.should_stop():
                self.publish_feedback(
                    f'前往{cycle.destination}区过程中任务被停止'
                )
            else:
                self.publish_feedback(
                    f'未能到达{cycle.destination}区投放准备位'
                )
            return False

        self.publish_feedback(
            f'已到达{cycle.destination}区投放准备位；'
            '机械臂阶段尚未启用'
        )
        self.publish_progress(
            'DROP_READY',
            f'已到达{cycle.destination}区投放准备位，'
            '未执行机械臂放置',
            cycle=cycle,
        )
        return True

    def execute_full_plan(
        self,
        plan,
        cycles,
    ):
        """严格按大模型给出的步骤顺序执行全部底盘运输循环。"""
        if not cycles:
            self.publish_feedback('任务中没有执行循环')
            return False

        if not self.navigation_only_mode and self.arm_runner is None:
            self.get_logger().error(
                '机械臂执行器初始化失败，无法进入完整抓放模式'
            )
            self.publish_feedback(
                '机械臂执行器初始化失败，拒绝执行真实抓放'
            )
            return False

        if not self.navigation_only_mode:
            self.get_logger().info(
                '机械臂执行器已接入，进入真实导航、抓取和放置流程'
            )

        all_cycles_successful = True

        self.get_logger().info(
            '进入完整视觉底盘流程：'
            f'task_id={plan.task_id}，'
            f'循环总数={len(cycles)}'
        )

        for cycle_index, cycle in enumerate(cycles, start=1):
            self.current_cycle = cycle
            self.current_cycle_index = cycle_index

            if self.should_stop():
                self.publish_stop()
                return False

            cycle_success = self.execute_full_cycle(
                cycle,
                cycle_index,
                len(cycles),
            )

            if not cycle_success:
                all_cycles_successful = False

                if self.should_stop() or self.stop_on_cycle_failure:
                    self.publish_stop()
                    return False

                self.get_logger().warning(
                    f'循环{cycle_index}失败，'
                    '根据配置继续下一循环'
                )

            else:
                self.completed_cycles += 1
                self.publish_progress(
                    'CYCLE_COMPLETED',
                    '底盘准备位循环完成，未执行机械臂抓放',
                    plan=plan,
                    cycle=cycle,
                    step_completed=cycle.iteration,
                    total_completed=self.completed_cycles,
                )

            has_next_cycle = cycle_index < len(cycles)
            should_return = (
                (
                    has_next_cycle
                    and self.return_between_cycles
                )
                or (
                    not has_next_cycle
                    and self.return_after_last_cycle
                )
            )

            if not should_return:
                continue

            self.publish_progress(
                'RETURNING_TO_RESOURCE',
                '正在返回资源观察区',
                plan=plan,
                cycle=cycle,
            )

            return_success = (
                self.transport_executor.return_to_resource(
                    self.should_stop,
                )
            )

            if return_success:
                self.publish_feedback(
                    '已返回资源观察区，准备下一循环'
                )
                self.publish_progress(
                    'AT_RESOURCE',
                    '已返回资源观察区，准备下一循环',
                    plan=plan,
                    cycle=cycle,
                )
                continue

            all_cycles_successful = False

            if self.should_stop():
                self.publish_feedback(
                    '返回资源区过程中任务被停止'
                )
            else:
                self.publish_feedback(
                    '返回资源观察区失败'
                )

            if self.should_stop() or self.stop_on_cycle_failure:
                self.publish_stop()
                return False

        return all_cycles_successful

    def execute_pending_plan(self):
        if (
            self.pending_plan is None
            or self.busy
        ):
            return

        plan = self.pending_plan
        self.pending_plan = None
        self.active_plan = plan
        self.active_cycles = ()
        self.current_cycle = None
        self.current_cycle_index = 0
        self.completed_cycles = 0
        self.busy = True
        self.stop_requested = False

        # Initialize the empty (no-load) motion profile before the first
        # navigation.  carried_motion_profile_active starts as None, so the
        # first pickup approach would otherwise run at Nav2's launch-time
        # vx_max (1.10 m/s) while every later empty leg runs at the configured
        # empty_linear_velocity_mps.  Send the empty profile once up front so
        # every empty leg shares one envelope.
        if not self.set_carried_motion_profile(False):
            self.get_logger().warning(
                '无法初始化空载速度曲线，'
                '第一段导航将沿用Nav2启动默认速度'
            )

        success = False

        try:
            cycles = expand_mission_steps(
                plan.steps
            )
            self.active_cycles = cycles

            self.publish_progress(
                'RUNNING',
                '开始执行任务计划',
                plan=plan,
            )

            self.get_logger().info(
                '开始执行任务：'
                f'task_id={plan.task_id}，'
                f'循环总数={len(cycles)}，'
                f'dry_run={self.dry_run}，'
                f'route_only_mode='
                f'{self.route_only_mode}'
            )

            if not cycles:
                self.publish_feedback(
                    '任务中没有有效执行循环'
                )
                success = False

            elif self.dry_run:
                self.get_logger().info(
                    '当前为dry_run模式，'
                    '只打印任务顺序'
                )

                for cycle_index, cycle in enumerate(
                    cycles,
                    start=1,
                ):
                    self.current_cycle = cycle
                    self.current_cycle_index = cycle_index
                    self.get_logger().info(
                        f'执行顺序'
                        f'{cycle_index}/'
                        f'{len(cycles)}：'
                        f'步骤'
                        f'{cycle.step_index}/'
                        f'{cycle.total_steps}，'
                        f'{cycle.color}'
                        f' → '
                        f'{cycle.destination}区，'
                        f'第{cycle.iteration}/'
                        f'{cycle.step_count}次，'
                        f'导航点='
                        f'{cycle.waypoint}'
                    )

                success = True

            elif self.route_only_mode:
                self.get_logger().info(
                    '进入固定路线导航模式'
                )

                success = (
                    self.execute_route_only_plan(
                        plan,
                        cycles,
                    )
                )

            else:
                self.get_logger().info(
                    '进入完整视觉导航模式'
                )

                success = self.execute_full_plan(
                    plan,
                    cycles,
                )

            if self.stop_requested:
                self.publish_progress(
                    'STOPPED',
                    '任务已停止',
                    plan=plan,
                    cycle=self.current_cycle,
                )
                self.publish_feedback(
                    f'任务已停止：'
                    f'task_id={plan.task_id}'
                )

            elif success:
                if self.dry_run:
                    completion_detail = (
                        '任务顺序检查完成，未驱动机器人'
                    )
                elif self.navigation_only_mode:
                    completion_detail = (
                        '底盘任务流程完成，未执行机械臂抓放'
                    )
                else:
                    completion_detail = '任务执行完成'
                self.publish_progress(
                    'COMPLETED',
                    completion_detail,
                    plan=plan,
                    cycle=self.current_cycle,
                    step_completed=(
                        self.current_cycle.step_count
                        if self.current_cycle is not None
                        else 0
                    ),
                    total_completed=self.completed_cycles,
                    success=True,
                )
                self.publish_feedback(
                    f'{completion_detail}：task_id={plan.task_id}'
                )

            else:
                self.publish_progress(
                    'FAILED',
                    '任务执行失败',
                    plan=plan,
                    cycle=self.current_cycle,
                )
                self.publish_feedback(
                    f'任务执行失败：'
                    f'task_id={plan.task_id}'
                )

        except Exception as error:
            self.get_logger().error(
                f'任务执行异常：{error}'
            )
            self.publish_feedback(
                f'任务执行异常：{error}'
            )
            self.publish_progress(
                'FAILED',
                f'任务执行异常：{error}',
                plan=plan,
                cycle=self.current_cycle,
            )

        finally:
            self.busy = False
            self.stop_requested = False
            self.publish_stop()
            self.active_plan = None
            self.active_cycles = ()
            self.current_cycle = None
            self.current_cycle_index = 0


def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()

    try:
        while rclpy.ok():
            rclpy.spin_once(
                node,
                timeout_sec=0.1,
            )
            node.execute_pending_plan()

    except KeyboardInterrupt:
        node.get_logger().warning(
            '用户终止任务管理器'
        )

    finally:
        if rclpy.ok():
            node.publish_stop()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
